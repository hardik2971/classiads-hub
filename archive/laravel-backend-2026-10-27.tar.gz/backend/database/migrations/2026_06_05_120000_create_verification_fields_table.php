<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('verification_fields', function (Blueprint $table) {
            $table->id();
            $table->string('name', 150);
            $table->enum('field_type', ['text', 'number', 'file', 'select'])->default('text');
            $table->unsignedInteger('min_length')->nullable();
            $table->unsignedInteger('max_length')->nullable();
            // Comma-separated or JSON list of allowed values when field_type=select.
            $table->json('values')->nullable();
            $table->boolean('is_required')->default(true);
            $table->boolean('is_active')->default(true)->index();
            $table->unsignedInteger('sort_order')->default(0)->index();
            $table->timestamps();
        });

        // Seed the 3 fields shown in the reference mock so the page isn't
        // empty on first open.
        \DB::table('verification_fields')->insert([
            [
                'name'        => 'ID Proof (Front)',
                'field_type'  => 'file',
                'min_length'  => null,
                'max_length'  => null,
                'values'      => null,
                'sort_order'  => 1,
                'is_active'   => true,
                'is_required' => true,
                'created_at'  => now(),
                'updated_at'  => now(),
            ],
            [
                'name'        => 'ID Proff (Back)',
                'field_type'  => 'file',
                'min_length'  => null,
                'max_length'  => null,
                'values'      => null,
                'sort_order'  => 2,
                'is_active'   => true,
                'is_required' => false,
                'created_at'  => now(),
                'updated_at'  => now(),
            ],
            [
                'name'        => 'National ID No',
                'field_type'  => 'text',
                'min_length'  => 5,
                'max_length'  => 20,
                'values'      => null,
                'sort_order'  => 3,
                'is_active'   => true,
                'is_required' => true,
                'created_at'  => now(),
                'updated_at'  => now(),
            ],
        ]);
    }

    public function down(): void
    {
        Schema::dropIfExists('verification_fields');
    }
};

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    // Dynamic SEO metadata: per-entity (polymorphic) or per static route_key.
    public function up(): void
    {
        Schema::create('seo_meta', function (Blueprint $table) {
            $table->id();
            $table->string('seoable_type', 191)->nullable();
            $table->unsignedBigInteger('seoable_id')->nullable();
            $table->string('route_key', 100)->nullable()->unique(); // e.g. home, search
            $table->string('title', 191)->nullable();
            $table->string('description', 500)->nullable();
            $table->string('keywords', 500)->nullable();
            $table->string('og_image', 255)->nullable();
            $table->json('json_ld')->nullable(); // structured data
            $table->timestamps();

            $table->unique(['seoable_type', 'seoable_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('seo_meta');
    }
};

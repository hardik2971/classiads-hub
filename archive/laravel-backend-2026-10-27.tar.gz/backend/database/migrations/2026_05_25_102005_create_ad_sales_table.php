<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Records the confirmed buyer of a sold ad ("Who bought?" flow).
        Schema::create('ad_sales', function (Blueprint $table) {
            $table->id();
            $table->foreignId('ad_id')->unique()->constrained()->cascadeOnDelete();
            $table->foreignId('seller_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('buyer_id')->constrained('users')->cascadeOnDelete();
            $table->timestamp('confirmed_at')->nullable();
            $table->timestamps();

            $table->index('buyer_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ad_sales');
    }
};

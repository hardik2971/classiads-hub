<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('faqs', function (Blueprint $table) {
            $table->id();
            $table->string('question', 500);
            $table->text('answer');
            // Per-locale overrides: { en: {question, answer}, fr: {...}, ar: {...}, ru: {...} }
            $table->json('translations')->nullable();
            $table->unsignedInteger('sort_order')->default(0)->index();
            $table->boolean('is_active')->default(true)->index();
            $table->timestamps();
        });

        // Seed the 7 starter FAQs from the reference mock so the table isn't
        // empty on first open.
        $now = now();
        \DB::table('faqs')->insert([
            ['question' => 'What is ClassiAds_Hub?',                      'answer' => 'ClassiAds_Hub is a multi-vendor classifieds marketplace covering everything from real-estate to electronics.',     'sort_order' => 1, 'is_active' => true, 'translations' => null, 'created_at' => $now, 'updated_at' => $now],
            ['question' => 'What features does eClassify offer?',          'answer' => 'eClassify offers a wide range of features including post management, chat, offers, monetization packages, and more.', 'sort_order' => 2, 'is_active' => true, 'translations' => null, 'created_at' => $now, 'updated_at' => $now],
            ['question' => 'Does eClassify support multiple languages?',   'answer' => 'Yes, eClassify supports multiple languages. You can switch the active language from the language picker.',           'sort_order' => 3, 'is_active' => true, 'translations' => null, 'created_at' => $now, 'updated_at' => $now],
            ['question' => 'What is Gemini AI integration in eClassify?',  'answer' => 'Gemini AI helps sellers automatically generate item descriptions, titles, and tags from a photo.',                  'sort_order' => 4, 'is_active' => true, 'translations' => null, 'created_at' => $now, 'updated_at' => $now],
            ['question' => 'How does the new SEO management system work?', 'answer' => 'It allows adding item-level meta tags, multilingual schema, automatic sitemap generation, and more.',               'sort_order' => 5, 'is_active' => true, 'translations' => null, 'created_at' => $now, 'updated_at' => $now],
            ['question' => 'Can I customize the home screen layout?',      'answer' => 'Yes. The modular home screen lets admins enable or disable each block and reorder Popular Categories.',            'sort_order' => 6, 'is_active' => true, 'translations' => null, 'created_at' => $now, 'updated_at' => $now],
            ['question' => 'Is there a way to search chats?',              'answer' => 'Yes. The chat search feature lets users quickly find conversations and messages by keyword.',                       'sort_order' => 7, 'is_active' => true, 'translations' => null, 'created_at' => $now, 'updated_at' => $now],
        ]);
    }

    public function down(): void
    {
        Schema::dropIfExists('faqs');
    }
};

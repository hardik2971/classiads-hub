<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('transactions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->enum('type', ['subscription', 'featured_ad']);

            // What is being purchased (nullable per type).
            $table->foreignId('package_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignId('featured_ad_plan_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignId('ad_id')->nullable()->constrained()->nullOnDelete();

            $table->string('gateway', 50);
            $table->string('gateway_reference', 191)->nullable()->index();
            $table->unsignedBigInteger('amount');     // minor units (subtotal)
            $table->unsignedBigInteger('tax_amount')->default(0);
            $table->unsignedBigInteger('total');      // minor units
            $table->string('currency_code', 8)->default('USD');
            $table->enum('status', ['pending', 'processing', 'completed', 'failed', 'refunded', 'cancelled'])
                ->default('pending')->index();
            $table->json('meta')->nullable();
            $table->timestamp('paid_at')->nullable();
            $table->timestamps();

            $table->index(['user_id', 'status']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('transactions');
    }
};

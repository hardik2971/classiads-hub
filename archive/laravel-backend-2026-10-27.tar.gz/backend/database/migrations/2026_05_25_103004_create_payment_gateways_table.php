<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('payment_gateways', function (Blueprint $table) {
            $table->id();
            $table->string('code', 50)->unique(); // stripe, razorpay, bank_transfer, sandbox...
            $table->string('name', 100);
            $table->boolean('is_active')->default(false)->index();
            $table->enum('mode', ['sandbox', 'live'])->default('sandbox');
            $table->json('config')->nullable();              // credentials (secret)
            $table->json('supported_currencies')->nullable();
            $table->boolean('is_manual')->default(false);    // e.g. bank transfer
            $table->unsignedInteger('sort_order')->default(0);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('payment_gateways');
    }
};

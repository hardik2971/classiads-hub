<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    // Category-based subscription plans: which categories a package covers.
    public function up(): void
    {
        Schema::create('package_category', function (Blueprint $table) {
            $table->id();
            $table->foreignId('package_id')->constrained()->cascadeOnDelete();
            $table->foreignId('category_id')->constrained()->cascadeOnDelete();
            $table->timestamps();

            $table->unique(['package_id', 'category_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('package_category');
    }
};

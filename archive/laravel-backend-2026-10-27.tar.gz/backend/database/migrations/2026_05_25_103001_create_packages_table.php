<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('packages', function (Blueprint $table) {
            $table->id();
            $table->string('name', 150);
            $table->string('ios_product_id', 191)->nullable();
            $table->string('android_product_id', 191)->nullable();
            $table->text('description')->nullable();
            $table->unsignedBigInteger('price');           // minor units
            $table->unsignedTinyInteger('discount_percent')->default(0);
            $table->unsignedBigInteger('final_price');     // minor units (after discount)
            $table->string('currency_code', 8)->default('USD');
            $table->unsignedSmallInteger('duration_days');
            $table->unsignedInteger('ad_limit')->nullable(); // null when unlimited
            $table->boolean('is_unlimited')->default(false);
            $table->string('icon_path', 255)->nullable();
            $table->boolean('is_active')->default(true)->index();
            $table->unsignedInteger('sort_order')->default(0)->index();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('packages');
    }
};

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('job_applications', function (Blueprint $table) {
            $table->id();
            $table->foreignId('job_listing_id')->constrained()->cascadeOnDelete();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete(); // applicant
            $table->text('cover_letter')->nullable();
            $table->string('resume_path', 255)->nullable();
            $table->enum('status', ['submitted', 'reviewed', 'shortlisted', 'rejected', 'hired'])
                ->default('submitted')->index();
            $table->timestamps();

            $table->unique(['job_listing_id', 'user_id']);
            $table->index('user_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('job_applications');
    }
};

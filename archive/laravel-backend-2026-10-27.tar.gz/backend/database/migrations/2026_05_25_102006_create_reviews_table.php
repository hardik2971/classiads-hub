<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('reviews', function (Blueprint $table) {
            $table->id();
            $table->foreignId('ad_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignId('reviewer_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('reviewee_id')->constrained('users')->cascadeOnDelete();
            $table->unsignedTinyInteger('rating'); // 1..5
            $table->text('comment')->nullable();
            // seller_review = buyer rates seller; buyer_review = seller rates buyer
            $table->enum('type', ['seller_review', 'buyer_review'])->default('seller_review');
            $table->boolean('is_approved')->default(true)->index();
            $table->timestamps();

            $table->unique(['reviewer_id', 'reviewee_id', 'ad_id']);
            $table->index(['reviewee_id', 'is_approved']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('reviews');
    }
};

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('offers', function (Blueprint $table) {
            $table->id();
            $table->foreignId('ad_id')->constrained()->cascadeOnDelete();
            $table->foreignId('conversation_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignId('buyer_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('seller_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('parent_offer_id')->nullable()->constrained('offers')->nullOnDelete();
            $table->unsignedBigInteger('amount'); // minor units
            $table->string('currency_code', 8)->default('USD');
            $table->enum('status', ['pending', 'accepted', 'rejected', 'countered', 'withdrawn'])
                ->default('pending')->index();
            $table->string('message', 500)->nullable();
            $table->timestamps();

            $table->index(['ad_id', 'buyer_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('offers');
    }
};

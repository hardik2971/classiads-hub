<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('job_listings', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete(); // employer
            $table->foreignId('category_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignId('city_id')->nullable()->constrained()->nullOnDelete();
            $table->string('title', 191);
            $table->string('slug', 191)->unique();
            $table->string('company_name', 191)->nullable();
            $table->longText('description');
            $table->enum('employment_type', ['full_time', 'part_time', 'contract', 'internship', 'remote'])
                ->default('full_time');
            $table->unsignedBigInteger('salary_min')->nullable(); // minor units
            $table->unsignedBigInteger('salary_max')->nullable();
            $table->string('currency_code', 8)->default('USD');
            $table->enum('status', ['draft', 'open', 'closed'])->default('open')->index();
            $table->timestamp('expires_at')->nullable();
            $table->unsignedInteger('applications_count')->default(0);
            $table->timestamps();

            $table->index(['status', 'category_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('job_listings');
    }
};

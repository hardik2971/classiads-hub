<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('ad_custom_field_values', function (Blueprint $table) {
            $table->id();
            $table->foreignId('ad_id')->constrained()->cascadeOnDelete();
            $table->foreignId('custom_field_id')->constrained()->cascadeOnDelete();
            // Scalar stored as string; multi-value (checkbox) stored as JSON string.
            $table->string('value', 500)->nullable();
            $table->timestamps();

            $table->unique(['ad_id', 'custom_field_id']);
            $table->index(['custom_field_id', 'value']); // filtering
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ad_custom_field_values');
    }
};

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('user_queries', function (Blueprint $table) {
            $table->id();
            $table->string('name', 150);
            $table->string('email', 191);
            $table->string('subject', 200);
            $table->text('message');
            $table->enum('status', ['open', 'replied', 'closed'])->default('open')->index();
            $table->timestamps();
        });

        $now = now();
        \DB::table('user_queries')->insert([
            ['name' => 'Subhankar Basak', 'email' => 'subhankarbasakmail@gmail.com', 'subject' => 'tthh',          'message' => 'message',                                                                                                  'created_at' => $now, 'updated_at' => $now],
            ['name' => 'test',            'email' => 'wrteam.bhumi@gmail.com',       'subject' => '65323',         'message' => 'ascf',                                                                                                     'created_at' => $now, 'updated_at' => $now],
            ['name' => 'Shyam',           'email' => 'kpshyam@rediffmail.com',       'subject' => 'Test Msg',      'message' => 'Test Message',                                                                                             'created_at' => $now, 'updated_at' => $now],
            ['name' => 'Dan',             'email' => 'danperrine5@gmail.com',        'subject' => 'Mobile money',  'message' => 'Can users pay for ads or subscriptions using mobile money? If so, which providers are supported?',         'created_at' => $now, 'updated_at' => $now],
        ]);
    }

    public function down(): void
    {
        Schema::dropIfExists('user_queries');
    }
};

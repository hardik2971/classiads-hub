<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('featured_sections', function (Blueprint $table) {
            $table->id();
            $table->string('title', 150);
            $table->enum('filter_type', ['latest', 'most_viewed', 'most_liked', 'featured', 'category'])
                ->default('latest');
            $table->foreignId('category_id')->nullable()->constrained()->nullOnDelete();
            $table->string('style', 50)->default('card'); // app display style
            $table->unsignedSmallInteger('item_limit')->default(10);
            $table->unsignedInteger('sort_order')->default(0)->index();
            $table->boolean('is_active')->default(true)->index();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('featured_sections');
    }
};

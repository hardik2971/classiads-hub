<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('ads', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('category_id')->constrained()->restrictOnDelete();

            $table->string('title', 191);
            $table->string('slug', 191)->unique();
            $table->longText('description');

            // Money stored in minor units (e.g. cents). Nullable for free/contact ads.
            $table->unsignedBigInteger('price')->nullable();
            $table->string('currency_code', 8)->default('USD');
            $table->enum('price_type', ['fixed', 'negotiable', 'free', 'contact'])->default('fixed');
            $table->enum('condition', ['new', 'used', 'refurbished'])->nullable();

            $table->string('phone', 32)->nullable();
            $table->string('video_url', 255)->nullable();

            // Location
            $table->foreignId('country_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignId('state_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignId('city_id')->nullable()->constrained()->nullOnDelete();
            $table->string('address', 255)->nullable();
            $table->decimal('latitude', 10, 7)->nullable();
            $table->decimal('longitude', 10, 7)->nullable();

            // Lifecycle
            $table->enum('status', ['draft', 'pending', 'approved', 'rejected', 'sold', 'expired'])
                ->default('pending')->index();
            $table->string('rejection_reason', 255)->nullable();
            $table->boolean('is_featured')->default(false)->index();
            $table->timestamp('featured_until')->nullable();

            $table->unsignedBigInteger('views_count')->default(0);
            $table->unsignedInteger('favorites_count')->default(0);

            $table->timestamp('approved_at')->nullable();
            $table->timestamp('sold_at')->nullable();
            $table->timestamp('published_at')->nullable();
            $table->timestamp('expires_at')->nullable()->index();

            $table->timestamps();
            $table->softDeletes();

            $table->index(['category_id', 'status']);
            $table->index(['city_id', 'status']);
            $table->index(['latitude', 'longitude']);
            $table->fullText(['title', 'description']); // keyword search
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ads');
    }
};

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Widen social_accounts.provider from enum(google,apple) to a string so additional
 * OAuth providers (facebook, etc.) can be linked without further migrations.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('social_accounts', function (Blueprint $table) {
            $table->string('provider', 20)->change();
        });
    }

    public function down(): void
    {
        Schema::table('social_accounts', function (Blueprint $table) {
            $table->enum('provider', ['google', 'apple'])->change();
        });
    }
};

<?php

namespace App\Providers;

use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        // Super-admins bypass all permission/policy checks.
        Gate::before(function ($user, $ability) {
            return $user->hasRole('super-admin') ? true : null;
        });

        $this->configureRateLimiters();
    }

    /**
     * Named throttles applied across the API (Phase 6 — abuse hardening).
     */
    private function configureRateLimiters(): void
    {
        // General API budget — keyed by authenticated user, else client IP.
        RateLimiter::for('api', fn (Request $request) => Limit::perMinute(90)
            ->by($request->user()?->id ?: $request->ip()));

        // Sensitive credential endpoints (login/register/social) — strict, per IP.
        RateLimiter::for('auth', fn (Request $request) => Limit::perMinute(10)
            ->by($request->ip()));

        // OTP / password-reset issuance — very strict to deter SMS/email abuse.
        RateLimiter::for('otp', fn (Request $request) => Limit::perMinute(6)
            ->by($request->ip()));
    }
}

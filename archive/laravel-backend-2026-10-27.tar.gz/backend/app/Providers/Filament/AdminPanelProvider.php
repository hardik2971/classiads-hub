<?php

namespace App\Providers\Filament;

use Filament\Auth\MultiFactor\App\AppAuthentication;
use Filament\Enums\ThemeMode;
use Filament\Http\Middleware\Authenticate;
use Filament\Http\Middleware\AuthenticateSession;
use Filament\Http\Middleware\DisableBladeIconComponents;
use Filament\Http\Middleware\DispatchServingFilamentEvent;
use App\Filament\Pages\Dashboard;
use Filament\Panel;
use Filament\PanelProvider;
use Filament\Support\Colors\Color;
use Filament\View\PanelsRenderHook;
use Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse;
use Illuminate\Cookie\Middleware\EncryptCookies;
use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken;
use Illuminate\Routing\Middleware\SubstituteBindings;
use Illuminate\Session\Middleware\StartSession;
use Illuminate\View\Middleware\ShareErrorsFromSession;

class AdminPanelProvider extends PanelProvider
{
    public function panel(Panel $panel): Panel
    {
        return $panel
            ->default()
            ->id('admin')
            ->path('admin')
            ->login()
            ->profile()
            ->multiFactorAuthentication([
                AppAuthentication::make()->recoverable(),
            ])
            ->brandName('')
            ->maxContentWidth(\Filament\Support\Enums\Width::Full)
            ->defaultThemeMode(ThemeMode::Light)
            // Explicit sidebar order. Groups listed here render in this exact
            // sequence; any group NOT listed (Catalog, Engagement, Localization,
            // Monetization, Content, Users & Access, Settings, System…) is
            // auto-pushed to the bottom of the sidebar.
            ->navigationGroups([
                'Ads Listing',
                'Package Management',
                'Seller Management',
                'Forms & Blogs',
                'User & Roles',
                'Location',
                'Reports',
            ])
            ->colors([
                'primary' => Color::hex('#272757'),  // brand Primary (navy)
                'warning' => Color::hex('#FFBF00'),  // brand Accent (amber)
                'gray'    => Color::hex('#505081'),  // brand Secondary
            ])
            ->renderHook(PanelsRenderHook::TOPBAR_START, fn () => '<a href="'.url('/admin').'" class="fi-topbar-brand inline-flex items-center"><img src="'.asset('main-logo-webiste.png').'" alt="ClassiAds_Hub"></a>')
            ->renderHook(PanelsRenderHook::AUTH_LOGIN_FORM_BEFORE, fn () => '<div class="fi-auth-logo"><img src="'.asset('main-logo-webiste.png').'" alt="ClassiAds_Hub"></div>')
            ->renderHook(PanelsRenderHook::AUTH_REGISTER_FORM_BEFORE, fn () => '<div class="fi-auth-logo"><img src="'.asset('main-logo-webiste.png').'" alt="ClassiAds_Hub"></div>')
            ->renderHook(PanelsRenderHook::AUTH_PASSWORD_RESET_REQUEST_FORM_BEFORE, fn () => '<div class="fi-auth-logo"><img src="'.asset('main-logo-webiste.png').'" alt="ClassiAds_Hub"></div>')
            ->renderHook(PanelsRenderHook::AUTH_PASSWORD_RESET_RESET_FORM_BEFORE, fn () => '<div class="fi-auth-logo"><img src="'.asset('main-logo-webiste.png').'" alt="ClassiAds_Hub"></div>')
            ->renderHook(PanelsRenderHook::STYLES_AFTER, fn () => <<<'HTML'
                <style>
                  /* Brand main background: Background Light from the palette. */
                  .fi-body,
                  .fi-main,
                  .fi-main-ctn,
                  .fi-page {
                      background-color: #E4E4EE !important;
                  }
                  /* Topbar: white with subtle bottom border. */
                  .fi-topbar {
                      background-color: #ffffff !important;
                      border-bottom: 1px solid rgba(39,39,87,0.08) !important;
                  }
                  /* Topbar brand logo (left side). */
                  .fi-topbar-brand img {
                      height: 52px;
                      width: auto;
                  }
                  /* Hide the empty sidebar header (brandName is now blank). */
                  .fi-sidebar-header {
                      display: none !important;
                  }
                  /* Login / register / password-reset: centered logo above the form. */
                  .fi-auth-logo {
                      display: flex;
                      justify-content: center;
                      margin-bottom: 1.5rem;
                  }
                  .fi-auth-logo img {
                      height: 56px;
                      width: auto;
                  }
                  /* Hide the default "Sign in" heading + subheading on auth pages. */
                  .fi-simple-header {
                      display: none !important;
                  }
                  /* Brand sidebar: navy background, white text/icons. */
                  .fi-sidebar,
                  .fi-sidebar-nav,
                  .fi-sidebar-header {
                      background-color: #272757 !important;
                      border-color: rgba(255,255,255,0.08) !important;
                  }
                  .fi-sidebar .fi-sidebar-item-label,
                  .fi-sidebar .fi-sidebar-item-icon,
                  .fi-sidebar .fi-sidebar-group-label,
                  .fi-sidebar .fi-sidebar-group-btn,
                  .fi-sidebar a,
                  .fi-sidebar button,
                  .fi-sidebar svg,
                  .fi-sidebar .fi-logo {
                      color: #ffffff !important;
                  }
                  .fi-sidebar .fi-sidebar-group-label {
                      color: rgba(255,255,255,0.55) !important;
                  }
                  /* Hover + active: white pill background, navy text/icons.
                     Covers leaf items, group expand/collapse, and group dropdown triggers. */
                  .fi-sidebar .fi-sidebar-item-btn:hover,
                  .fi-sidebar .fi-sidebar-group-btn:hover,
                  .fi-sidebar .fi-sidebar-group-collapse-btn:hover,
                  .fi-sidebar .fi-sidebar-group-dropdown-trigger-btn:hover,
                  .fi-sidebar .fi-sidebar-item.fi-active .fi-sidebar-item-btn,
                  .fi-sidebar .fi-sidebar-item-active .fi-sidebar-item-btn {
                      background-color: #ffffff !important;
                      color: #272757 !important;
                  }
                  .fi-sidebar .fi-sidebar-item-btn:hover .fi-sidebar-item-label,
                  .fi-sidebar .fi-sidebar-item-btn:hover .fi-sidebar-item-icon,
                  .fi-sidebar .fi-sidebar-item-btn:hover svg,
                  .fi-sidebar .fi-sidebar-group-btn:hover .fi-sidebar-group-label,
                  .fi-sidebar .fi-sidebar-group-btn:hover svg,
                  .fi-sidebar .fi-sidebar-group-collapse-btn:hover svg,
                  .fi-sidebar .fi-sidebar-group-dropdown-trigger-btn:hover svg,
                  .fi-sidebar .fi-sidebar-item.fi-active .fi-sidebar-item-label,
                  .fi-sidebar .fi-sidebar-item.fi-active .fi-sidebar-item-icon,
                  .fi-sidebar .fi-sidebar-item-active .fi-sidebar-item-label,
                  .fi-sidebar .fi-sidebar-item-active .fi-sidebar-item-icon,
                  .fi-sidebar .fi-sidebar-item.fi-active svg,
                  .fi-sidebar .fi-sidebar-item-active svg {
                      color: #272757 !important;
                  }

                  /* Brand all buttons: navy background, white text + icons. */
                  .fi-btn {
                      background-color: #272757 !important;
                      color: #ffffff !important;
                      border-color: #272757 !important;
                  }
                  .fi-btn:hover {
                      background-color: #1c1c40 !important;
                      color: #ffffff !important;
                      border-color: #1c1c40 !important;
                  }
                  .fi-btn svg,
                  .fi-btn .fi-btn-label,
                  .fi-btn .fi-btn-icon {
                      color: #ffffff !important;
                  }
                  /* Disabled buttons keep the brand bg but with reduced opacity. */
                  .fi-btn:disabled,
                  .fi-btn[aria-disabled="true"] {
                      opacity: 0.55;
                  }
                </style>
                HTML)
            ->navigationGroups([
                'Listings',
                'Catalog',
                'Users & Access',
                'Monetization',
                'Engagement',
                'Homepage',
                'Localization',
                'Content',
                'System',
            ])
            ->discoverResources(in: app_path('Filament/Resources'), for: 'App\Filament\Resources')
            ->discoverPages(in: app_path('Filament/Pages'), for: 'App\Filament\Pages')
            ->pages([
                Dashboard::class,
            ])
            ->discoverWidgets(in: app_path('Filament/Widgets'), for: 'App\Filament\Widgets')
            ->widgets([
                \App\Filament\Widgets\WelcomeWidget::class,
                \App\Filament\Widgets\StatsOverviewWidget::class,
                \App\Filament\Widgets\FeaturedSectionsWidget::class,
            ])
            ->middleware([
                EncryptCookies::class,
                AddQueuedCookiesToResponse::class,
                StartSession::class,
                AuthenticateSession::class,
                ShareErrorsFromSession::class,
                VerifyCsrfToken::class,
                SubstituteBindings::class,
                DisableBladeIconComponents::class,
                DispatchServingFilamentEvent::class,
            ])
            ->authMiddleware([
                Authenticate::class,
            ]);
    }
}

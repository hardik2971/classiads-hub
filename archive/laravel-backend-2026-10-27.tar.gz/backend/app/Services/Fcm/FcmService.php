<?php

namespace App\Services\Fcm;

use App\Models\User;
use Illuminate\Support\Facades\Log;

/**
 * Firebase Cloud Messaging sender (pluggable).
 *
 * Default driver is "log" so the notification fan-out is fully testable without
 * Firebase credentials. A real FCM HTTP v1 driver plugs into deliver().
 */
class FcmService
{
    public function driver(): string
    {
        return (string) config('services.fcm.driver', env('FCM_DRIVER', 'log'));
    }

    /**
     * Send to all of a user's registered device tokens.
     *
     * @return int number of tokens targeted
     */
    public function sendToUser(User $user, string $title, string $body, array $data = []): int
    {
        $tokens = $user->devices()->pluck('fcm_token')->all();

        if (empty($tokens)) {
            return 0;
        }

        $this->deliver($tokens, $title, $body, $data);

        return count($tokens);
    }

    /**
     * @param  array<int,string>  $tokens
     */
    public function deliver(array $tokens, string $title, string $body, array $data = []): void
    {
        if ($this->driver() === 'log') {
            Log::info('[FCM:log] '.json_encode([
                'tokens' => count($tokens),
                'title'  => $title,
                'body'   => $body,
                'data'   => $data,
            ]));

            return;
        }

        // TODO: real FCM HTTP v1 delivery (service account / OAuth token).
        Log::warning('[FCM] driver "'.$this->driver().'" not implemented; message dropped.');
    }
}

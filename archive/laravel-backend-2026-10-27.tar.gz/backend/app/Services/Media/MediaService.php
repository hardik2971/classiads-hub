<?php

namespace App\Services\Media;

use App\Models\Setting;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

/**
 * Image upload pipeline: store on the public disk, optionally watermark (GD).
 * Watermark behaviour is driven by settings (media.watermark_enabled / media.watermark_text).
 */
class MediaService
{
    public function disk(): string
    {
        return 'public';
    }

    /**
     * Store an uploaded image and return its relative path on the public disk.
     */
    public function storeImage(UploadedFile $file, string $dir = 'ads'): string
    {
        $name = Str::uuid()->toString().'.'.strtolower($file->getClientOriginalExtension() ?: 'jpg');
        $path = trim($dir, '/').'/'.$name;

        $binary = file_get_contents($file->getRealPath());

        if ($this->watermarkEnabled() && function_exists('imagecreatefromstring')) {
            $watermarked = $this->applyWatermark($binary);
            if ($watermarked !== null) {
                $binary = $watermarked;
            }
        }

        Storage::disk($this->disk())->put($path, $binary);

        return $path;
    }

    protected function watermarkEnabled(): bool
    {
        return (bool) Setting::get('media', 'watermark_enabled', false);
    }

    protected function watermarkText(): string
    {
        return (string) Setting::get('media', 'watermark_text', config('app.name'));
    }

    /**
     * Overlay a semi-transparent text watermark in the bottom-right corner.
     * Returns JPEG binary, or null if the source could not be decoded.
     */
    protected function applyWatermark(string $binary): ?string
    {
        $img = @imagecreatefromstring($binary);
        if ($img === false) {
            return null;
        }

        $width  = imagesx($img);
        $height = imagesy($img);
        $text   = $this->watermarkText();

        $fontSize = max(10, (int) ($width / 35));
        $padding  = (int) ($fontSize * 0.8);

        // Built-in GD font (1-5); approximate placement bottom-right.
        $font   = 5;
        $charW  = imagefontwidth($font);
        $charH  = imagefontheight($font);
        $textW  = $charW * strlen($text);
        $x      = max($padding, $width - $textW - $padding);
        $y      = max($padding, $height - $charH - $padding);

        $shadow = imagecolorallocatealpha($img, 0, 0, 0, 60);
        $white  = imagecolorallocatealpha($img, 255, 255, 255, 30);

        imagestring($img, $font, $x + 1, $y + 1, $text, $shadow);
        imagestring($img, $font, $x, $y, $text, $white);

        ob_start();
        imagejpeg($img, null, 88);
        $out = ob_get_clean();
        imagedestroy($img);

        return $out ?: null;
    }
}

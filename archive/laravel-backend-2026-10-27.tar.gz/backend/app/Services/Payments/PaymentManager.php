<?php

namespace App\Services\Payments;

use App\Models\PaymentGateway;
use App\Services\Payments\Contracts\PaymentGatewayDriver;
use App\Services\Payments\Drivers\BankTransferDriver;
use App\Services\Payments\Drivers\GenericExternalDriver;
use App\Services\Payments\Drivers\SandboxDriver;
use App\Services\Payments\Drivers\StripeDriver;
use RuntimeException;

/**
 * Resolves a payment driver by gateway code, using the (active) payment_gateways
 * config row. This is the single seam between the app and any gateway.
 */
class PaymentManager
{
    /**
     * @return array<int, array{code:string, name:string, is_manual:bool, mode:string}>
     */
    public function availableGateways(): array
    {
        return PaymentGateway::active()->orderBy('sort_order')->get()
            ->map(fn ($g) => [
                'code'      => $g->code,
                'name'      => $g->name,
                'is_manual' => (bool) $g->is_manual,
                'mode'      => $g->mode,
            ])->all();
    }

    public function resolve(string $code): PaymentGatewayDriver
    {
        $gateway = PaymentGateway::where('code', $code)->first();

        if (! $gateway || ! $gateway->is_active) {
            throw new RuntimeException("Payment gateway [{$code}] is not available.");
        }

        $config = $gateway->config ?? [];

        return match ($code) {
            'sandbox'       => new SandboxDriver($config),
            'bank_transfer' => new BankTransferDriver($config),
            'stripe'        => new StripeDriver($config),
            default         => new GenericExternalDriver($code, $config),
        };
    }
}

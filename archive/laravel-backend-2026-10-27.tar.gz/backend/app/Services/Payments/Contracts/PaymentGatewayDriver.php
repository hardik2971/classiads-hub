<?php

namespace App\Services\Payments\Contracts;

use App\Models\Transaction;
use Illuminate\Http\Request;

/**
 * Single contract every payment gateway implements. Drivers are gateway-agnostic
 * to the rest of the app; the PaymentManager resolves the right one by code.
 */
interface PaymentGatewayDriver
{
    public function code(): string;

    /**
     * Begin a payment for a pending transaction.
     *
     * @return array{status:string, requires_action:bool, reference?:string, checkout_url?:?string, instructions?:?string, message?:?string}
     */
    public function initiate(Transaction $transaction, array $options = []): array;

    /**
     * Verify/confirm a payment (used by dev confirm + manual admin confirm).
     * Returns true when the payment should be treated as captured.
     */
    public function confirm(Transaction $transaction, array $payload = []): bool;

    /**
     * Parse an incoming webhook into a normalized result, or null if not handled.
     *
     * @return array{transaction_id?:int, gateway_reference?:string, status:string}|null
     */
    public function parseWebhook(Request $request): ?array;
}

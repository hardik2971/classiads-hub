<?php

namespace App\Services\Payments\Drivers;

use App\Models\Transaction;
use App\Services\Payments\Contracts\PaymentGatewayDriver;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

/**
 * Manual bank transfer. Buyer gets transfer instructions; an admin confirms the
 * payment once funds are received (transaction stays pending until then).
 */
class BankTransferDriver implements PaymentGatewayDriver
{
    public function __construct(private readonly array $config = []) {}

    public function code(): string
    {
        return 'bank_transfer';
    }

    public function initiate(Transaction $transaction, array $options = []): array
    {
        $ref = 'bt_'.Str::upper(Str::random(10));
        $transaction->update(['gateway_reference' => $ref, 'status' => 'pending']);

        $instructions = $this->config['instructions']
            ?? 'Transfer the amount to the marketplace bank account and quote your reference.';

        return [
            'status'          => 'pending',
            'requires_action' => true,
            'reference'       => $ref,
            'checkout_url'    => null,
            'instructions'    => $instructions." (Ref: {$ref})",
            'message'         => 'Awaiting manual confirmation by an administrator.',
        ];
    }

    public function confirm(Transaction $transaction, array $payload = []): bool
    {
        // Only an admin should trigger this (enforced at the controller layer).
        return true;
    }

    public function parseWebhook(Request $request): ?array
    {
        return null; // manual gateway has no webhook
    }
}

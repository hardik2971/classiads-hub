<?php

namespace App\Services\Payments\Drivers;

use App\Models\Transaction;
use App\Services\Payments\Contracts\PaymentGatewayDriver;
use Illuminate\Http\Request;
use RuntimeException;

/**
 * Stripe driver (scaffold). Shows where real PaymentIntent / Checkout Session
 * creation + webhook signature verification go. Requires a configured secret key.
 */
class StripeDriver implements PaymentGatewayDriver
{
    public function __construct(private readonly array $config = []) {}

    public function code(): string
    {
        return 'stripe';
    }

    public function initiate(Transaction $transaction, array $options = []): array
    {
        $secret = $this->config['secret_key'] ?? null;
        if (! $secret) {
            throw new RuntimeException('Stripe is not configured (missing secret_key).');
        }

        // TODO: create a Stripe Checkout Session / PaymentIntent here and return its URL/client_secret.
        // $session = \Stripe\Checkout\Session::create([...]); $transaction->update(['gateway_reference' => $session->id]);
        throw new RuntimeException('Stripe live integration is not implemented in this build.');
    }

    public function confirm(Transaction $transaction, array $payload = []): bool
    {
        // TODO: retrieve PaymentIntent and check status === 'succeeded'.
        return false;
    }

    public function parseWebhook(Request $request): ?array
    {
        // TODO: verify Stripe-Signature header, map event -> transaction.
        return null;
    }
}

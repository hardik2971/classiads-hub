<?php

namespace App\Services\Payments\Drivers;

use App\Models\Transaction;
use App\Services\Payments\Contracts\PaymentGatewayDriver;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

/**
 * Sandbox gateway — simulates a hosted-checkout flow end-to-end without real
 * credentials. initiate() issues a reference + checkout URL; the payment is
 * captured via confirm() (dev) or the webhook ({reference, status:completed}).
 */
class SandboxDriver implements PaymentGatewayDriver
{
    public function __construct(private readonly array $config = []) {}

    public function code(): string
    {
        return 'sandbox';
    }

    public function initiate(Transaction $transaction, array $options = []): array
    {
        $ref = 'sbx_'.Str::lower(Str::random(20));
        $transaction->update(['gateway_reference' => $ref, 'status' => 'pending']);

        return [
            'status'          => 'pending',
            'requires_action' => true,
            'reference'       => $ref,
            'checkout_url'    => url("/api/v1/payments/{$transaction->id}/confirm"),
            'message'         => 'Sandbox checkout — POST to checkout_url (or the webhook) to capture.',
        ];
    }

    public function confirm(Transaction $transaction, array $payload = []): bool
    {
        // Sandbox always succeeds unless explicitly told to fail.
        return ($payload['simulate'] ?? 'success') !== 'fail';
    }

    public function parseWebhook(Request $request): ?array
    {
        return [
            'transaction_id'    => $request->integer('transaction_id') ?: null,
            'gateway_reference' => $request->string('reference')->toString() ?: null,
            'status'            => $request->string('status')->toString() ?: 'completed',
        ];
    }
}

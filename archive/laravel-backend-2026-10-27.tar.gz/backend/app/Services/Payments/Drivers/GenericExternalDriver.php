<?php

namespace App\Services\Payments\Drivers;

use App\Models\Transaction;
use App\Services\Payments\Contracts\PaymentGatewayDriver;
use Illuminate\Http\Request;
use RuntimeException;

/**
 * Placeholder for hosted-redirect gateways not yet implemented
 * (Razorpay, PayPal, Paystack, PhonePe, Flutterwave, PayTabs, DPO).
 * Keeps the contract intact so a real driver can replace it without app changes.
 */
class GenericExternalDriver implements PaymentGatewayDriver
{
    public function __construct(
        private readonly string $gatewayCode,
        private readonly array $config = []
    ) {}

    public function code(): string
    {
        return $this->gatewayCode;
    }

    public function initiate(Transaction $transaction, array $options = []): array
    {
        if (empty($this->config)) {
            throw new RuntimeException(ucfirst($this->gatewayCode).' is not configured.');
        }

        throw new RuntimeException(ucfirst($this->gatewayCode).' live integration is not implemented in this build.');
    }

    public function confirm(Transaction $transaction, array $payload = []): bool
    {
        return false;
    }

    public function parseWebhook(Request $request): ?array
    {
        return null;
    }
}

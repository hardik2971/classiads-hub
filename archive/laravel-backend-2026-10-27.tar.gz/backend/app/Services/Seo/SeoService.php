<?php

namespace App\Services\Seo;

use App\Models\Ad;
use App\Models\BlogPost;
use App\Models\Category;
use App\Models\JobListing;
use App\Models\Page;
use App\Models\SeoMeta;
use App\Models\Setting;
use Illuminate\Database\Eloquent\Model;

class SeoService
{
    public function frontendUrl(): string
    {
        return rtrim((string) (Setting::get('general', 'frontend_url') ?: config('app.url')), '/');
    }

    /** Resolve SEO meta for a static route key, falling back to site defaults. */
    public function forRoute(string $routeKey): array
    {
        $meta = SeoMeta::where('route_key', $routeKey)->first();

        return $this->withDefaults($meta);
    }

    /** Resolve SEO meta for an entity (ad, category, blog post, page). */
    public function forModel(Model $model): array
    {
        $meta = SeoMeta::where('seoable_type', $model::class)
            ->where('seoable_id', $model->getKey())
            ->first();

        return $this->withDefaults($meta, $model);
    }

    private function withDefaults(?SeoMeta $meta, ?Model $model = null): array
    {
        $siteName = (string) Setting::get('general', 'app_name', config('app.name'));

        $title = $meta?->title
            ?? ($model->title ?? $model->name ?? null)
            ?? $siteName;

        $description = $meta?->description
            ?? ($model->excerpt ?? $model->description ?? null)
            ?? (string) Setting::get('general', 'app_tagline', '');

        return [
            'title'       => \Illuminate\Support\Str::limit((string) $title, 160, ''),
            'description' => \Illuminate\Support\Str::limit(strip_tags((string) $description), 280, ''),
            'keywords'    => $meta?->keywords,
            'og_image'    => $meta?->og_image,
            'json_ld'     => $meta?->json_ld,
        ];
    }

    /**
     * Build a sitemap of indexable URLs.
     *
     * @return array<int, array{loc:string, lastmod:?string}>
     */
    public function sitemapUrls(): array
    {
        $base = $this->frontendUrl();
        $urls = [['loc' => $base.'/', 'lastmod' => now()->toDateString()]];

        foreach (Page::published()->get() as $page) {
            $urls[] = ['loc' => "{$base}/{$page->key}", 'lastmod' => $page->updated_at?->toDateString()];
        }
        foreach (Category::query()->active()->get() as $cat) {
            $urls[] = ['loc' => "{$base}/category/{$cat->slug}", 'lastmod' => $cat->updated_at?->toDateString()];
        }
        foreach (Ad::query()->published()->latest('published_at')->limit(5000)->get(['slug', 'updated_at']) as $ad) {
            $urls[] = ['loc' => "{$base}/ad/{$ad->slug}", 'lastmod' => $ad->updated_at?->toDateString()];
        }
        foreach (BlogPost::query()->published()->get(['slug', 'updated_at']) as $post) {
            $urls[] = ['loc' => "{$base}/blog/{$post->slug}", 'lastmod' => $post->updated_at?->toDateString()];
        }
        foreach (JobListing::query()->open()->get(['slug', 'updated_at']) as $job) {
            $urls[] = ['loc' => "{$base}/jobs/{$job->slug}", 'lastmod' => $job->updated_at?->toDateString()];
        }

        return $urls;
    }

    public function sitemapXml(): string
    {
        $xml = '<?xml version="1.0" encoding="UTF-8"?>'."\n";
        $xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'."\n";
        foreach ($this->sitemapUrls() as $u) {
            $xml .= '  <url><loc>'.htmlspecialchars($u['loc']).'</loc>';
            if (! empty($u['lastmod'])) {
                $xml .= '<lastmod>'.$u['lastmod'].'</lastmod>';
            }
            $xml .= "</url>\n";
        }
        $xml .= '</urlset>';

        return $xml;
    }
}

<?php

namespace App\Services\Billing;

use App\Models\Ad;
use App\Models\FeaturedAdPlan;
use App\Models\Package;
use App\Models\Setting;
use App\Models\Subscription;
use App\Models\Transaction;
use App\Models\User;
use App\Services\Payments\PaymentManager;
use Illuminate\Support\Facades\DB;

/**
 * Creates pending transactions (with tax) and kicks off the chosen gateway.
 */
class CheckoutService
{
    public function __construct(private readonly PaymentManager $payments) {}

    /**
     * @return array{transaction:Transaction, subscription:Subscription, payment:array}
     */
    public function subscription(User $user, Package $package, string $gateway): array
    {
        [$tax, $total] = $this->withTax($package->final_price);

        return DB::transaction(function () use ($user, $package, $gateway, $tax, $total) {
            $transaction = Transaction::create([
                'user_id'       => $user->id,
                'type'          => 'subscription',
                'package_id'    => $package->id,
                'gateway'       => $gateway,
                'amount'        => $package->final_price,
                'tax_amount'    => $tax,
                'total'         => $total,
                'currency_code' => $package->currency_code,
                'status'        => 'pending',
            ]);

            $subscription = Subscription::create([
                'user_id'        => $user->id,
                'package_id'     => $package->id,
                'transaction_id' => $transaction->id,
                'status'         => 'pending',
                'ad_limit'       => $package->is_unlimited ? null : $package->ad_limit,
                'is_unlimited'   => $package->is_unlimited,
            ]);

            $payment = $this->payments->resolve($gateway)->initiate($transaction);

            return compact('transaction', 'subscription', 'payment');
        });
    }

    /**
     * @return array{transaction:Transaction, payment:array}
     */
    public function featured(User $user, Ad $ad, FeaturedAdPlan $plan, string $gateway): array
    {
        [$tax, $total] = $this->withTax($plan->price);

        return DB::transaction(function () use ($user, $ad, $plan, $gateway, $tax, $total) {
            $transaction = Transaction::create([
                'user_id'             => $user->id,
                'type'                => 'featured_ad',
                'ad_id'               => $ad->id,
                'featured_ad_plan_id' => $plan->id,
                'gateway'             => $gateway,
                'amount'              => $plan->price,
                'tax_amount'          => $tax,
                'total'               => $total,
                'currency_code'       => $plan->currency_code,
                'status'              => 'pending',
            ]);

            $payment = $this->payments->resolve($gateway)->initiate($transaction);

            return compact('transaction', 'payment');
        });
    }

    /**
     * @return array{0:int, 1:int} [tax_amount, total] in minor units
     */
    private function withTax(int $amount): array
    {
        $pct = (float) Setting::get('commerce', 'tax_percent', 0);
        $tax = (int) round($amount * $pct / 100);

        return [$tax, $amount + $tax];
    }
}

<?php

namespace App\Services\Billing;

use App\Models\Category;
use App\Models\Setting;
use App\Models\Subscription;
use App\Models\User;
use Illuminate\Validation\ValidationException;

/**
 * Subscription quota enforcement for ad posting. Active only when the
 * `ads.require_subscription` setting is enabled (off by default).
 */
class SubscriptionService
{
    public function isRequired(): bool
    {
        return (bool) Setting::get('ads', 'require_subscription', false);
    }

    /**
     * Return an active subscription that covers $category with remaining quota,
     * or null. Throws when subscriptions are required and none qualifies.
     */
    public function resolveForPosting(User $user, Category $category): ?Subscription
    {
        if (! $this->isRequired()) {
            return null;
        }

        $candidates = $user->subscriptions()->active()->with('package.categories')->get();

        foreach ($candidates as $sub) {
            $covers = $sub->package->categories->isEmpty()
                || $sub->package->categories->contains('id', $category->id);

            if ($covers && $sub->hasQuota()) {
                return $sub;
            }
        }

        throw ValidationException::withMessages([
            'subscription' => ['An active subscription with remaining quota is required to post in this category.'],
        ]);
    }

    public function consume(?Subscription $subscription): void
    {
        if ($subscription && ! $subscription->is_unlimited) {
            $subscription->increment('ads_used');
        }
    }
}

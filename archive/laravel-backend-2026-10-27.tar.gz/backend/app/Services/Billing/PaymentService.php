<?php

namespace App\Services\Billing;

use App\Models\Ad;
use App\Models\Subscription;
use App\Models\Transaction;
use App\Services\Notifications\NotificationService;
use Illuminate\Support\Facades\DB;

/**
 * Fulfils completed payments: activates subscriptions, features ads, issues
 * invoices, and notifies the buyer. Idempotent — safe to call from both the
 * dev confirm endpoint and the gateway webhook.
 */
class PaymentService
{
    public function __construct(
        private readonly InvoiceService $invoices,
        private readonly NotificationService $notifications,
    ) {}

    /**
     * Mark a transaction completed and deliver what was purchased.
     */
    public function fulfil(Transaction $transaction): Transaction
    {
        if ($transaction->isCompleted()) {
            return $transaction; // idempotent
        }

        return DB::transaction(function () use ($transaction) {
            $transaction->update(['status' => 'completed', 'paid_at' => now()]);

            if ($transaction->type === 'subscription') {
                $this->activateSubscription($transaction);
            } elseif ($transaction->type === 'featured_ad') {
                $this->featureAd($transaction);
            }

            $invoice = $this->invoices->generate($transaction);

            $this->notifications->notify(
                $transaction->user,
                'payment.completed',
                'Payment successful',
                $transaction->totalDisplay().' — '.str_replace('_', ' ', $transaction->type),
                ['transaction_id' => $transaction->id, 'invoice_number' => $invoice->number]
            );

            return $transaction->fresh();
        });
    }

    public function fail(Transaction $transaction): Transaction
    {
        if (! $transaction->isCompleted()) {
            $transaction->update(['status' => 'failed']);
        }

        return $transaction;
    }

    public function refund(Transaction $transaction): Transaction
    {
        return DB::transaction(function () use ($transaction) {
            $transaction->update(['status' => 'refunded']);
            $this->invoices->markRefunded($transaction);

            // Revoke what was granted.
            if ($transaction->type === 'subscription') {
                $transaction->subscription?->update(['status' => 'cancelled']);
            } elseif ($transaction->type === 'featured_ad' && $transaction->ad) {
                $transaction->ad->update(['is_featured' => false, 'featured_until' => null]);
            }

            $this->notifications->notify(
                $transaction->user, 'payment.refunded', 'Payment refunded',
                $transaction->totalDisplay().' has been refunded.',
                ['transaction_id' => $transaction->id]
            );

            return $transaction->fresh();
        });
    }

    private function activateSubscription(Transaction $transaction): void
    {
        /** @var Subscription|null $subscription */
        $subscription = $transaction->subscription
            ?? Subscription::where('transaction_id', $transaction->id)->first();

        if (! $subscription) {
            return;
        }

        $package = $subscription->package;
        $subscription->update([
            'status'       => 'active',
            'starts_at'    => now(),
            'ends_at'      => now()->addDays($package->duration_days),
            'ad_limit'     => $package->is_unlimited ? null : $package->ad_limit,
            'is_unlimited' => $package->is_unlimited,
            'ads_used'     => 0,
        ]);
    }

    private function featureAd(Transaction $transaction): void
    {
        $ad = $transaction->ad;
        $plan = $transaction->featuredPlan;
        if (! $ad || ! $plan) {
            return;
        }

        $base = ($ad->featured_until && $ad->featured_until->isFuture()) ? $ad->featured_until : now();
        $ad->update([
            'is_featured'    => true,
            'featured_until' => $base->copy()->addDays($plan->duration_days),
        ]);
    }
}

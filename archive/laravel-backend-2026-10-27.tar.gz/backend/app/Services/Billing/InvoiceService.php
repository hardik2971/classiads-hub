<?php

namespace App\Services\Billing;

use App\Models\Invoice;
use App\Models\Transaction;

class InvoiceService
{
    /**
     * Create (or return existing) invoice for a transaction.
     */
    public function generate(Transaction $transaction): Invoice
    {
        if ($transaction->invoice) {
            return $transaction->invoice;
        }

        return Invoice::create([
            'transaction_id' => $transaction->id,
            'user_id'        => $transaction->user_id,
            'number'         => $this->nextNumber($transaction),
            'subtotal'       => $transaction->amount,
            'tax_amount'     => $transaction->tax_amount,
            'total'          => $transaction->total,
            'currency_code'  => $transaction->currency_code,
            'status'         => 'paid',
            'issued_at'      => now(),
        ]);
    }

    public function markRefunded(Transaction $transaction): void
    {
        $transaction->invoice?->update(['status' => 'refunded']);
    }

    private function nextNumber(Transaction $transaction): string
    {
        return 'INV-'.now()->format('Ymd').'-'.str_pad((string) $transaction->id, 6, '0', STR_PAD_LEFT);
    }
}

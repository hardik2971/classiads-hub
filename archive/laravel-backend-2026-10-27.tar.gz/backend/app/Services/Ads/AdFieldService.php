<?php

namespace App\Services\Ads;

use App\Models\Ad;
use App\Models\Category;
use Illuminate\Validation\ValidationException;

/**
 * Validates and persists category-specific custom-field values for an ad.
 */
class AdFieldService
{
    /**
     * @param  array<string,mixed>  $input  keyed by custom field code
     */
    public function sync(Ad $ad, Category $category, array $input): void
    {
        $fields = $category->customFields()->with('options')->get();
        $errors = [];

        foreach ($fields as $field) {
            $required = $field->pivot->is_required ?? $field->is_required;
            $value    = $input[$field->code] ?? null;

            if ($required && ($value === null || $value === '' || $value === [])) {
                $errors["custom_fields.{$field->code}"] = ["The {$field->name} field is required."];
                continue;
            }

            if ($value === null || $value === '') {
                // Clear any previous value.
                $ad->fieldValues()->where('custom_field_id', $field->id)->delete();
                continue;
            }

            // Validate option-based fields against allowed values.
            if ($field->hasOptions()) {
                $allowed = $field->options->pluck('value')->all();
                $values  = is_array($value) ? $value : [$value];
                foreach ($values as $v) {
                    if (! in_array($v, $allowed, true)) {
                        $errors["custom_fields.{$field->code}"] = ["Invalid option for {$field->name}."];
                    }
                }
            }

            if ($field->type === 'number' && ! is_numeric($value)) {
                $errors["custom_fields.{$field->code}"] = ["The {$field->name} must be a number."];
            }

            if (isset($errors["custom_fields.{$field->code}"])) {
                continue;
            }

            $stored = is_array($value) ? json_encode(array_values($value)) : (string) $value;

            $ad->fieldValues()->updateOrCreate(
                ['custom_field_id' => $field->id],
                ['value' => $stored]
            );
        }

        // Remove values for fields no longer attached to the category.
        $validIds = $fields->pluck('id')->all();
        $ad->fieldValues()->whereNotIn('custom_field_id', $validIds ?: [0])->delete();

        if ($errors) {
            throw ValidationException::withMessages($errors);
        }
    }
}

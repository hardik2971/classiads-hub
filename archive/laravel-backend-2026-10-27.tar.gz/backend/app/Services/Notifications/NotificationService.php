<?php

namespace App\Services\Notifications;

use App\Models\User;
use App\Services\Fcm\FcmService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

/**
 * Central notification fan-out: persists an in-app (DatabaseNotification-compatible)
 * record and pushes to the user's devices via FCM.
 */
class NotificationService
{
    public function __construct(private readonly FcmService $fcm) {}

    /**
     * Notify a single user.
     *
     * @param  array<string,mixed>  $payload  extra data (e.g. deep-link refs)
     */
    public function notify(User $user, string $type, string $title, string $body, array $payload = []): string
    {
        $id = (string) Str::uuid();

        DB::table('notifications')->insert([
            'id'              => $id,
            'type'            => $type,
            'notifiable_type' => User::class,
            'notifiable_id'   => $user->id,
            'data'            => json_encode(array_merge([
                'type'  => $type,
                'title' => $title,
                'body'  => $body,
            ], $payload)),
            'read_at'    => null,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $this->fcm->sendToUser($user, $title, $body, array_merge(['type' => $type], $payload));

        return $id;
    }

    /**
     * Notify many users (returns count notified).
     *
     * @param  iterable<User>  $users
     */
    public function notifyMany(iterable $users, string $type, string $title, string $body, array $payload = []): int
    {
        $count = 0;
        foreach ($users as $user) {
            $this->notify($user, $type, $title, $body, $payload);
            $count++;
        }

        return $count;
    }
}

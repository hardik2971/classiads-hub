<?php

namespace App\Services\Otp;

use App\Models\OtpVerification;
use App\Models\Setting;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;

/**
 * Pluggable OTP issuing/verification.
 *
 * Provider is chosen from settings (otp.provider): firebase | twilio | twofactor | log.
 * For now all providers fall back to "log" delivery (code written to the log) so the
 * full flow is testable without external accounts. Real drivers plug in here later.
 */
class OtpService
{
    public function provider(): string
    {
        return (string) Setting::get('otp', 'provider', 'log');
    }

    public function codeLength(): int
    {
        return (int) Setting::get('otp', 'code_length', 6);
    }

    public function expiryMinutes(): int
    {
        return (int) Setting::get('otp', 'expiry_minutes', 10);
    }

    /**
     * Generate + "send" an OTP for an identifier (email or phone).
     *
     * @return array{otp_id:int, debug_code:?string}
     */
    public function send(string $identifier, string $channel, string $purpose): array
    {
        $code = $this->generateCode();

        // Invalidate previous unconsumed codes for this identifier+purpose.
        OtpVerification::where('identifier', $identifier)
            ->where('purpose', $purpose)
            ->whereNull('consumed_at')
            ->update(['consumed_at' => now()]);

        $otp = OtpVerification::create([
            'identifier' => $identifier,
            'channel'    => $channel,
            'provider'   => $this->provider(),
            'purpose'    => $purpose,
            'code_hash'  => Hash::make($code),
            'expires_at' => now()->addMinutes($this->expiryMinutes()),
        ]);

        $this->deliver($identifier, $channel, $code);

        return [
            'otp_id'     => $otp->id,
            // Exposed only in local/debug so the flow can be tested end-to-end.
            'debug_code' => config('app.debug') ? $code : null,
        ];
    }

    /**
     * Verify a submitted code. Returns true on success and consumes the OTP.
     */
    public function verify(string $identifier, string $purpose, string $code): bool
    {
        $otp = OtpVerification::where('identifier', $identifier)
            ->where('purpose', $purpose)
            ->whereNull('consumed_at')
            ->latest('id')
            ->first();

        if (! $otp || $otp->isExpired() || $otp->attempts >= 5) {
            return false;
        }

        $otp->increment('attempts');

        if (! Hash::check($code, $otp->code_hash)) {
            return false;
        }

        $otp->update(['consumed_at' => now()]);

        return true;
    }

    protected function generateCode(): string
    {
        $len = max(4, min(8, $this->codeLength()));
        $max = (10 ** $len) - 1;

        return str_pad((string) random_int(0, $max), $len, '0', STR_PAD_LEFT);
    }

    protected function deliver(string $identifier, string $channel, string $code): void
    {
        // TODO(phase-3): dispatch to Firebase/Twilio/2Factor drivers based on provider().
        Log::info("[OTP:{$this->provider()}] {$channel} to {$identifier}: code={$code}");
    }
}

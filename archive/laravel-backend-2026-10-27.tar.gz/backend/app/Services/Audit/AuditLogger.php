<?php

namespace App\Services\Audit;

use App\Models\AuditLog;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class AuditLogger
{
    /**
     * Record an admin/system action for accountability.
     *
     * @param  array<string,mixed>  $changes
     */
    public function log(string $action, ?Model $auditable = null, array $changes = []): void
    {
        AuditLog::create([
            'user_id'        => Auth::id(),
            'action'         => $action,
            'auditable_type' => $auditable ? $auditable::class : null,
            'auditable_id'   => $auditable?->getKey(),
            'changes'        => $changes ?: null,
            'ip'             => request()->ip(),
            'created_at'     => now(),
        ]);
    }
}

<?php

namespace App\Services\Ai;

use App\Models\Setting;
use Illuminate\Support\Facades\Log;

/**
 * Optional AI content generation (Google Gemini). Pluggable — driver chosen from
 * settings (ai.provider). Default "stub" produces deterministic placeholder text
 * so the feature is usable without an API key; configure a real key for Gemini.
 */
class AiContentService
{
    public function provider(): string
    {
        return (string) Setting::get('ai', 'provider', 'stub');
    }

    public function isEnabled(): bool
    {
        return $this->provider() !== 'disabled';
    }

    /**
     * Generate content from a prompt.
     *
     * @return array{provider:string, content:string}
     */
    public function generate(string $prompt, string $type = 'description'): array
    {
        return match ($this->provider()) {
            'gemini' => $this->gemini($prompt, $type),
            'disabled' => ['provider' => 'disabled', 'content' => ''],
            default => $this->stub($prompt, $type),
        };
    }

    private function stub(string $prompt, string $type): array
    {
        $content = match ($type) {
            'title'   => 'Great deal: '.\Illuminate\Support\Str::limit($prompt, 50, ''),
            'blog'    => "## ".\Illuminate\Support\Str::limit($prompt, 60, '')."\n\nThis is AI-assisted draft content generated from your prompt. Replace with a real Gemini key to enable full generation.",
            default   => 'AI-assisted description based on: "'.\Illuminate\Support\Str::limit($prompt, 120).'". Configure a Gemini API key for production-grade content.',
        };

        return ['provider' => 'stub', 'content' => $content];
    }

    private function gemini(string $prompt, string $type): array
    {
        $key = Setting::get('ai', 'gemini_api_key');
        if (! $key) {
            Log::warning('[AI] Gemini selected but no API key configured; falling back to stub.');

            return $this->stub($prompt, $type);
        }

        // TODO: call the Gemini generateContent endpoint with $key and $prompt.
        return $this->stub($prompt, $type);
    }
}

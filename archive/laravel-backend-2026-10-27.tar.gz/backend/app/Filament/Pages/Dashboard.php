<?php

namespace App\Filament\Pages;

use App\Filament\Widgets\FeaturedSectionsWidget;
use App\Filament\Widgets\MostViewedMapWidget;
use App\Filament\Widgets\StatsOverviewWidget;
use App\Filament\Widgets\TotalCategoriesChartWidget;
use App\Filament\Widgets\WelcomeWidget;
use Filament\Pages\Dashboard as BasePage;

class Dashboard extends BasePage
{
    /**
     * Twelve-column grid lets us mix narrow (col-4) and wide (col-8) widgets
     * on the same row — needed for the stats-left / featured-right layout.
     */
    public function getColumns(): int | array
    {
        return 12;
    }

    /**
     * Explicit whitelist of the widgets that match the reference mock.
     * Auto-discovered widgets that are NOT on this list are intentionally
     * left out of the dashboard view here.
     */
    public function getWidgets(): array
    {
        return [
            WelcomeWidget::class,
            StatsOverviewWidget::class,
            FeaturedSectionsWidget::class,
            MostViewedMapWidget::class,
            TotalCategoriesChartWidget::class,
        ];
    }
}

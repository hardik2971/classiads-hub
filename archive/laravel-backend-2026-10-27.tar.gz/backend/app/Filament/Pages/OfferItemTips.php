<?php

namespace App\Filament\Pages;

use App\Models\Setting;
use BackedEnum;
use Filament\Actions\Action;
use Filament\Forms\Components\Repeater;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Notifications\Notification;
use Filament\Pages\Page;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use UnitEnum;

class OfferItemTips extends Page implements HasForms
{
    use InteractsWithForms;

    protected string $view = 'filament.pages.offer-item-tips';

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedLightBulb;

    protected static string | UnitEnum | null $navigationGroup = 'Ads Listing';

    protected static ?string $navigationLabel = 'Offer Item Tips';

    protected static ?string $title = 'Tips';

    protected static ?int $navigationSort = 7;

    public ?array $data = [];

    public function mount(): void
    {
        $tips = Setting::get('offer_tips', 'items', null);
        if (is_string($tips)) {
            $tips = json_decode($tips, true) ?: [];
        }

        $this->form->fill([
            'items' => is_array($tips) && ! empty($tips) ? $tips : $this->defaultTips(),
        ]);
    }

    public function form(Schema $schema): Schema
    {
        return $schema
            ->components([
                Repeater::make('items')
                    ->label('')
                    ->schema([
                        Textarea::make('description')
                            ->label('Description')
                            ->required()
                            ->rows(2)
                            ->placeholder('Take necessary precautions when meeting with buyer…')
                            ->maxLength(500),
                        Toggle::make('is_active')
                            ->label('Active')
                            ->default(true),
                    ])
                    ->columns(2)
                    ->reorderable()
                    ->reorderableWithDragAndDrop()
                    ->addActionLabel('+ Add Tip')
                    ->collapsible()
                    ->itemLabel(fn (array $state): ?string => $state['description'] ?? null)
                    ->helperText('* To change the order, drag the rows up & down.'),
            ])
            ->statePath('data');
    }

    protected function getFormActions(): array
    {
        return [
            Action::make('save')
                ->label('Save Tips')
                ->submit('save'),
        ];
    }

    public function save(): void
    {
        $data = $this->form->getState();

        Setting::updateOrCreate(
            ['group' => 'offer_tips', 'key' => 'items'],
            ['value' => json_encode(array_values($data['items'] ?? [])), 'type' => 'json'],
        );

        Notification::make()
            ->title('Tips saved')
            ->success()
            ->send();
    }

    private function defaultTips(): array
    {
        return [
            ['description' => 'Avoid entering UPI PIN when receiving payments.',  'is_active' => true],
            ['description' => 'Never hand over money or products upfront.',       'is_active' => true],
            ['description' => 'Report user about any suspicious activity.',       'is_active' => true],
            ['description' => 'Take necessary precautions when meeting with buyer.', 'is_active' => true],
        ];
    }
}

<?php

namespace App\Filament\Pages\Settings;

use BackedEnum;
use Filament\Pages\Page;
use Filament\Support\Icons\Heroicon;
use Illuminate\Support\Facades\DB;
use UnitEnum;

class SystemStatus extends Page
{
    protected string $view = 'filament.pages.settings.system-status';

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedArrowTopRightOnSquare;

    protected static string | UnitEnum | null $navigationGroup = null;

    protected static bool $shouldRegisterNavigation = false;

    protected static ?string $title = 'System Status';

    protected static ?string $slug = 'system-status';

    public function getViewData(): array
    {
        $checks = [
            ['label' => 'PHP version',         'value' => PHP_VERSION,                                            'ok' => version_compare(PHP_VERSION, '8.2.0', '>=')],
            ['label' => 'Laravel version',     'value' => app()->version(),                                       'ok' => true],
            ['label' => 'Environment',         'value' => app()->environment(),                                   'ok' => true],
            ['label' => 'Debug mode',          'value' => config('app.debug') ? 'On' : 'Off',                     'ok' => ! config('app.debug') || app()->environment('local')],
            ['label' => 'Database connection', 'value' => $this->dbStatus(),                                      'ok' => $this->dbConnected()],
            ['label' => 'Cache driver',        'value' => config('cache.default'),                                'ok' => true],
            ['label' => 'Queue driver',        'value' => config('queue.default'),                                'ok' => true],
            ['label' => 'Mail driver',         'value' => config('mail.default'),                                 'ok' => true],
            ['label' => 'Storage path writable','value'=> is_writable(storage_path()) ? 'Yes' : 'No',             'ok' => is_writable(storage_path())],
        ];

        return ['checks' => $checks];
    }

    private function dbStatus(): string
    {
        try {
            DB::connection()->getPdo();
            return DB::connection()->getDatabaseName();
        } catch (\Throwable $e) {
            return 'Disconnected';
        }
    }

    private function dbConnected(): bool
    {
        try {
            DB::connection()->getPdo();
            return true;
        } catch (\Throwable) {
            return false;
        }
    }
}

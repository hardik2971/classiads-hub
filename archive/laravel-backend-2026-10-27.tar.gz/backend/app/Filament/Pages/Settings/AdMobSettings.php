<?php

namespace App\Filament\Pages\Settings;

use App\Filament\Pages\Settings\Concerns\PersistsToSettingsTable;
use BackedEnum;
use Filament\Schemas\Components\Section;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Pages\Page;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use UnitEnum;

class AdMobSettings extends Page implements HasForms
{
    use InteractsWithForms;
    use PersistsToSettingsTable;

    protected string $view = 'filament.pages.settings.form';

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedRectangleStack;

    protected static string | UnitEnum | null $navigationGroup = null;

    protected static bool $shouldRegisterNavigation = false;

    protected static ?string $title = 'AdMob Settings';

    protected static ?string $slug = 'ad-mob-settings';

    protected function group(): string { return 'admob'; }

    protected function keys(): array
    {
        return [
            'enabled'                  => 'bool',
            'android_app_id'           => 'string',
            'ios_app_id'               => 'string',
            'android_banner_unit'      => 'string',
            'ios_banner_unit'          => 'string',
            'android_interstitial_unit'=> 'string',
            'ios_interstitial_unit'    => 'string',
            'frequency_cap'            => 'int',
        ];
    }

    public function form(Schema $schema): Schema
    {
        return $schema
            ->components([
                Section::make('Master switch')
                    ->schema([
                        Toggle::make('enabled')->label('Show AdMob banners in mobile app'),
                    ]),

                Section::make('Android')
                    ->schema([
                        TextInput::make('android_app_id')->label('App ID')->placeholder('ca-app-pub-…~…'),
                        TextInput::make('android_banner_unit')->label('Banner Ad Unit ID'),
                        TextInput::make('android_interstitial_unit')->label('Interstitial Ad Unit ID'),
                    ])->columns(3),

                Section::make('iOS')
                    ->schema([
                        TextInput::make('ios_app_id')->label('App ID')->placeholder('ca-app-pub-…~…'),
                        TextInput::make('ios_banner_unit')->label('Banner Ad Unit ID'),
                        TextInput::make('ios_interstitial_unit')->label('Interstitial Ad Unit ID'),
                    ])->columns(3),

                Section::make('Behavior')
                    ->schema([
                        TextInput::make('frequency_cap')
                            ->label('Interstitial frequency cap (per session)')
                            ->numeric()
                            ->minValue(0)
                            ->maxValue(20)
                            ->default(3),
                    ]),
            ])
            ->statePath('data');
    }
}

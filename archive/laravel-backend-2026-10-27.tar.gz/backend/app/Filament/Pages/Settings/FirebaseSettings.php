<?php

namespace App\Filament\Pages\Settings;

use App\Filament\Pages\Settings\Concerns\PersistsToSettingsTable;
use BackedEnum;
use Filament\Schemas\Components\Section;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Pages\Page;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use UnitEnum;

class FirebaseSettings extends Page implements HasForms
{
    use InteractsWithForms;
    use PersistsToSettingsTable;

    protected string $view = 'filament.pages.settings.form';

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedCloud;

    protected static string | UnitEnum | null $navigationGroup = null;

    protected static bool $shouldRegisterNavigation = false;

    protected static ?string $title = 'Firebase Settings';

    protected static ?string $slug = 'firebase-settings';

    protected function group(): string { return 'firebase'; }

    protected function keys(): array
    {
        return [
            'api_key'                => 'string',
            'auth_domain'            => 'string',
            'project_id'             => 'string',
            'storage_bucket'         => 'string',
            'messaging_sender_id'    => 'string',
            'app_id'                 => 'string',
            'measurement_id'         => 'string',
            'vapid_key'              => 'string',
            'service_account_json'   => 'string',
        ];
    }

    public function form(Schema $schema): Schema
    {
        return $schema
            ->components([
                Section::make('Web SDK config')
                    ->description('Required by the admin chat to enable live FCM refresh.')
                    ->schema([
                        TextInput::make('api_key')->label('Api Key'),
                        TextInput::make('auth_domain')->label('Auth Domain'),
                        TextInput::make('project_id')->label('Project Id'),
                        TextInput::make('storage_bucket')->label('Storage Bucket'),
                        TextInput::make('messaging_sender_id')->label('Messaging Sender Id'),
                        TextInput::make('app_id')->label('App Id'),
                        TextInput::make('measurement_id')->label('Measurement Id'),
                        TextInput::make('vapid_key')->label('VAPID Key')->columnSpanFull(),
                    ])->columns(2),

                Section::make('Server-side (Admin SDK)')
                    ->description('Paste the Service Account JSON for backend push dispatch.')
                    ->schema([
                        Textarea::make('service_account_json')
                            ->label('Service Account JSON')
                            ->rows(8)
                            ->placeholder('{"type":"service_account","project_id":"…"}')
                            ->columnSpanFull(),
                    ]),
            ])
            ->statePath('data');
    }
}

<?php

namespace App\Filament\Pages\Settings;

use BackedEnum;
use Filament\Pages\Page;
use Filament\Support\Icons\Heroicon;
use UnitEnum;

class Settings extends Page
{
    protected string $view = 'filament.pages.settings.hub';

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedCog6Tooth;

    protected static string | UnitEnum | null $navigationGroup = 'Settings';

    protected static ?string $navigationLabel = 'Settings';

    protected static ?string $title = 'Settings';

    protected static ?int $navigationSort = 1;

    /**
     * The 20 settings tiles shown on the hub. Each one is either:
     *   - `route`: a Filament route name (links to an existing resource / page), or
     *   - `url`:   an explicit URL to a custom page.
     */
    public function getViewData(): array
    {
        return [
            'tiles' => [
                ['title' => 'Settings',              'subtitle' => 'Go to settings', 'icon' => 'heroicon-o-cog-8-tooth',          'url' => route('filament.admin.pages.general-settings', absolute: false)],
                ['title' => 'Web Settings',          'subtitle' => 'Go to settings', 'icon' => 'heroicon-o-cog-6-tooth',          'url' => route('filament.admin.pages.web-settings', absolute: false)],
                ['title' => 'Notification Settings', 'subtitle' => 'Go to settings', 'icon' => 'heroicon-o-bell',                 'url' => route('filament.admin.pages.notification-settings', absolute: false)],
                ['title' => 'Watermark Settings',    'subtitle' => 'Go to settings', 'icon' => 'heroicon-o-photo',                'url' => route('filament.admin.pages.watermark-settings', absolute: false)],

                ['title' => 'OTP Provider Settings', 'subtitle' => 'Go to settings',                              'icon' => 'heroicon-o-envelope',     'url' => route('filament.admin.pages.otp-provider-settings', absolute: false)],
                ['title' => 'Import Dummy Data',     'subtitle' => 'Add dummy categories and custom fields',      'icon' => 'heroicon-o-circle-stack', 'url' => route('filament.admin.pages.import-dummy-data', absolute: false)],
                ['title' => 'Admob',                 'subtitle' => 'Go to settings',                              'icon' => 'heroicon-o-rectangle-stack', 'url' => route('filament.admin.pages.ad-mob-settings', absolute: false)],
                ['title' => 'AdSense',               'subtitle' => 'Go to settings',                              'icon' => 'heroicon-o-currency-dollar', 'url' => route('filament.admin.pages.ad-sense-settings', absolute: false)],

                ['title' => 'About Us',              'subtitle' => 'Go to settings', 'icon' => 'heroicon-o-information-circle',   'url' => route('filament.admin.resources.pages.index', absolute: false).'?tableSearchQuery=about'],
                ['title' => 'Terms & Conditions',    'subtitle' => 'Go to settings', 'icon' => 'heroicon-o-document-text',         'url' => route('filament.admin.resources.pages.index', absolute: false).'?tableSearchQuery=terms'],
                ['title' => 'Privacy Policy',        'subtitle' => 'Go to settings', 'icon' => 'heroicon-o-shield-check',          'url' => route('filament.admin.resources.pages.index', absolute: false).'?tableSearchQuery=privacy'],
                ['title' => 'Refund Policy',         'subtitle' => 'Go to settings', 'icon' => 'heroicon-o-shield-check',          'url' => route('filament.admin.resources.pages.index', absolute: false).'?tableSearchQuery=refund'],

                ['title' => 'Contact Us',            'subtitle' => 'Go to settings', 'icon' => 'heroicon-o-identification',        'url' => route('filament.admin.resources.pages.index', absolute: false).'?tableSearchQuery=contact'],
                ['title' => 'Firebase Settings',     'subtitle' => 'Go to settings', 'icon' => 'heroicon-o-cloud',                 'url' => route('filament.admin.pages.firebase-settings', absolute: false)],
                ['title' => 'Languages',             'subtitle' => 'Go to settings', 'icon' => 'heroicon-o-language',              'url' => route('filament.admin.resources.languages.index', absolute: false)],
                ['title' => 'Payment Gateways',      'subtitle' => 'Go to settings', 'icon' => 'heroicon-o-currency-dollar',       'url' => route('filament.admin.resources.payment-gateways.index', absolute: false)],

                ['title' => 'System Status',         'subtitle' => 'Go to settings', 'icon' => 'heroicon-o-arrow-top-right-on-square', 'url' => route('filament.admin.pages.system-status', absolute: false)],
                ['title' => 'Seo-Settings',          'subtitle' => 'Go to settings', 'icon' => 'heroicon-o-magnifying-glass-circle',   'url' => route('filament.admin.resources.seo-metas.index', absolute: false)],
                ['title' => 'File Manager',          'subtitle' => 'Go to settings', 'icon' => 'heroicon-o-folder-open',               'url' => route('filament.admin.pages.file-manager', absolute: false)],
                ['title' => 'Email Templates',       'subtitle' => 'Go to settings', 'icon' => 'heroicon-o-envelope',                   'url' => route('filament.admin.resources.email-templates.index', absolute: false)],
            ],
        ];
    }
}

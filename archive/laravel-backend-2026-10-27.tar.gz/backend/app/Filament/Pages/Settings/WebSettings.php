<?php

namespace App\Filament\Pages\Settings;

use App\Filament\Pages\Settings\Concerns\PersistsToSettingsTable;
use BackedEnum;
use Filament\Schemas\Components\Section;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Pages\Page;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use UnitEnum;

class WebSettings extends Page implements HasForms
{
    use InteractsWithForms;
    use PersistsToSettingsTable;

    protected string $view = 'filament.pages.settings.form';

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedCog6Tooth;

    protected static string | UnitEnum | null $navigationGroup = null;

    protected static bool $shouldRegisterNavigation = false;

    protected static ?string $title = 'Web Settings';

    protected static ?string $slug = 'web-settings';

    protected function group(): string { return 'web'; }

    protected function keys(): array
    {
        return [
            'public_url'         => 'string',
            'meta_title'         => 'string',
            'meta_description'   => 'string',
            'meta_keywords'      => 'string',
            'analytics_id'       => 'string',
            'show_blog_section'  => 'bool',
            'show_jobs_section'  => 'bool',
        ];
    }

    public function form(Schema $schema): Schema
    {
        return $schema
            ->components([
                Section::make('Public site')
                    ->schema([
                        TextInput::make('public_url')->label('Public URL')->url()->placeholder('https://classify.example.com'),
                        TextInput::make('analytics_id')->label('Google Analytics ID')->placeholder('G-XXXXXXX'),
                        TextInput::make('meta_title')->label('Default Meta Title')->columnSpanFull(),
                        Textarea::make('meta_description')->label('Default Meta Description')->rows(2)->columnSpanFull(),
                        Textarea::make('meta_keywords')->label('Default Meta Keywords')->rows(2)->columnSpanFull(),

                        \Filament\Forms\Components\Toggle::make('show_blog_section')->label('Show Blog section'),
                        \Filament\Forms\Components\Toggle::make('show_jobs_section')->label('Show Jobs section'),
                    ])->columns(2),
            ])
            ->statePath('data');
    }
}

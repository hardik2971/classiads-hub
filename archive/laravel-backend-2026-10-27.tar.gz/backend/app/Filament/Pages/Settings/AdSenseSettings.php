<?php

namespace App\Filament\Pages\Settings;

use App\Filament\Pages\Settings\Concerns\PersistsToSettingsTable;
use BackedEnum;
use Filament\Schemas\Components\Section;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Pages\Page;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use UnitEnum;

class AdSenseSettings extends Page implements HasForms
{
    use InteractsWithForms;
    use PersistsToSettingsTable;

    protected string $view = 'filament.pages.settings.form';

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedCurrencyDollar;

    protected static string | UnitEnum | null $navigationGroup = null;

    protected static bool $shouldRegisterNavigation = false;

    protected static ?string $title = 'AdSense Settings';

    protected static ?string $slug = 'ad-sense-settings';

    protected function group(): string { return 'adsense'; }

    protected function keys(): array
    {
        return [
            'enabled'         => 'bool',
            'publisher_id'    => 'string',
            'header_slot_id'  => 'string',
            'sidebar_slot_id' => 'string',
            'footer_slot_id'  => 'string',
        ];
    }

    public function form(Schema $schema): Schema
    {
        return $schema
            ->components([
                Section::make('AdSense')
                    ->schema([
                        Toggle::make('enabled')->label('Show AdSense slots on web'),

                        TextInput::make('publisher_id')
                            ->label('Publisher ID')
                            ->placeholder('ca-pub-XXXXXXXXXXXXXXXX')
                            ->columnSpanFull(),

                        TextInput::make('header_slot_id')->label('Header slot ID'),
                        TextInput::make('sidebar_slot_id')->label('Sidebar slot ID'),
                        TextInput::make('footer_slot_id')->label('Footer slot ID'),
                    ])->columns(3),
            ])
            ->statePath('data');
    }
}

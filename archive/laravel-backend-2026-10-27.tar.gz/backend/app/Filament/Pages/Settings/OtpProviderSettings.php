<?php

namespace App\Filament\Pages\Settings;

use App\Filament\Pages\Settings\Concerns\PersistsToSettingsTable;
use BackedEnum;
use Filament\Schemas\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Pages\Page;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use UnitEnum;

class OtpProviderSettings extends Page implements HasForms
{
    use InteractsWithForms;
    use PersistsToSettingsTable;

    protected string $view = 'filament.pages.settings.form';

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedEnvelope;

    protected static string | UnitEnum | null $navigationGroup = null;

    protected static bool $shouldRegisterNavigation = false;

    protected static ?string $title = 'OTP Provider Settings';

    protected static ?string $slug = 'otp-provider-settings';

    protected function group(): string { return 'otp'; }

    protected function keys(): array
    {
        return [
            'provider'             => 'string',
            'twilio_sid'           => 'string',
            'twilio_auth_token'    => 'string',
            'twilio_from'          => 'string',
            'twofactor_api_key'    => 'string',
            'firebase_project_id'  => 'string',
            'otp_length'           => 'int',
            'otp_expiry_minutes'   => 'int',
        ];
    }

    public function form(Schema $schema): Schema
    {
        return $schema
            ->components([
                Section::make('Provider')
                    ->schema([
                        Select::make('provider')
                            ->options([
                                'firebase'   => 'Firebase',
                                'twilio'     => 'Twilio',
                                '2factor'    => '2Factor',
                            ])
                            ->required()
                            ->live(),

                        TextInput::make('otp_length')
                            ->label('OTP Length')
                            ->numeric()
                            ->minValue(4)
                            ->maxValue(8)
                            ->default(6),

                        TextInput::make('otp_expiry_minutes')
                            ->label('Expiry (minutes)')
                            ->numeric()
                            ->minValue(1)
                            ->maxValue(60)
                            ->default(10),
                    ])->columns(3),

                Section::make('Twilio')
                    ->visible(fn (callable $get) => $get('provider') === 'twilio')
                    ->schema([
                        TextInput::make('twilio_sid')->label('Account SID'),
                        TextInput::make('twilio_auth_token')->label('Auth Token')->password()->revealable(),
                        TextInput::make('twilio_from')->label('From Number (+E.164)'),
                    ])->columns(2),

                Section::make('2Factor')
                    ->visible(fn (callable $get) => $get('provider') === '2factor')
                    ->schema([
                        TextInput::make('twofactor_api_key')->label('API Key')->password()->revealable(),
                    ]),

                Section::make('Firebase')
                    ->visible(fn (callable $get) => $get('provider') === 'firebase')
                    ->schema([
                        TextInput::make('firebase_project_id')->label('Project ID'),
                    ]),
            ])
            ->statePath('data');
    }
}

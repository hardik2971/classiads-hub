<?php

namespace App\Filament\Pages\Settings;

use App\Filament\Pages\Settings\Concerns\PersistsToSettingsTable;
use BackedEnum;
use Filament\Forms\Components\FileUpload;
use Filament\Schemas\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Pages\Page;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use UnitEnum;

class WatermarkSettings extends Page implements HasForms
{
    use InteractsWithForms;
    use PersistsToSettingsTable;

    protected string $view = 'filament.pages.settings.form';

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedPhoto;

    protected static string | UnitEnum | null $navigationGroup = null;

    protected static bool $shouldRegisterNavigation = false;

    protected static ?string $title = 'Watermark Settings';

    protected static ?string $slug = 'watermark-settings';

    protected function group(): string { return 'watermark'; }

    protected function keys(): array
    {
        return [
            'enabled'        => 'bool',
            'image_path'     => 'string',
            'position'       => 'string',
            'opacity'        => 'int',
            'margin_px'      => 'int',
        ];
    }

    public function form(Schema $schema): Schema
    {
        return $schema
            ->components([
                Section::make('Watermark')
                    ->schema([
                        Toggle::make('enabled')->label('Apply watermark on new uploads'),

                        FileUpload::make('image_path')
                            ->label('Watermark image (transparent PNG)')
                            ->image()
                            ->directory('watermark')
                            ->columnSpanFull(),

                        Select::make('position')
                            ->options([
                                'top-left'      => 'Top Left',
                                'top-right'     => 'Top Right',
                                'bottom-left'   => 'Bottom Left',
                                'bottom-right'  => 'Bottom Right',
                                'center'        => 'Center',
                            ])
                            ->default('bottom-right'),

                        TextInput::make('opacity')
                            ->label('Opacity (0–100)')
                            ->numeric()
                            ->minValue(0)
                            ->maxValue(100)
                            ->default(70),

                        TextInput::make('margin_px')
                            ->label('Margin (px)')
                            ->numeric()
                            ->minValue(0)
                            ->maxValue(200)
                            ->default(16),
                    ])->columns(2),
            ])
            ->statePath('data');
    }
}

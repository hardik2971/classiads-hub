<?php

namespace App\Filament\Pages\Settings;

use App\Filament\Pages\Settings\Concerns\PersistsToSettingsTable;
use BackedEnum;
use Filament\Forms\Components\FileUpload;
use Filament\Schemas\Components\Section;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Pages\Page;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use UnitEnum;

class GeneralSettings extends Page implements HasForms
{
    use InteractsWithForms;
    use PersistsToSettingsTable;

    protected string $view = 'filament.pages.settings.form';

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedCog8Tooth;

    protected static string | UnitEnum | null $navigationGroup = null;

    protected static bool $shouldRegisterNavigation = false;

    protected static ?string $title = 'Settings';

    protected static ?string $slug = 'general-settings';

    protected function group(): string { return 'general'; }

    protected function keys(): array
    {
        return [
            'site_name'        => 'string',
            'tagline'          => 'string',
            'admin_email'      => 'string',
            'support_email'    => 'string',
            'support_phone'    => 'string',
            'logo_path'        => 'string',
            'favicon_path'     => 'string',
            'maintenance_mode' => 'bool',
        ];
    }

    public function form(Schema $schema): Schema
    {
        return $schema
            ->components([
                Section::make('General')
                    ->schema([
                        TextInput::make('site_name')->label('Site Name')->required(),
                        TextInput::make('tagline')->label('Tagline'),
                        TextInput::make('admin_email')->label('Admin Email')->email()->required(),
                        TextInput::make('support_email')->label('Support Email')->email(),
                        TextInput::make('support_phone')->label('Support Phone')->tel(),
                        Toggle::make('maintenance_mode')->label('Maintenance Mode'),
                    ])->columns(2),

                Section::make('Branding')
                    ->schema([
                        FileUpload::make('logo_path')->label('Logo')->image()->directory('branding'),
                        FileUpload::make('favicon_path')->label('Favicon')->image()->directory('branding'),
                    ])->columns(2),
            ])
            ->statePath('data');
    }
}

<?php

namespace App\Filament\Pages\Settings;

use BackedEnum;
use Filament\Notifications\Notification;
use Filament\Pages\Page;
use Filament\Support\Icons\Heroicon;
use Illuminate\Support\Facades\Storage;
use UnitEnum;

class FileManager extends Page
{
    protected string $view = 'filament.pages.settings.file-manager';

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedFolderOpen;

    protected static string | UnitEnum | null $navigationGroup = null;

    protected static bool $shouldRegisterNavigation = false;

    protected static ?string $title = 'File Manager';

    protected static ?string $slug = 'file-manager';

    public string $currentPath = '';

    public function getViewData(): array
    {
        $disk = Storage::disk('public');
        $directories = $disk->directories($this->currentPath);
        $files = collect($disk->files($this->currentPath))
            ->map(fn (string $path) => [
                'path' => $path,
                'name' => basename($path),
                'size' => $disk->size($path),
                'url'  => $disk->url($path),
            ])
            ->all();

        return [
            'directories' => $directories,
            'files'       => $files,
        ];
    }

    public function open(string $dir): void
    {
        $this->currentPath = $dir;
    }

    public function up(): void
    {
        if ($this->currentPath === '') return;
        $parts = explode('/', $this->currentPath);
        array_pop($parts);
        $this->currentPath = implode('/', $parts);
    }

    public function deleteFile(string $path): void
    {
        Storage::disk('public')->delete($path);
        Notification::make()->title('File deleted')->success()->send();
    }
}

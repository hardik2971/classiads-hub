<?php

namespace App\Filament\Pages\Settings;

use App\Filament\Pages\Settings\Concerns\PersistsToSettingsTable;
use BackedEnum;
use Filament\Schemas\Components\Section;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Pages\Page;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use UnitEnum;

class NotificationSettings extends Page implements HasForms
{
    use InteractsWithForms;
    use PersistsToSettingsTable;

    protected string $view = 'filament.pages.settings.form';

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedBell;

    protected static string | UnitEnum | null $navigationGroup = null;

    protected static bool $shouldRegisterNavigation = false;

    protected static ?string $title = 'Notification Settings';

    protected static ?string $slug = 'notification-settings';

    protected function group(): string { return 'notifications'; }

    protected function keys(): array
    {
        return [
            'push_enabled'           => 'bool',
            'email_enabled'          => 'bool',
            'sms_enabled'            => 'bool',
            'notify_on_new_ad'       => 'bool',
            'notify_on_offer'        => 'bool',
            'notify_on_chat'         => 'bool',
            'notify_on_review'       => 'bool',
            'admin_digest_email_to'  => 'string',
        ];
    }

    public function form(Schema $schema): Schema
    {
        return $schema
            ->components([
                Section::make('Channels')
                    ->schema([
                        Toggle::make('push_enabled')->label('Push notifications (FCM)')->default(true),
                        Toggle::make('email_enabled')->label('Email notifications')->default(true),
                        Toggle::make('sms_enabled')->label('SMS notifications'),
                    ])->columns(3),

                Section::make('Trigger events')
                    ->schema([
                        Toggle::make('notify_on_new_ad')->label('On new ad'),
                        Toggle::make('notify_on_offer')->label('On offer'),
                        Toggle::make('notify_on_chat')->label('On chat message'),
                        Toggle::make('notify_on_review')->label('On review'),
                    ])->columns(2),

                Section::make('Admin digest')
                    ->schema([
                        TextInput::make('admin_digest_email_to')
                            ->label('Send daily digest to')
                            ->email()
                            ->placeholder('admin@example.com'),
                    ]),
            ])
            ->statePath('data');
    }
}

<?php

namespace App\Filament\Pages\Settings\Concerns;

use App\Models\Setting;
use Filament\Notifications\Notification;

/**
 * Shared persistence layer for every per-area settings page. Subclasses
 * declare a `group` and `keys()` map; this trait handles read/write to
 * the `settings` table + flash notifications.
 */
trait PersistsToSettingsTable
{
    /** Subclasses define the storage group (e.g. "web", "admob"). */
    abstract protected function group(): string;

    /**
     * Map of form-key → setting-type. Drives both load+save.
     * Example: ['site_name' => 'string', 'maintenance_mode' => 'bool']
     */
    abstract protected function keys(): array;

    public ?array $data = [];

    public function mount(): void
    {
        $values = [];
        foreach (array_keys($this->keys()) as $key) {
            $values[$key] = Setting::get($this->group(), $key, null);
        }
        $this->form->fill($values);
    }

    public function save(): void
    {
        $data = $this->form->getState();
        foreach ($this->keys() as $key => $type) {
            $raw = $data[$key] ?? null;
            $value = match ($type) {
                'bool'  => $raw ? '1' : '0',
                'int'   => (string) (int) $raw,
                default => (string) ($raw ?? ''),
            };
            Setting::updateOrCreate(
                ['group' => $this->group(), 'key' => $key],
                ['value' => $value, 'type' => $type],
            );
        }

        Notification::make()->title('Settings saved')->success()->send();
    }

    protected function getFormActions(): array
    {
        return [
            \Filament\Actions\Action::make('save')
                ->label('Save')
                ->submit('save'),
        ];
    }
}

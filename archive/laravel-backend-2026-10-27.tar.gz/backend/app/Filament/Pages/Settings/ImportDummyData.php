<?php

namespace App\Filament\Pages\Settings;

use BackedEnum;
use Filament\Notifications\Notification;
use Filament\Pages\Page;
use Filament\Support\Icons\Heroicon;
use Illuminate\Support\Facades\Artisan;
use UnitEnum;

class ImportDummyData extends Page
{
    protected string $view = 'filament.pages.settings.import-dummy';

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedCircleStack;

    protected static string | UnitEnum | null $navigationGroup = null;

    protected static bool $shouldRegisterNavigation = false;

    protected static ?string $title = 'Import Dummy Data';

    protected static ?string $slug = 'import-dummy-data';

    public function importCategories(): void
    {
        try {
            Artisan::call('db:seed', ['--class' => 'CategorySeeder', '--force' => true]);
            Notification::make()->title('Categories seeded')->success()->send();
        } catch (\Throwable $e) {
            Notification::make()->title('Seeder not found — wire CategorySeeder to make this work.')->warning()->send();
        }
    }

    public function importCustomFields(): void
    {
        try {
            Artisan::call('db:seed', ['--class' => 'CustomFieldSeeder', '--force' => true]);
            Notification::make()->title('Custom fields seeded')->success()->send();
        } catch (\Throwable $e) {
            Notification::make()->title('Seeder not found — wire CustomFieldSeeder to make this work.')->warning()->send();
        }
    }

    public function importLocations(): void
    {
        try {
            Artisan::call('db:seed', ['--class' => 'LocationSeeder', '--force' => true]);
            Notification::make()->title('Countries / states / cities seeded')->success()->send();
        } catch (\Throwable $e) {
            Notification::make()->title('Seeder not found — wire LocationSeeder to make this work.')->warning()->send();
        }
    }
}

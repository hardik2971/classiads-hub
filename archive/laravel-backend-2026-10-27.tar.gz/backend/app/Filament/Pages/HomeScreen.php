<?php

namespace App\Filament\Pages;

use App\Models\Category;
use App\Models\Setting;
use BackedEnum;
use Filament\Actions\Action;
use Filament\Forms\Components\Select;
use Filament\Schemas\Components\Grid;
use Filament\Schemas\Components\Section;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Notifications\Notification;
use Filament\Pages\Page;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use UnitEnum;

class HomeScreen extends Page implements HasForms
{
    use InteractsWithForms;

    protected string $view = 'filament.pages.home-screen';

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedHome;

    protected static string | UnitEnum | null $navigationGroup = 'Ads Listing';

    protected static ?string $navigationLabel = 'Home Screen';

    protected static ?string $title = 'Home Screen Sections';

    protected static ?int $navigationSort = 5;

    public ?array $data = [];

    public function mount(): void
    {
        $popular = Setting::get('home', 'popular_categories', null);
        if (is_string($popular)) {
            $popular = json_decode($popular, true) ?: [];
        }

        $this->form->fill([
            'show_all_categories'    => (bool) Setting::get('home', 'show_all_categories', true),
            'show_slider'            => (bool) Setting::get('home', 'show_slider', true),
            'show_popular_categories'=> (bool) Setting::get('home', 'show_popular_categories', true),
            'show_featured_section'  => (bool) Setting::get('home', 'show_featured_section', true),
            'popular_category_ids'   => is_array($popular) ? $popular : [],
        ]);
    }

    public function form(Schema $schema): Schema
    {
        return $schema
            ->components([
                Section::make('Section Visibility')
                    ->schema([
                        Grid::make(4)
                            ->schema([
                                Toggle::make('show_all_categories')
                                    ->label('All Categories')
                                    ->inline(false),
                                Toggle::make('show_slider')
                                    ->label('Slider')
                                    ->inline(false),
                                Toggle::make('show_popular_categories')
                                    ->label('Popular Categories')
                                    ->inline(false),
                                Toggle::make('show_featured_section')
                                    ->label('Featured Section')
                                    ->inline(false),
                            ]),
                    ]),

                Section::make('Popular Categories')
                    ->description('Search and select categories to add to the popular list. Drag rows in the Categories page to change order.')
                    ->schema([
                        Select::make('popular_category_ids')
                            ->label('Categories')
                            ->multiple()
                            ->searchable()
                            ->preload()
                            ->options(fn () => Category::query()
                                ->orderBy('name')
                                ->pluck('name', 'id')
                                ->all())
                            ->helperText('Pick categories shown in the Popular Categories block on mobile/web home.'),
                    ]),
            ])
            ->statePath('data');
    }

    protected function getFormActions(): array
    {
        return [
            Action::make('save')
                ->label('Save Home Screen')
                ->submit('save'),
        ];
    }

    public function save(): void
    {
        $data = $this->form->getState();

        foreach (['show_all_categories', 'show_slider', 'show_popular_categories', 'show_featured_section'] as $key) {
            Setting::updateOrCreate(
                ['group' => 'home', 'key' => $key],
                ['value' => $data[$key] ? '1' : '0', 'type' => 'bool'],
            );
        }

        Setting::updateOrCreate(
            ['group' => 'home', 'key' => 'popular_categories'],
            ['value' => json_encode(array_values($data['popular_category_ids'] ?? [])), 'type' => 'json'],
        );

        Notification::make()
            ->title('Home screen sections saved')
            ->success()
            ->send();
    }
}

<?php

namespace App\Filament\Pages;

use App\Models\Ad;
use App\Models\PushNotification;
use App\Models\User;
use BackedEnum;
use Filament\Facades\Filament;
use Filament\Notifications\Notification;
use Filament\Pages\Page;
use Filament\Support\Icons\Heroicon;
use UnitEnum;

class SendNotification extends Page
{
    protected string $view = 'filament.pages.send-notification';

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedBell;

    protected static string | UnitEnum | null $navigationGroup = null;

    protected static ?string $navigationLabel = 'Notification';

    protected static ?string $title = 'Send Notification';

    protected static ?int $navigationSort = 3;

    /** ───── Form state ───── */
    public string $title_input = '';
    public string $message = '';
    public string $select_user = 'all';     // 'all' | 'role' | 'user'
    public bool   $include_image = false;
    public ?int   $advertisement_id = null;

    /** ───── Picker state ───── */
    public string $userSearch = '';
    public array  $selectedUserIds = [];

    /** ───── History state ───── */
    public string $historySearch = '';
    public array  $selectedHistoryIds = [];

    public function submit(): void
    {
        $this->validate([
            'title_input' => 'required|string|max:191',
            'message'     => 'required|string',
        ]);

        $userIds = array_values(array_unique(array_map('intval', $this->selectedUserIds)));
        $target  = match (true) {
            count($userIds) === 0 => 'all',
            count($userIds) === 1 => 'user',
            default               => 'user', // multi-user via target_user_ids
        };

        PushNotification::create([
            'title'             => $this->title_input,
            'body'              => $this->message,
            'image_path'        => null, // wired when Filament FileUpload is added in next pass
            'target'            => $target,
            'target_user_id'    => $userIds[0] ?? null,
            'target_user_ids'   => count($userIds) > 1 ? $userIds : null,
            'item_type'         => $this->advertisement_id ? Ad::class : null,
            'item_id'           => $this->advertisement_id,
            'sent_by'           => Filament::auth()->id(),
            'recipients_count'  => count($userIds) > 0
                ? count($userIds)
                : User::role('customer')->count(),
        ]);

        // TODO: dispatch the FCM payload via Firebase Admin SDK.
        // For now we persist the row so it appears in history immediately.

        $this->reset(['title_input', 'message', 'include_image', 'advertisement_id', 'selectedUserIds']);

        Notification::make()
            ->title('Notification queued')
            ->success()
            ->send();
    }

    public function deleteSelectedHistory(): void
    {
        if (empty($this->selectedHistoryIds)) {
            return;
        }
        PushNotification::whereIn('id', $this->selectedHistoryIds)->delete();
        $this->selectedHistoryIds = [];
        Notification::make()->title('Notifications deleted')->success()->send();
    }

    public function deleteHistoryRow(int $id): void
    {
        PushNotification::where('id', $id)->delete();
        Notification::make()->title('Notification deleted')->success()->send();
    }

    public function getViewData(): array
    {
        $usersPage = User::query()
            ->select('id', 'name', 'phone')
            ->when($this->userSearch !== '', fn ($q) => $q
                ->where('name', 'like', "%{$this->userSearch}%")
                ->orWhere('phone', 'like', "%{$this->userSearch}%"))
            ->orderByDesc('id')
            ->paginate(10, ['*'], 'usersPage');

        $historyPage = PushNotification::query()
            ->when($this->historySearch !== '', fn ($q) => $q
                ->where('title', 'like', "%{$this->historySearch}%")
                ->orWhere('body', 'like', "%{$this->historySearch}%"))
            ->orderByDesc('id')
            ->paginate(10, ['*'], 'historyPage');

        return [
            'users'         => $usersPage,
            'history'       => $historyPage,
            'targetOptions' => [
                'all'     => 'All',
                'role'    => 'By role',
                'user'    => 'Specific users (picked at right)',
            ],
            'adOptions'     => Ad::query()
                ->orderByDesc('id')
                ->limit(200)
                ->pluck('title', 'id')
                ->all(),
        ];
    }
}

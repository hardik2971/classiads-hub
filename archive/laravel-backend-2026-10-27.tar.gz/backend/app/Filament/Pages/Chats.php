<?php

namespace App\Filament\Pages;

use App\Models\Ad;
use App\Models\Conversation;
use App\Models\Message;
use BackedEnum;
use Filament\Facades\Filament;
use Filament\Pages\Page;
use Filament\Support\Icons\Heroicon;
use Illuminate\Contracts\View\View;
use Illuminate\Database\Eloquent\Collection;
use UnitEnum;

class Chats extends Page
{
    protected string $view = 'filament.pages.chats';

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedChatBubbleLeftRight;

    protected static ?string $navigationLabel = 'Chats';

    protected static ?string $title = 'Message';

    protected static string | UnitEnum | null $navigationGroup = null;

    protected static ?int $navigationSort = 2;

    /** Livewire state ----------------------------------------------------- */
    public ?int $selectedAdId = null;

    public ?int $selectedConversationId = null;

    public string $productSearch = '';

    public string $chatSearch = '';

    public string $newMessage = '';

    public function mount(): void
    {
        // Default the right pane to the first conversation so the screen
        // never opens empty.
        $first = $this->productsQuery()->first();
        if ($first) {
            $this->selectedAdId = $first->id;
            $convo = $this->conversationsForAd($first->id)->first();
            if ($convo) {
                $this->selectedConversationId = $convo->id;
            }
        }
    }

    public function selectProduct(int $adId): void
    {
        $this->selectedAdId = $adId;
        $first = $this->conversationsForAd($adId)->first();
        $this->selectedConversationId = $first?->id;
    }

    public function selectConversation(int $conversationId): void
    {
        $this->selectedConversationId = $conversationId;
        Conversation::where('id', $conversationId)
            ->update(['seller_unread' => 0]);
    }

    public function sendMessage(): void
    {
        $body = trim($this->newMessage);
        if ($body === '' || ! $this->selectedConversationId) {
            return;
        }

        Message::create([
            'conversation_id' => $this->selectedConversationId,
            'sender_id'       => Filament::auth()->id(),
            'body'            => $body,
            'type'            => 'text',
        ]);

        Conversation::where('id', $this->selectedConversationId)->update([
            'last_message'    => $body,
            'last_message_at' => now(),
            'buyer_unread'    => \DB::raw('buyer_unread + 1'),
        ]);

        $this->newMessage = '';
    }

    /** View data ---------------------------------------------------------- */

    public function getViewData(): array
    {
        return [
            'products'         => $this->productsQuery()->limit(40)->get(),
            'conversations'    => $this->selectedAdId
                ? $this->conversationsForAd($this->selectedAdId)->limit(80)->get()
                : new Collection,
            'conversationStats'=> $this->conversationStats(),
            'activeConvo'      => $this->selectedConversationId
                ? Conversation::with(['buyer', 'seller', 'ad.images'])->find($this->selectedConversationId)
                : null,
            'messages'         => $this->selectedConversationId
                ? Message::query()
                    ->where('conversation_id', $this->selectedConversationId)
                    ->with('sender')
                    ->orderBy('created_at')
                    ->limit(200)
                    ->get()
                : new Collection,
            'currentUserId'    => Filament::auth()->id(),
        ];
    }

    private function productsQuery()
    {
        // Only show ads that actually have a conversation, ordered by latest activity.
        // Use a subquery so we avoid `only_full_group_by` violations on MySQL
        // strict mode: aggregate the conversations' newest activity per ad,
        // then join back to the ads table for `ads.*`.
        $latest = \DB::table('conversations')
            ->select('ad_id', \DB::raw('MAX(last_message_at) as latest_at'))
            ->groupBy('ad_id');

        return Ad::query()
            ->joinSub($latest, 'recent', 'recent.ad_id', '=', 'ads.id')
            ->with('images')
            ->when($this->productSearch !== '', fn ($q) =>
                $q->where('ads.title', 'like', "%{$this->productSearch}%"))
            ->orderByRaw('recent.latest_at DESC');
    }

    private function conversationsForAd(int $adId)
    {
        return Conversation::query()
            ->where('ad_id', $adId)
            ->with(['buyer', 'seller', 'ad.images'])
            ->when($this->chatSearch !== '', function ($q) {
                $q->where(function ($q) {
                    $q->whereHas('buyer', fn ($q) => $q->where('name', 'like', "%{$this->chatSearch}%"))
                        ->orWhere('last_message', 'like', "%{$this->chatSearch}%");
                });
            })
            ->orderByDesc('last_message_at');
    }

    private function conversationStats(): array
    {
        if (! $this->selectedAdId) {
            return ['total' => 0, 'unread' => 0];
        }

        return [
            'total'  => Conversation::where('ad_id', $this->selectedAdId)->count(),
            'unread' => (int) Conversation::where('ad_id', $this->selectedAdId)
                ->sum('seller_unread'),
        ];
    }
}

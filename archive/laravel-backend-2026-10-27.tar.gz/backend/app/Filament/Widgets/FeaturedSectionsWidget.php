<?php

namespace App\Filament\Widgets;

use App\Models\FeaturedSection;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Columns\ViewColumn;
use Filament\Tables\Table;
use Filament\Widgets\TableWidget as BaseWidget;

class FeaturedSectionsWidget extends BaseWidget
{
    protected static ?int $sort = 2;

    /**
     * Wide column on `lg`+ so it sits next to the narrow Stats grid.
     */
    protected int|string|array $columnSpan = [
        'default' => 12,
        'md' => 12,
        'lg' => 8,
    ];

    protected static ?string $heading = 'Featured Sections';

    public function table(Table $table): Table
    {
        return $table
            ->query(FeaturedSection::query()->orderByDesc('id'))
            ->paginated([10, 25, 50])
            ->defaultPaginationPageOption(3)
            ->searchPlaceholder('Search…')
            ->columns([
                TextColumn::make('id')
                    ->label('ID')
                    ->sortable()
                    ->weight('semibold')
                    ->color('gray'),

                ViewColumn::make('style_preview')
                    ->label('Style')
                    ->view('filament.widgets.featured-sections-style-cell'),

                TextColumn::make('title')
                    ->label('Title')
                    ->searchable()
                    ->weight('medium'),

                TextColumn::make('filter_type')
                    ->label('Filters')
                    ->formatStateUsing(fn (string $state): string => match ($state) {
                        'latest'      => 'Latest Listings',
                        'most_viewed' => 'Most Viewed',
                        'most_liked'  => 'Most Liked',
                        'featured'    => 'Featured Only',
                        'category'    => 'Category Criteria',
                        default       => ucfirst(str_replace('_', ' ', $state)),
                    })
                    ->badge()
                    ->color('gray'),
            ]);
    }
}

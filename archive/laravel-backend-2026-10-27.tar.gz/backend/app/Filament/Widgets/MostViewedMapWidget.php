<?php

namespace App\Filament\Widgets;

use App\Models\Ad;
use Filament\Widgets\Widget;

class MostViewedMapWidget extends Widget
{
    protected string $view = 'filament.widgets.most-viewed-map';

    protected static ?int $sort = 5;

    protected int|string|array $columnSpan = [
        'default' => 'full',
        'md' => 'half',
        'lg' => 6,
    ];

    // Leaflet bootstrap must be in initial DOM, not lazy-loaded.
    protected static bool $isLazy = false;

    /**
     * Top-viewed geo-located ads as map pins.
     *
     * @return array<int, array{lat: float, lng: float, label: string, views: int, slug: string|null}>
     */
    public function getLocations(): array
    {
        return Ad::query()
            ->whereNotNull('latitude')
            ->whereNotNull('longitude')
            ->where('status', 'approved')
            ->orderByDesc('views_count')
            ->limit(500)
            ->get(['id', 'title', 'slug', 'latitude', 'longitude', 'views_count'])
            ->map(fn (Ad $a): array => [
                'lat'   => (float) $a->latitude,
                'lng'   => (float) $a->longitude,
                'label' => $a->title,
                'views' => (int) $a->views_count,
                'slug'  => $a->slug,
            ])
            ->all();
    }
}

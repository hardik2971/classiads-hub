<?php

namespace App\Filament\Widgets;

use App\Models\Ad;
use Filament\Widgets\Widget;

class AdsMapWidget extends Widget
{
    protected string $view = 'filament.widgets.ads-map';

    protected static ?int $sort = 4;

    protected int|string|array $columnSpan = 'full';

    // Render inline (not lazy) so the Leaflet bootstrap script is in the initial DOM.
    protected static bool $isLazy = false;

    /**
     * Geo-located, approved ads as map pins.
     *
     * @return array<int, array{lat: float, lng: float, label: string, slug: string|null}>
     */
    public function getLocations(): array
    {
        return Ad::query()
            ->whereNotNull('latitude')
            ->whereNotNull('longitude')
            ->where('status', 'approved')
            ->latest()
            ->limit(500)
            ->get(['id', 'title', 'slug', 'latitude', 'longitude'])
            ->map(fn (Ad $a): array => [
                'lat' => (float) $a->latitude,
                'lng' => (float) $a->longitude,
                'label' => $a->title,
                'slug' => $a->slug,
            ])
            ->all();
    }
}

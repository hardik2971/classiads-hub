<?php

namespace App\Filament\Widgets;

use App\Models\Transaction;
use Filament\Widgets\ChartWidget;
use Illuminate\Support\Carbon;

class RevenueChartWidget extends ChartWidget
{
    protected ?string $heading = 'Revenue (last 6 months)';

    protected static ?int $sort = 2;

    protected int|string|array $columnSpan = [
        'default' => 'full',
        'md' => 'half',
    ];

    protected function getData(): array
    {
        $start = Carbon::now()->startOfMonth()->subMonths(5);

        $labels = [];
        $buckets = array_fill(0, 6, 0.0);
        for ($i = 0; $i < 6; $i++) {
            $labels[] = $start->copy()->addMonths($i)->format('M Y');
        }

        // Bucket completed transactions in PHP (DB-agnostic — works on MySQL & SQLite).
        Transaction::query()
            ->where('status', 'completed')
            ->where('created_at', '>=', $start)
            ->get(['total', 'paid_at', 'created_at'])
            ->each(function (Transaction $t) use (&$buckets, $start): void {
                $when = $t->paid_at ?? $t->created_at;
                $idx = $start->diffInMonths($when);
                if ($idx >= 0 && $idx < 6) {
                    $buckets[$idx] += $t->total / 100;
                }
            });

        return [
            'datasets' => [[
                'label' => 'Revenue',
                'data' => array_map(fn ($v) => round($v, 2), $buckets),
                'borderColor' => '#272757',
                'backgroundColor' => 'rgba(39, 39, 87, 0.15)',
                'fill' => true,
                'tension' => 0.3,
            ]],
            'labels' => $labels,
        ];
    }

    protected function getType(): string
    {
        return 'line';
    }
}

<?php

namespace App\Filament\Widgets;

use App\Models\Ad;
use App\Models\State;
use Filament\Widgets\ChartWidget;

class AdsByLocationChartWidget extends ChartWidget
{
    protected ?string $heading = 'Ads by location (top states)';

    protected static ?int $sort = 3;

    protected int|string|array $columnSpan = [
        'default' => 'full',
        'md' => 'half',
    ];

    protected function getData(): array
    {
        $counts = Ad::query()
            ->whereNotNull('state_id')
            ->selectRaw('state_id, count(*) as total')
            ->groupBy('state_id')
            ->orderByDesc('total')
            ->limit(8)
            ->pluck('total', 'state_id');

        $names = State::query()
            ->whereIn('id', $counts->keys())
            ->pluck('name', 'id');

        $labels = [];
        $data = [];
        foreach ($counts as $stateId => $total) {
            $labels[] = $names[$stateId] ?? "State #{$stateId}";
            $data[] = $total;
        }

        return [
            'datasets' => [[
                'label' => 'Ads',
                'data' => $data,
                'backgroundColor' => '#272757',
            ]],
            'labels' => $labels,
        ];
    }

    protected function getType(): string
    {
        return 'bar';
    }
}

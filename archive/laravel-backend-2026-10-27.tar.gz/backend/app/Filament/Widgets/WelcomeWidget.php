<?php

namespace App\Filament\Widgets;

use Filament\Facades\Filament;
use Filament\Widgets\Widget;

class WelcomeWidget extends Widget
{
    protected string $view = 'filament.widgets.welcome';

    protected int|string|array $columnSpan = 'full';

    protected static ?int $sort = 0;

    protected function getViewData(): array
    {
        $user = Filament::auth()->user();
        // Match the reference mock: short greeting using "Admin" as the
        // friendly fallback for users whose name field is empty.
        $name = trim((string) ($user?->name ?? ''));

        return [
            'name' => $name !== '' ? $name : 'Admin',
        ];
    }
}

<?php

namespace App\Filament\Widgets;

use App\Models\Ad;
use App\Models\Category;
use App\Models\CustomField;
use App\Models\User;
use Filament\Widgets\Widget;

class StatsOverviewWidget extends Widget
{
    protected string $view = 'filament.widgets.stats-overview';

    protected static ?int $sort = 1;

    /**
     * Narrow column on `lg`+ so it sits next to the wide Featured Sections
     * table; stacks full-width on smaller screens.
     */
    protected int|string|array $columnSpan = [
        'default' => 12,
        'md' => 12,
        'lg' => 4,
    ];

    protected function getViewData(): array
    {
        // Mirrors the reference mock: 4 cards in a 2×2 grid with alternating
        // teal / coral icon tiles, big number, small label.
        return [
            'stats' => [
                [
                    'label' => 'Total Customers',
                    'value' => number_format(User::role('customer')->count()),
                    'icon'  => 'heroicon-m-users',
                    'tint'  => 'teal',
                ],
                [
                    'label' => 'Total Advertisements',
                    'value' => number_format(Ad::count()),
                    'icon'  => 'heroicon-m-megaphone',
                    'tint'  => 'coral',
                ],
                [
                    'label' => 'Total Categories',
                    'value' => number_format(Category::count()),
                    'icon'  => 'heroicon-m-square-3-stack-3d',
                    'tint'  => 'coral',
                ],
                [
                    'label' => 'Total Custom Fields',
                    'value' => number_format(CustomField::count()),
                    'icon'  => 'heroicon-m-clipboard-document-list',
                    'tint'  => 'teal',
                ],
            ],
        ];
    }
}

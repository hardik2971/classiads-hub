<?php

namespace App\Filament\Widgets;

use App\Models\Ad;
use App\Models\Category;
use Filament\Widgets\ChartWidget;

class TotalCategoriesChartWidget extends ChartWidget
{
    protected ?string $heading = 'Total Categories';

    protected static ?int $sort = 6;

    protected int|string|array $columnSpan = [
        'default' => 'full',
        'md' => 'half',
        'lg' => 6,
    ];

    protected ?string $maxHeight = '380px';

    /** Cap the legend so it remains readable. */
    private const MAX_SLICES = 60;

    protected function getData(): array
    {
        // Count ads per category — the donut's slice sizes match each category's
        // share of the catalog.
        $rows = Ad::query()
            ->selectRaw('category_id, COUNT(*) as total')
            ->whereNotNull('category_id')
            ->groupBy('category_id')
            ->orderByDesc('total')
            ->limit(self::MAX_SLICES)
            ->get();

        if ($rows->isEmpty()) {
            // Fall back to a flat distribution if no ads have categories yet,
            // so the donut isn't empty on first render.
            $rows = Category::query()
                ->orderBy('name')
                ->limit(self::MAX_SLICES)
                ->get(['id', 'name'])
                ->map(fn (Category $c) => (object) ['category_id' => $c->id, 'total' => 1]);
        }

        $names = Category::query()
            ->whereIn('id', $rows->pluck('category_id'))
            ->pluck('name', 'id');

        $palette = [
            '#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#06B6D4',
            '#F472B6', '#22C55E', '#A855F7', '#0EA5E9', '#FB7185', '#14B8A6',
            '#F97316', '#84CC16', '#EC4899', '#6366F1', '#FACC15', '#D946EF',
        ];

        $labels = [];
        $data   = [];
        $colors = [];

        foreach ($rows as $i => $row) {
            $labels[] = "'" . ($names[$row->category_id] ?? "Category #{$row->category_id}") . "'";
            $data[]   = (int) $row->total;
            $colors[] = $palette[$i % count($palette)];
        }

        return [
            'datasets' => [[
                'label'           => 'Ads',
                'data'            => $data,
                'backgroundColor' => $colors,
                'borderColor'     => '#ffffff',
                'borderWidth'     => 2,
            ]],
            'labels' => $labels,
        ];
    }

    protected function getType(): string
    {
        return 'doughnut';
    }

    protected function getOptions(): array
    {
        return [
            'plugins' => [
                'legend' => [
                    'position' => 'bottom',
                    'labels'   => [
                        'boxWidth' => 8,
                        'padding'  => 8,
                        'font'     => ['size' => 11],
                    ],
                ],
                'tooltip' => [
                    'callbacks' => null,
                ],
            ],
            'cutout' => '62%',
        ];
    }
}

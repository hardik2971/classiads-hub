<?php

namespace App\Filament\Widgets;

use App\Filament\Resources\Ads\AdResource;
use App\Models\Ad;
use Filament\Actions\Action;
use Filament\Notifications\Notification;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Filament\Widgets\TableWidget as BaseWidget;

class LatestPendingAdsWidget extends BaseWidget
{
    protected static ?int $sort = 5;

    protected int|string|array $columnSpan = 'full';

    public function getTableHeading(): string
    {
        return 'Pending moderation';
    }

    public function table(Table $table): Table
    {
        return $table
            ->query(
                Ad::query()->where('status', 'pending')->latest()
            )
            ->emptyStateHeading('No ads awaiting moderation')
            ->emptyStateIcon('heroicon-o-check-badge')
            ->columns([
                TextColumn::make('title')->limit(40)->weight('bold')->searchable(),
                TextColumn::make('user.name')->label('Seller')->searchable(),
                TextColumn::make('category.name')->label('Category')->toggleable(),
                TextColumn::make('price')
                    ->money(currency: fn (Ad $r) => $r->currency_code, divideBy: 100),
                TextColumn::make('created_at')->since()->label('Submitted')->sortable(),
            ])
            ->recordActions([
                Action::make('approve')
                    ->icon('heroicon-o-check-circle')
                    ->color('success')
                    ->requiresConfirmation()
                    ->action(function (Ad $record): void {
                        $record->update([
                            'status' => 'approved',
                            'approved_at' => now(),
                            'published_at' => $record->published_at ?? now(),
                            'rejection_reason' => null,
                        ]);
                        Notification::make()->title('Ad approved')->success()->send();
                    }),
                Action::make('review')
                    ->icon('heroicon-o-eye')
                    ->color('gray')
                    ->url(fn (Ad $record): string => AdResource::getUrl('edit', ['record' => $record])),
            ]);
    }
}

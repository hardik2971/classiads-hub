<?php

namespace App\Filament\Resources\FeaturedSections;

use App\Filament\Resources\FeaturedSections\Pages\CreateFeaturedSection;
use App\Filament\Resources\FeaturedSections\Pages\EditFeaturedSection;
use App\Filament\Resources\FeaturedSections\Pages\ListFeaturedSections;
use App\Filament\Resources\FeaturedSections\Schemas\FeaturedSectionForm;
use App\Filament\Resources\FeaturedSections\Tables\FeaturedSectionsTable;
use App\Models\FeaturedSection;
use BackedEnum;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Table;

class FeaturedSectionResource extends Resource
{
    protected static ?string $model = FeaturedSection::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedStar;

    protected static string | \UnitEnum | null $navigationGroup = 'Ads Listing';

    protected static ?string $navigationLabel = 'Feature Section';

    protected static ?int $navigationSort = 6;

    public static function form(Schema $schema): Schema
    {
        return FeaturedSectionForm::configure($schema);
    }

    public static function table(Table $table): Table
    {
        return FeaturedSectionsTable::configure($table);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => ListFeaturedSections::route('/'),
            'create' => CreateFeaturedSection::route('/create'),
            'edit' => EditFeaturedSection::route('/{record}/edit'),
        ];
    }
}

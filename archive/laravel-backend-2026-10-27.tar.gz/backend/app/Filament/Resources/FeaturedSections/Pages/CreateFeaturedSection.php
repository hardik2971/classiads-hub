<?php

namespace App\Filament\Resources\FeaturedSections\Pages;

use App\Filament\Resources\FeaturedSections\FeaturedSectionResource;
use Filament\Resources\Pages\CreateRecord;

class CreateFeaturedSection extends CreateRecord
{
    protected static string $resource = FeaturedSectionResource::class;
}

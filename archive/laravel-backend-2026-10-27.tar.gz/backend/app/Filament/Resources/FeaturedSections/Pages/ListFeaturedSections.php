<?php

namespace App\Filament\Resources\FeaturedSections\Pages;

use App\Filament\Resources\FeaturedSections\FeaturedSectionResource;
use Filament\Actions\CreateAction;
use Filament\Resources\Pages\ListRecords;

class ListFeaturedSections extends ListRecords
{
    protected static string $resource = FeaturedSectionResource::class;

    protected function getHeaderActions(): array
    {
        return [
            CreateAction::make(),
        ];
    }
}

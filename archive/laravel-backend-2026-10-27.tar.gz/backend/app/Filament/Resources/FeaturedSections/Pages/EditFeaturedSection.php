<?php

namespace App\Filament\Resources\FeaturedSections\Pages;

use App\Filament\Resources\FeaturedSections\FeaturedSectionResource;
use Filament\Actions\DeleteAction;
use Filament\Resources\Pages\EditRecord;

class EditFeaturedSection extends EditRecord
{
    protected static string $resource = FeaturedSectionResource::class;

    protected function getHeaderActions(): array
    {
        return [
            DeleteAction::make(),
        ];
    }
}

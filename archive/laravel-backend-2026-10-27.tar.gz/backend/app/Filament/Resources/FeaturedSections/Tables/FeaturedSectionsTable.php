<?php

namespace App\Filament\Resources\FeaturedSections\Tables;

use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Columns\ViewColumn;
use Filament\Tables\Table;

class FeaturedSectionsTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('id')
                    ->label('ID')
                    ->sortable()
                    ->weight('semibold'),

                ViewColumn::make('style_preview')
                    ->label('Style')
                    ->view('filament.widgets.featured-sections-style-cell'),

                TextColumn::make('title')
                    ->label('Title')
                    ->searchable()
                    ->weight('semibold')
                    ->color('info'),

                TextColumn::make('filter_type')
                    ->label('Filters')
                    ->formatStateUsing(fn (string $s) => match ($s) {
                        'latest'      => 'Latest Listings',
                        'most_viewed' => 'Most Viewed',
                        'most_liked'  => 'Most Liked',
                        'featured'    => 'Featured Only',
                        'category'    => 'Category Criteria',
                        default       => ucfirst(str_replace('_', ' ', $s)),
                    })
                    ->color('gray'),

                TextColumn::make('sort_order')
                    ->label('Sequence')
                    ->numeric()
                    ->sortable(),
            ])
            ->defaultSort('sort_order')
            ->reorderable('sort_order')
            ->recordActions([
                EditAction::make()->iconButton(),
                DeleteAction::make()->iconButton(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ]);
    }
}

<?php

namespace App\Filament\Resources\FeaturedSections\Schemas;

use Filament\Forms\Components\Radio;
use Filament\Schemas\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Schemas\Components\Tabs;
use Filament\Schemas\Components\Tabs\Tab;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Schemas\Schema;

class FeaturedSectionForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                Section::make('Add Feature Section')
                    ->schema([
                        Tabs::make('translations')
                            ->tabs([
                                Tab::make('English')
                                    ->schema([
                                        TextInput::make('title')
                                            ->label('Title (English)')
                                            ->placeholder('Title')
                                            ->required()
                                            ->maxLength(150),
                                    ]),
                                Tab::make('Français')
                                    ->schema([
                                        TextInput::make('title_fr')
                                            ->label('Title (Français)')
                                            ->placeholder('Title')
                                            ->maxLength(150),
                                    ]),
                                Tab::make('عربي')
                                    ->schema([
                                        TextInput::make('title_ar')
                                            ->label('Title (عربي)')
                                            ->placeholder('Title')
                                            ->maxLength(150),
                                    ]),
                                Tab::make('Ð ÑƒÑÑÐºÐ¸Ð¹')
                                    ->schema([
                                        TextInput::make('title_ru')
                                            ->label('Title (Ð ÑƒÑÑÐºÐ¸Ð¹)')
                                            ->placeholder('Title')
                                            ->maxLength(150),
                                    ]),
                            ])
                            ->columnSpanFull(),

                        TextInput::make('slug')
                            ->label('Slug')
                            ->required()
                            ->maxLength(150)
                            ->alphaDash(),

                        Select::make('filter_type')
                            ->label('Filters')
                            ->options([
                                'latest'      => 'Latest',
                                'most_viewed' => 'Most Viewed',
                                'most_liked'  => 'Most Liked',
                                'featured'    => 'Featured',
                                'category'    => 'Category Criteria',
                            ])
                            ->default('most_liked')
                            ->required()
                            ->live(),

                        Select::make('category_id')
                            ->label('Category')
                            ->relationship('category', 'name')
                            ->searchable()
                            ->visible(fn (callable $get) => $get('filter_type') === 'category'),

                        Radio::make('style')
                            ->label('Select Style for APP Section')
                            ->options([
                                'card'    => 'Card layout',
                                'compact' => 'Compact list',
                                'wide'    => 'Wide tile',
                                'hero'    => 'Hero with details',
                            ])
                            ->required()
                            ->default('card')
                            ->columns(4)
                            ->columnSpanFull(),

                        TextInput::make('item_limit')
                            ->label('Items to show')
                            ->numeric()
                            ->default(10)
                            ->minValue(1)
                            ->maxValue(50)
                            ->required(),

                        TextInput::make('sort_order')
                            ->label('Sequence')
                            ->numeric()
                            ->default(0)
                            ->required(),

                        Toggle::make('is_active')
                            ->label('Active')
                            ->default(true),
                    ])
                    ->columns(2),
            ]);
    }
}

<?php

namespace App\Filament\Resources\PaymentGateways\Schemas;

use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\Toggle;
use Filament\Schemas\Schema;

class PaymentGatewayForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                TextInput::make('code')
                    ->required(),
                TextInput::make('name')
                    ->required(),
                Toggle::make('is_active')
                    ->required(),
                Select::make('mode')
                    ->options(['sandbox' => 'Sandbox', 'live' => 'Live'])
                    ->default('sandbox')
                    ->required(),
                Textarea::make('config')
                    ->default(null)
                    ->columnSpanFull(),
                Textarea::make('supported_currencies')
                    ->default(null)
                    ->columnSpanFull(),
                Toggle::make('is_manual')
                    ->required(),
                TextInput::make('sort_order')
                    ->required()
                    ->numeric()
                    ->default(0),
            ]);
    }
}

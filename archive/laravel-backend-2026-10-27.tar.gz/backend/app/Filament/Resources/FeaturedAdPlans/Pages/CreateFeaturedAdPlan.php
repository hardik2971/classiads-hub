<?php

namespace App\Filament\Resources\FeaturedAdPlans\Pages;

use App\Filament\Resources\FeaturedAdPlans\FeaturedAdPlanResource;
use Filament\Resources\Pages\CreateRecord;

class CreateFeaturedAdPlan extends CreateRecord
{
    protected static string $resource = FeaturedAdPlanResource::class;
}

<?php

namespace App\Filament\Resources\FeaturedAdPlans\Pages;

use App\Filament\Resources\FeaturedAdPlans\FeaturedAdPlanResource;
use Filament\Actions\DeleteAction;
use Filament\Resources\Pages\EditRecord;

class EditFeaturedAdPlan extends EditRecord
{
    protected static string $resource = FeaturedAdPlanResource::class;

    protected function getHeaderActions(): array
    {
        return [
            DeleteAction::make(),
        ];
    }
}

<?php

namespace App\Filament\Resources\FeaturedAdPlans\Pages;

use App\Filament\Resources\FeaturedAdPlans\FeaturedAdPlanResource;
use Filament\Actions\CreateAction;
use Filament\Resources\Pages\ListRecords;

class ListFeaturedAdPlans extends ListRecords
{
    protected static string $resource = FeaturedAdPlanResource::class;

    protected function getHeaderActions(): array
    {
        return [
            CreateAction::make(),
        ];
    }
}

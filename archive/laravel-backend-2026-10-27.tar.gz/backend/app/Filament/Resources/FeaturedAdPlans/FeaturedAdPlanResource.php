<?php

namespace App\Filament\Resources\FeaturedAdPlans;

use App\Filament\Resources\FeaturedAdPlans\Pages\CreateFeaturedAdPlan;
use App\Filament\Resources\FeaturedAdPlans\Pages\EditFeaturedAdPlan;
use App\Filament\Resources\FeaturedAdPlans\Pages\ListFeaturedAdPlans;
use App\Filament\Resources\FeaturedAdPlans\Schemas\FeaturedAdPlanForm;
use App\Filament\Resources\FeaturedAdPlans\Tables\FeaturedAdPlansTable;
use App\Models\FeaturedAdPlan;
use BackedEnum;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Table;

class FeaturedAdPlanResource extends Resource
{
    protected static ?string $model = FeaturedAdPlan::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedRectangleStack;

    protected static string | \UnitEnum | null $navigationGroup = 'Monetization';

    public static function form(Schema $schema): Schema
    {
        return FeaturedAdPlanForm::configure($schema);
    }

    public static function table(Table $table): Table
    {
        return FeaturedAdPlansTable::configure($table);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => ListFeaturedAdPlans::route('/'),
            'create' => CreateFeaturedAdPlan::route('/create'),
            'edit' => EditFeaturedAdPlan::route('/{record}/edit'),
        ];
    }
}

<?php

namespace App\Filament\Resources\Packages\Schemas;

use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\Toggle;
use Filament\Schemas\Schema;

class PackageForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                TextInput::make('name')
                    ->required(),
                TextInput::make('ios_product_id')
                    ->default(null),
                TextInput::make('android_product_id')
                    ->default(null),
                Textarea::make('description')
                    ->default(null)
                    ->columnSpanFull(),
                TextInput::make('price')
                    ->required()
                    ->numeric()
                    ->prefix('$'),
                TextInput::make('discount_percent')
                    ->required()
                    ->numeric()
                    ->default(0),
                TextInput::make('final_price')
                    ->required()
                    ->numeric()
                    ->prefix('$'),
                TextInput::make('currency_code')
                    ->required()
                    ->default('USD'),
                TextInput::make('duration_days')
                    ->required()
                    ->numeric(),
                TextInput::make('ad_limit')
                    ->numeric()
                    ->default(null),
                Toggle::make('is_unlimited')
                    ->required(),
                TextInput::make('icon_path')
                    ->default(null),
                Toggle::make('is_active')
                    ->required(),
                TextInput::make('sort_order')
                    ->required()
                    ->numeric()
                    ->default(0),
            ]);
    }
}

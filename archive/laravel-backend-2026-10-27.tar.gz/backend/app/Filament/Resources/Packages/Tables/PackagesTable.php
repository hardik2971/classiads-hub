<?php

namespace App\Filament\Resources\Packages\Tables;

use App\Models\Package;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Tables\Columns\ImageColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Columns\ToggleColumn;
use Filament\Tables\Enums\FiltersLayout;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Table;

class PackagesTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('id')
                    ->label('ID')
                    ->sortable()
                    ->weight('semibold'),

                ImageColumn::make('icon_path')
                    ->label('Image')
                    ->size(40),

                TextColumn::make('name')
                    ->label('Name')
                    ->searchable()
                    ->weight('semibold'),

                TextColumn::make('package_kind')
                    ->label('Type')
                    ->getStateUsing(fn (Package $r): string => self::resolveType($r))
                    ->badge()
                    ->color(fn (string $s): string => $s === 'Advertisement (Featured Ads)' ? 'success' : 'info'),

                TextColumn::make('package_scope')
                    ->label('Categories')
                    ->getStateUsing(fn (Package $r): string => self::resolveScope($r))
                    ->badge()
                    ->color(fn (string $s): string => $s === 'Global' ? 'success' : 'warning'),

                TextColumn::make('price')
                    ->label('Price')
                    ->numeric()
                    ->sortable(),

                TextColumn::make('discount_percent')
                    ->label('Discount (%)')
                    ->numeric()
                    ->sortable(),

                TextColumn::make('final_price')
                    ->label('Final Price')
                    ->numeric()
                    ->sortable(),

                TextColumn::make('duration_label')
                    ->label('Package Duration')
                    ->getStateUsing(fn (Package $r): string => $r->is_unlimited
                        ? 'unlimited'
                        : (string) ($r->duration_days ?? 0)),

                ToggleColumn::make('is_active')
                    ->label('Status'),
            ])
            ->defaultSort('id', 'desc')
            ->filters([
                SelectFilter::make('package_type')
                    ->label('Package Type')
                    ->options([
                        'all'  => 'All',
                        'item' => 'Item Listing (Ads)',
                        'ads'  => 'Advertisement (Featured Ads)',
                    ])
                    ->placeholder('All')
                    ->query(function ($query, array $data) {
                        if (($data['value'] ?? null) === 'item') {
                            $query->whereNotNull('ad_limit')->orWhere('is_unlimited', true);
                        } elseif (($data['value'] ?? null) === 'ads') {
                            $query->whereNull('ad_limit')->where('is_unlimited', false);
                        }
                    }),
            ], layout: FiltersLayout::AboveContent)
            ->recordActions([
                EditAction::make()->iconButton(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ]);
    }

    /**
     * Heuristic mapping until the schema gets a dedicated `type` column:
     *   - has ad_limit or is_unlimited → Item Listing (Ads)
     *   - otherwise → Advertisement (Featured Ads)
     */
    private static function resolveType(Package $r): string
    {
        if ($r->is_unlimited || ! is_null($r->ad_limit)) {
            return 'Item Listing (Ads)';
        }
        return 'Advertisement (Featured Ads)';
    }

    /**
     * Until packages can be scoped to categories via a pivot, every package
     * is "Global" unless its name hints otherwise.
     */
    private static function resolveScope(Package $r): string
    {
        $name = strtolower($r->name ?? '');
        if (str_contains($name, 'category') || str_contains($name, 'cat-based')) {
            return 'Category Based';
        }
        return 'Global';
    }
}

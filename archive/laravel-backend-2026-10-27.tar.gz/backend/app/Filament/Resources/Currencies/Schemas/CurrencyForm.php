<?php

namespace App\Filament\Resources\Currencies\Schemas;

use Filament\Schemas\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Schemas\Schema;

class CurrencyForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                Section::make()
                    ->schema([
                        TextInput::make('code')
                            ->label('ISO Code')
                            ->required()
                            ->maxLength(3)
                            ->placeholder('USD'),

                        TextInput::make('name')
                            ->label('Name')
                            ->required()
                            ->maxLength(80),

                        TextInput::make('symbol')
                            ->label('Symbol')
                            ->required()
                            ->maxLength(8),

                        Select::make('symbol_position')
                            ->label('Symbol Position')
                            ->options(['left' => 'Left', 'right' => 'Right'])
                            ->default('left')
                            ->required(),

                        Select::make('country_id')
                            ->label('Country')
                            ->relationship('country', 'name')
                            ->searchable()
                            ->preload()
                            ->columnSpanFull(),

                        TextInput::make('decimal_digits')
                            ->label('Decimal Digits')
                            ->numeric()
                            ->default(2)
                            ->minValue(0)
                            ->maxValue(8),

                        Toggle::make('is_default')
                            ->label('Default'),

                        Toggle::make('is_active')
                            ->label('Active')
                            ->default(true),
                    ])
                    ->columns(2),
            ]);
    }
}

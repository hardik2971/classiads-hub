<?php

namespace App\Filament\Resources\Currencies\Tables;

use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class CurrenciesTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->modifyQueryUsing(fn ($query) => $query->with('country'))
            ->columns([
                TextColumn::make('id')
                    ->label('ID')
                    ->sortable()
                    ->weight('semibold'),

                TextColumn::make('code')
                    ->label('ISO Code')
                    ->searchable()
                    ->color('info'),

                TextColumn::make('name')
                    ->label('Name')
                    ->searchable(),

                TextColumn::make('symbol')
                    ->label('Symbol'),

                TextColumn::make('symbol_position')
                    ->label('Symbol Position'),

                TextColumn::make('country.name')
                    ->label('Country')
                    ->searchable()
                    ->placeholder('-'),
            ])
            ->defaultSort('id', 'desc')
            ->recordActions([
                EditAction::make()->iconButton(),
                DeleteAction::make()->iconButton(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ]);
    }
}

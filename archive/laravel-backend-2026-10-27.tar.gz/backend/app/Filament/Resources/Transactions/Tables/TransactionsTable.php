<?php

namespace App\Filament\Resources\Transactions\Tables;

use Filament\Actions\Action;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteBulkAction;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class TransactionsTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->modifyQueryUsing(fn ($query) => $query->with('user'))
            ->columns([
                TextColumn::make('id')
                    ->label('ID')
                    ->sortable()
                    ->weight('semibold'),

                TextColumn::make('user.name')
                    ->label('User Name')
                    ->searchable(),

                TextColumn::make('amount_display')
                    ->label('Amount')
                    ->getStateUsing(fn ($r) => number_format(($r->total ?? 0) / 100, 2)),

                TextColumn::make('gateway')
                    ->label('Payment Gateway')
                    ->formatStateUsing(fn (?string $s): string => match ($s) {
                        'stripe'        => 'Stripe',
                        'razorpay'      => 'Razorpay',
                        'bank_transfer' => 'BankTransfer',
                        'free'          => 'Free',
                        'sandbox'       => 'Sandbox',
                        default         => $s ? ucfirst($s) : '—',
                    }),

                TextColumn::make('status')
                    ->label('Payment Status')
                    ->formatStateUsing(fn (string $s): string => match ($s) {
                        'completed'   => 'Succeed',
                        'pending'     => 'Under review',
                        'failed'      => 'Failed',
                        'refunded'    => 'Refunded',
                        'cancelled'   => 'Cancelled',
                        default       => ucfirst($s),
                    })
                    ->color(fn (string $s): string => match ($s) {
                        'completed' => 'success',
                        'pending'   => 'warning',
                        'failed'    => 'danger',
                        'refunded'  => 'gray',
                        default     => 'gray',
                    }),

                TextColumn::make('created_at')
                    ->label('Created At')
                    ->dateTime('d-m-y H:i:s')
                    ->sortable(),
            ])
            ->defaultSort('id', 'desc')
            ->recordActions([
                Action::make('view_invoice')
                    ->label('')
                    ->icon('heroicon-o-document-text')
                    ->iconButton()
                    ->color('info')
                    ->visible(fn ($record) => in_array($record->status, ['completed', 'failed'], true))
                    ->modalHeading(fn ($record) => "Transaction #{$record->id}")
                    ->modalContent(fn ($record) => view('filament.resources.transactions.modal-invoice', [
                        'transaction' => $record,
                    ])),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ]);
    }
}

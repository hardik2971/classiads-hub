<?php

namespace App\Filament\Resources\Transactions\Schemas;

use Filament\Forms\Components\DateTimePicker;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Textarea;
use Filament\Schemas\Schema;

class TransactionForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                Select::make('user_id')
                    ->relationship('user', 'name')
                    ->required(),
                Select::make('type')
                    ->options(['subscription' => 'Subscription', 'featured_ad' => 'Featured ad'])
                    ->required(),
                Select::make('package_id')
                    ->relationship('package', 'name')
                    ->default(null),
                TextInput::make('featured_ad_plan_id')
                    ->numeric()
                    ->default(null),
                Select::make('ad_id')
                    ->relationship('ad', 'title')
                    ->default(null),
                TextInput::make('gateway')
                    ->required(),
                TextInput::make('gateway_reference')
                    ->default(null),
                TextInput::make('amount')
                    ->required()
                    ->numeric(),
                TextInput::make('tax_amount')
                    ->required()
                    ->numeric()
                    ->default(0),
                TextInput::make('total')
                    ->required()
                    ->numeric(),
                TextInput::make('currency_code')
                    ->required()
                    ->default('USD'),
                Select::make('status')
                    ->options([
            'pending' => 'Pending',
            'processing' => 'Processing',
            'completed' => 'Completed',
            'failed' => 'Failed',
            'refunded' => 'Refunded',
            'cancelled' => 'Cancelled',
        ])
                    ->default('pending')
                    ->required(),
                Textarea::make('meta')
                    ->default(null)
                    ->columnSpanFull(),
                DateTimePicker::make('paid_at'),
            ]);
    }
}

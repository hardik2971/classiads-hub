<?php

namespace App\Filament\Resources\States\Tables;

use App\Models\Country;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteBulkAction;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Enums\FiltersLayout;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Table;

class StatesTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->modifyQueryUsing(fn ($query) => $query->with('country'))
            ->columns([
                TextColumn::make('id')
                    ->label('ID')
                    ->sortable()
                    ->weight('semibold'),

                TextColumn::make('name')
                    ->label('Name')
                    ->searchable()
                    ->color('info'),

                TextColumn::make('country.name')
                    ->label('Country')
                    ->searchable()
                    ->color('info'),

                TextColumn::make('country.iso2')
                    ->label('Flag')
                    ->color('gray'),
            ])
            ->defaultSort('id', 'desc')
            ->filters([
                SelectFilter::make('country_id')
                    ->label('Country')
                    ->options(fn () => Country::orderBy('name')->pluck('name', 'id')->all())
                    ->searchable(),
            ], layout: FiltersLayout::AboveContent)
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ]);
    }
}

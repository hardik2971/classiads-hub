<?php

namespace App\Filament\Resources\States\Pages;

use App\Filament\Resources\States\StateResource;
use Filament\Actions\Action;
use Filament\Resources\Pages\ListRecords;

class ListStates extends ListRecords
{
    protected static string $resource = StateResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Action::make('translate_states')
                ->label('Translate States')
                ->icon('heroicon-o-language')
                ->color('info')
                ->url(fn () => route('filament.admin.resources.translations.index', [
                    'tableFilters[group][value]' => 'states',
                ]))
                ->openUrlInNewTab(false),
        ];
    }
}

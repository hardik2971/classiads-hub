<?php

namespace App\Filament\Resources\SeoMetas\Schemas;

use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Textarea;
use Filament\Schemas\Schema;

class SeoMetaForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                TextInput::make('seoable_type')
                    ->default(null),
                TextInput::make('seoable_id')
                    ->numeric()
                    ->default(null),
                TextInput::make('route_key')
                    ->default(null),
                TextInput::make('title')
                    ->default(null),
                TextInput::make('description')
                    ->default(null),
                TextInput::make('keywords')
                    ->default(null),
                FileUpload::make('og_image')
                    ->image(),
                Textarea::make('json_ld')
                    ->default(null)
                    ->columnSpanFull(),
            ]);
    }
}

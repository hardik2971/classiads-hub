<?php

namespace App\Filament\Resources\BankTransfers;

use App\Filament\Resources\BankTransfers\Pages\EditBankTransfer;
use App\Filament\Resources\BankTransfers\Pages\ListBankTransfers;
use App\Filament\Resources\BankTransfers\Schemas\BankTransferForm;
use App\Filament\Resources\BankTransfers\Tables\BankTransfersTable;
use App\Models\Transaction;
use BackedEnum;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use UnitEnum;

class BankTransferResource extends Resource
{
    protected static ?string $model = Transaction::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedBuildingLibrary;

    protected static string | UnitEnum | null $navigationGroup = 'Package Management';

    protected static ?string $navigationLabel = 'Bank Transfers';

    protected static ?string $modelLabel = 'Bank Transfer';

    protected static ?string $pluralModelLabel = 'Bank Transfers';

    protected static ?string $slug = 'bank-transfers';

    protected static ?int $navigationSort = 4;

    /**
     * Only show transactions whose gateway is "bank_transfer".
     */
    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()->where('gateway', 'bank_transfer');
    }

    public static function form(Schema $schema): Schema
    {
        return BankTransferForm::configure($schema);
    }

    public static function table(Table $table): Table
    {
        return BankTransfersTable::configure($table);
    }

    public static function getPages(): array
    {
        return [
            'index' => ListBankTransfers::route('/'),
            'edit'  => EditBankTransfer::route('/{record}/edit'),
        ];
    }
}

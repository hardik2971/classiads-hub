<?php

namespace App\Filament\Resources\BankTransfers\Schemas;

use Filament\Forms\Components\FileUpload;
use Filament\Schemas\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Schemas\Schema;

class BankTransferForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                Section::make('Review Bank Transfer')
                    ->schema([
                        TextInput::make('user.name')
                            ->label('User')
                            ->disabled(),

                        TextInput::make('total')
                            ->label('Amount (minor units)')
                            ->disabled(),

                        Select::make('status')
                            ->label('Payment Status')
                            ->options([
                                'pending'   => 'Under review',
                                'completed' => 'Approved',
                                'failed'    => 'Failed',
                                'rejected'  => 'Rejected',
                            ])
                            ->required(),

                        FileUpload::make('meta.receipt_path')
                            ->label('Payment Receipt')
                            ->image()
                            ->directory('receipts')
                            ->disk('public')
                            ->columnSpanFull(),

                        Textarea::make('meta.admin_note')
                            ->label('Admin note (internal)')
                            ->rows(2)
                            ->columnSpanFull(),
                    ])
                    ->columns(2),
            ]);
    }
}

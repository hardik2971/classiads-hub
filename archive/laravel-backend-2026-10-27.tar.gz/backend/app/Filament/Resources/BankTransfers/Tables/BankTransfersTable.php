<?php

namespace App\Filament\Resources\BankTransfers\Tables;

use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Tables\Columns\ImageColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class BankTransfersTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->modifyQueryUsing(fn ($query) => $query->with('user'))
            ->columns([
                TextColumn::make('id')
                    ->label('ID')
                    ->sortable()
                    ->weight('semibold'),

                TextColumn::make('user.name')
                    ->label('User Name')
                    ->searchable(),

                TextColumn::make('amount_display')
                    ->label('Amount')
                    ->getStateUsing(fn ($r) => number_format(($r->total ?? 0) / 100, 2)),

                TextColumn::make('status')
                    ->label('Payment Status')
                    ->formatStateUsing(fn (string $s): string => match ($s) {
                        'completed' => 'Approved',
                        'pending'   => 'Under review',
                        'failed'    => 'Failed',
                        'rejected'  => 'Rejected',
                        default     => ucfirst($s),
                    })
                    ->color(fn (string $s): string => match ($s) {
                        'completed' => 'success',
                        'pending'   => 'warning',
                        'failed'    => 'danger',
                        'rejected'  => 'danger',
                        default     => 'gray',
                    }),

                ImageColumn::make('receipt_path')
                    ->label('Payment Reciept')
                    ->getStateUsing(fn ($r) => $r->meta['receipt_path'] ?? null)
                    ->size(50)
                    ->defaultImageUrl(null),

                TextColumn::make('created_at')
                    ->label('Created At')
                    ->dateTime('d-m-y H:i:s')
                    ->sortable(),
            ])
            ->defaultSort('id', 'desc')
            ->recordActions([
                EditAction::make()->iconButton(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ]);
    }
}

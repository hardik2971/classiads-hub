<?php

namespace App\Filament\Resources\PushNotifications\Schemas;

use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Textarea;
use Filament\Schemas\Schema;

class PushNotificationForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                TextInput::make('title')
                    ->required(),
                Textarea::make('body')
                    ->required()
                    ->columnSpanFull(),
                FileUpload::make('image_path')
                    ->image(),
                Select::make('target')
                    ->options(['all' => 'All', 'role' => 'Role', 'user' => 'User'])
                    ->default('all')
                    ->required(),
                TextInput::make('target_role')
                    ->default(null),
                Select::make('target_user_id')
                    ->relationship('targetUser', 'name')
                    ->default(null),
                TextInput::make('item_type')
                    ->default(null),
                TextInput::make('item_id')
                    ->numeric()
                    ->default(null),
                TextInput::make('sent_by')
                    ->numeric()
                    ->default(null),
                TextInput::make('recipients_count')
                    ->required()
                    ->numeric()
                    ->default(0),
            ]);
    }
}

<?php

namespace App\Filament\Resources\BlogPosts\Tables;

use App\Models\BlogPost;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Tables\Columns\ImageColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class BlogPostsTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('id')
                    ->label('ID')
                    ->sortable()
                    ->weight('semibold'),

                TextColumn::make('title')
                    ->label('Title')
                    ->searchable()
                    ->wrap()
                    ->weight('semibold'),

                TextColumn::make('slug')
                    ->label('Slug')
                    ->searchable()
                    ->color('info')
                    ->wrap(),

                TextColumn::make('excerpt')
                    ->label('Description')
                    ->limit(80)
                    ->wrap()
                    ->color('gray')
                    ->tooltip(fn (BlogPost $r) => $r->excerpt),

                ImageColumn::make('cover_image_path')
                    ->label('Image')
                    ->size(46)
                    ->circular(),

                TextColumn::make('tags_csv')
                    ->label('Tags')
                    ->getStateUsing(fn (BlogPost $r): string => is_array($r->tags) && ! empty($r->tags)
                        ? implode(',', $r->tags)
                        : '-')
                    ->color('info')
                    ->wrap(),

                TextColumn::make('updated_at')
                    ->label('Date')
                    ->dateTime('d-m-y H:i:s')
                    ->sortable(),
            ])
            ->defaultSort('id', 'desc')
            ->recordActions([
                EditAction::make()->iconButton(),
                DeleteAction::make()->iconButton(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ]);
    }
}

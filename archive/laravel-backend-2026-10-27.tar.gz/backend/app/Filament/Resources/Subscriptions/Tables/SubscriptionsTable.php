<?php

namespace App\Filament\Resources\Subscriptions\Tables;

use App\Models\Subscription;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteBulkAction;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class SubscriptionsTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->modifyQueryUsing(fn ($query) => $query->with(['user', 'package']))
            ->columns([
                TextColumn::make('id')
                    ->label('ID')
                    ->sortable()
                    ->weight('semibold'),

                TextColumn::make('user.name')
                    ->label('User Name')
                    ->searchable(),

                TextColumn::make('package.name')
                    ->label('Package Name')
                    ->searchable(),

                TextColumn::make('starts_at')
                    ->label('Start Date')
                    ->date('Y-m-d')
                    ->sortable(),

                TextColumn::make('ends_at')
                    ->label('End Date')
                    ->date('Y-m-d')
                    ->sortable(),

                TextColumn::make('status')
                    ->label('Status')
                    ->badge()
                    ->formatStateUsing(fn (string $s) => ucfirst($s))
                    ->color(fn (string $s) => match ($s) {
                        'active'    => 'success',
                        'expired'   => 'danger',
                        'cancelled' => 'gray',
                        default     => 'warning',
                    }),

                TextColumn::make('total_limit')
                    ->label('Total Limit')
                    ->getStateUsing(fn (Subscription $r) => $r->is_unlimited
                        ? 'unlimited'
                        : (string) ($r->ad_limit ?? 0)),

                TextColumn::make('ads_used')
                    ->label('Used Limit')
                    ->numeric()
                    ->sortable(),
            ])
            ->defaultSort('id', 'desc')
            ->recordActions([])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ]);
    }
}

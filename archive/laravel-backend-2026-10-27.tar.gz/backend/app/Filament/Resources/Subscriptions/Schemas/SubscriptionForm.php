<?php

namespace App\Filament\Resources\Subscriptions\Schemas;

use Filament\Forms\Components\DateTimePicker;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Schemas\Schema;

class SubscriptionForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                Select::make('user_id')
                    ->relationship('user', 'name')
                    ->required(),
                Select::make('package_id')
                    ->relationship('package', 'name')
                    ->required(),
                Select::make('transaction_id')
                    ->relationship('transaction', 'id')
                    ->default(null),
                Select::make('status')
                    ->options([
            'pending' => 'Pending',
            'active' => 'Active',
            'expired' => 'Expired',
            'cancelled' => 'Cancelled',
        ])
                    ->default('pending')
                    ->required(),
                DateTimePicker::make('starts_at'),
                DateTimePicker::make('ends_at'),
                TextInput::make('ad_limit')
                    ->numeric()
                    ->default(null),
                Toggle::make('is_unlimited')
                    ->required(),
                TextInput::make('ads_used')
                    ->required()
                    ->numeric()
                    ->default(0),
            ]);
    }
}

<?php

namespace App\Filament\Resources\Conversations\Schemas;

use Filament\Forms\Components\DateTimePicker;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Textarea;
use Filament\Schemas\Schema;

class ConversationForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                Select::make('ad_id')
                    ->relationship('ad', 'title')
                    ->required(),
                Select::make('buyer_id')
                    ->relationship('buyer', 'name')
                    ->required(),
                Select::make('seller_id')
                    ->relationship('seller', 'name')
                    ->required(),
                Textarea::make('last_message')
                    ->default(null)
                    ->columnSpanFull(),
                DateTimePicker::make('last_message_at'),
                TextInput::make('buyer_unread')
                    ->required()
                    ->numeric()
                    ->default(0),
                TextInput::make('seller_unread')
                    ->required()
                    ->numeric()
                    ->default(0),
            ]);
    }
}

<?php

namespace App\Filament\Resources\CustomFieldOptions\Pages;

use App\Filament\Resources\CustomFieldOptions\CustomFieldOptionResource;
use Filament\Actions\CreateAction;
use Filament\Resources\Pages\ListRecords;

class ListCustomFieldOptions extends ListRecords
{
    protected static string $resource = CustomFieldOptionResource::class;

    protected function getHeaderActions(): array
    {
        return [
            CreateAction::make(),
        ];
    }
}

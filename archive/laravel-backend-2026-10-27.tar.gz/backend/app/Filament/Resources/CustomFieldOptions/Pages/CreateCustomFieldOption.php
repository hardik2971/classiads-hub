<?php

namespace App\Filament\Resources\CustomFieldOptions\Pages;

use App\Filament\Resources\CustomFieldOptions\CustomFieldOptionResource;
use Filament\Resources\Pages\CreateRecord;

class CreateCustomFieldOption extends CreateRecord
{
    protected static string $resource = CustomFieldOptionResource::class;
}

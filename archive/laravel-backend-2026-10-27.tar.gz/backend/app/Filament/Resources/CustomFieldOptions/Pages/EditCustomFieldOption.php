<?php

namespace App\Filament\Resources\CustomFieldOptions\Pages;

use App\Filament\Resources\CustomFieldOptions\CustomFieldOptionResource;
use Filament\Actions\DeleteAction;
use Filament\Resources\Pages\EditRecord;

class EditCustomFieldOption extends EditRecord
{
    protected static string $resource = CustomFieldOptionResource::class;

    protected function getHeaderActions(): array
    {
        return [
            DeleteAction::make(),
        ];
    }
}

<?php

namespace App\Filament\Resources\CustomFieldOptions;

use App\Filament\Resources\CustomFieldOptions\Pages\CreateCustomFieldOption;
use App\Filament\Resources\CustomFieldOptions\Pages\EditCustomFieldOption;
use App\Filament\Resources\CustomFieldOptions\Pages\ListCustomFieldOptions;
use App\Filament\Resources\CustomFieldOptions\Schemas\CustomFieldOptionForm;
use App\Filament\Resources\CustomFieldOptions\Tables\CustomFieldOptionsTable;
use App\Models\CustomFieldOption;
use BackedEnum;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Table;

class CustomFieldOptionResource extends Resource
{
    protected static ?string $model = CustomFieldOption::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedRectangleStack;

    protected static string | \UnitEnum | null $navigationGroup = 'Catalog';

    public static function form(Schema $schema): Schema
    {
        return CustomFieldOptionForm::configure($schema);
    }

    public static function table(Table $table): Table
    {
        return CustomFieldOptionsTable::configure($table);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => ListCustomFieldOptions::route('/'),
            'create' => CreateCustomFieldOption::route('/create'),
            'edit' => EditCustomFieldOption::route('/{record}/edit'),
        ];
    }
}

<?php

namespace App\Filament\Resources\VerificationRequests;

use App\Filament\Resources\VerificationRequests\Pages\CreateVerificationRequest;
use App\Filament\Resources\VerificationRequests\Pages\EditVerificationRequest;
use App\Filament\Resources\VerificationRequests\Pages\ListVerificationRequests;
use App\Filament\Resources\VerificationRequests\Schemas\VerificationRequestForm;
use App\Filament\Resources\VerificationRequests\Tables\VerificationRequestsTable;
use App\Models\VerificationRequest;
use BackedEnum;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Table;

class VerificationRequestResource extends Resource
{
    protected static ?string $model = VerificationRequest::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedIdentification;

    protected static string | \UnitEnum | null $navigationGroup = 'Seller Management';

    protected static ?string $navigationLabel = 'Seller Verification';

    protected static ?int $navigationSort = 2;

    public static function form(Schema $schema): Schema
    {
        return VerificationRequestForm::configure($schema);
    }

    public static function table(Table $table): Table
    {
        return VerificationRequestsTable::configure($table);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => ListVerificationRequests::route('/'),
            'create' => CreateVerificationRequest::route('/create'),
            'edit' => EditVerificationRequest::route('/{record}/edit'),
        ];
    }
}

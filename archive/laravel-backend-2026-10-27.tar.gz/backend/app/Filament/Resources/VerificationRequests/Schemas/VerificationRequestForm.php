<?php

namespace App\Filament\Resources\VerificationRequests\Schemas;

use Filament\Forms\Components\DateTimePicker;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Schemas\Schema;

class VerificationRequestForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                Select::make('user_id')
                    ->relationship('user', 'name')
                    ->required(),
                Select::make('document_type')
                    ->options([
            'id_card' => 'Id card',
            'passport' => 'Passport',
            'driving_license' => 'Driving license',
            'other' => 'Other',
        ])
                    ->required(),
                TextInput::make('document_number')
                    ->default(null),
                FileUpload::make('front_image_path')
                    ->image()
                    ->required(),
                FileUpload::make('back_image_path')
                    ->image(),
                FileUpload::make('selfie_image_path')
                    ->image(),
                Select::make('status')
                    ->options(['pending' => 'Pending', 'approved' => 'Approved', 'rejected' => 'Rejected'])
                    ->default('pending')
                    ->required(),
                TextInput::make('rejection_reason')
                    ->default(null),
                TextInput::make('reviewed_by')
                    ->numeric()
                    ->default(null),
                DateTimePicker::make('reviewed_at'),
            ]);
    }
}

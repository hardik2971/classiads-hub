<?php

namespace App\Filament\Resources\Faqs\Schemas;

use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Tabs;
use Filament\Schemas\Components\Tabs\Tab;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Schemas\Schema;

class FaqForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                Section::make('Add FAQ')
                    ->schema([
                        Tabs::make('locales')
                            ->tabs([
                                Tab::make('English')
                                    ->schema([
                                        TextInput::make('question')
                                            ->label('Question (English)')
                                            ->required()
                                            ->maxLength(500),
                                        Textarea::make('answer')
                                            ->label('Answer (English)')
                                            ->required()
                                            ->rows(5),
                                    ]),
                                Tab::make('Français')
                                    ->schema([
                                        TextInput::make('translations.fr.question')
                                            ->label('Question (Français)')
                                            ->maxLength(500),
                                        Textarea::make('translations.fr.answer')
                                            ->label('Answer (Français)')
                                            ->rows(5),
                                    ]),
                                Tab::make('عربي')
                                    ->schema([
                                        TextInput::make('translations.ar.question')
                                            ->label('Question (عربي)')
                                            ->maxLength(500),
                                        Textarea::make('translations.ar.answer')
                                            ->label('Answer (عربي)')
                                            ->rows(5),
                                    ]),
                                Tab::make('Ð ÑƒÑÑÐºÐ¸Ð¹')
                                    ->schema([
                                        TextInput::make('translations.ru.question')
                                            ->label('Question (Ð ÑƒÑÑÐºÐ¸Ð¹)')
                                            ->maxLength(500),
                                        Textarea::make('translations.ru.answer')
                                            ->label('Answer (Ð ÑƒÑÑÐºÐ¸Ð¹)')
                                            ->rows(5),
                                    ]),
                            ])
                            ->columnSpanFull(),

                        TextInput::make('sort_order')
                            ->label('Sort Order')
                            ->numeric()
                            ->default(0),

                        Toggle::make('is_active')
                            ->label('Active')
                            ->default(true),
                    ])
                    ->columns(2),
            ]);
    }
}

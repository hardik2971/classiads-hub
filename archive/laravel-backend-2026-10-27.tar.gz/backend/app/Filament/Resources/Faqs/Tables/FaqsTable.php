<?php

namespace App\Filament\Resources\Faqs\Tables;

use App\Models\Faq;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class FaqsTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('id')
                    ->label('ID')
                    ->sortable()
                    ->weight('semibold'),

                TextColumn::make('question')
                    ->label('Questions')
                    ->searchable()
                    ->wrap()
                    ->color('info'),

                TextColumn::make('answer')
                    ->label('Answers')
                    ->searchable()
                    ->wrap()
                    ->limit(120)
                    ->tooltip(fn (Faq $r) => $r->answer),
            ])
            ->defaultSort('sort_order', 'desc')
            ->reorderable('sort_order')
            ->recordActions([
                EditAction::make()->iconButton(),
                DeleteAction::make()->iconButton(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ]);
    }
}

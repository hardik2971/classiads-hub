<?php

namespace App\Filament\Resources\SellerReviewReports\Tables;

use App\Models\Report;
use App\Models\Review;
use Filament\Actions\Action;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Notifications\Notification;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Table;

class SellerReviewReportsTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->modifyQueryUsing(fn ($query) => $query->with(['reporter', 'reportable.reviewee', 'reportable.reviewer']))
            ->columns([
                TextColumn::make('id')
                    ->label('ID')
                    ->sortable()
                    ->weight('semibold'),

                TextColumn::make('reporter.name')
                    ->label('Reported By')
                    ->searchable(),

                TextColumn::make('review_target')
                    ->label('Review Of')
                    ->getStateUsing(function (Report $r): string {
                        $review = $r->reportable;
                        if (! $review instanceof Review) {
                            return '—';
                        }
                        return $review->reviewee?->name ?? "Review #{$review->id}";
                    }),

                TextColumn::make('review_excerpt')
                    ->label('Review')
                    ->getStateUsing(function (Report $r): string {
                        $review = $r->reportable;
                        if (! $review instanceof Review) {
                            return '—';
                        }
                        return \Illuminate\Support\Str::limit($review->comment ?? '', 60, '…');
                    })
                    ->wrap()
                    ->color('gray'),

                TextColumn::make('reason')
                    ->label('Reason')
                    ->limit(40)
                    ->tooltip(fn (Report $r) => $r->details),

                TextColumn::make('status')
                    ->label('Status')
                    ->badge()
                    ->formatStateUsing(fn (string $s) => ucfirst($s))
                    ->color(fn (string $s) => match ($s) {
                        'open'      => 'warning',
                        'resolved'  => 'success',
                        'dismissed' => 'gray',
                        default     => 'info',
                    }),

                TextColumn::make('created_at')
                    ->label('Created At')
                    ->dateTime('d-m-y H:i:s')
                    ->sortable(),
            ])
            ->defaultSort('id', 'desc')
            ->filters([
                SelectFilter::make('status')
                    ->options([
                        'open'      => 'Open',
                        'resolved'  => 'Resolved',
                        'dismissed' => 'Dismissed',
                    ]),
            ])
            ->recordActions([
                Action::make('resolve')
                    ->icon('heroicon-o-check-circle')
                    ->color('success')
                    ->visible(fn (Report $r) => $r->status === 'open')
                    ->requiresConfirmation()
                    ->action(function (Report $r) {
                        $r->update([
                            'status'      => 'resolved',
                            'resolved_at' => now(),
                            'resolved_by' => auth()->id(),
                        ]);
                        Notification::make()->title('Report resolved')->success()->send();
                    }),

                Action::make('dismiss')
                    ->icon('heroicon-o-x-mark')
                    ->color('gray')
                    ->visible(fn (Report $r) => $r->status === 'open')
                    ->requiresConfirmation()
                    ->action(function (Report $r) {
                        $r->update([
                            'status'      => 'dismissed',
                            'resolved_at' => now(),
                            'resolved_by' => auth()->id(),
                        ]);
                        Notification::make()->title('Report dismissed')->warning()->send();
                    }),

                EditAction::make()->iconButton(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ]);
    }
}

<?php

namespace App\Filament\Resources\SellerReviewReports\Pages;

use App\Filament\Resources\SellerReviewReports\SellerReviewReportResource;
use Filament\Resources\Pages\EditRecord;

class EditSellerReviewReport extends EditRecord
{
    protected static string $resource = SellerReviewReportResource::class;

    protected function getRedirectUrl(): string
    {
        return $this->getResource()::getUrl('index');
    }
}

<?php

namespace App\Filament\Resources\SellerReviewReports\Pages;

use App\Filament\Resources\SellerReviewReports\SellerReviewReportResource;
use Filament\Resources\Pages\ListRecords;

class ListSellerReviewReports extends ListRecords
{
    protected static string $resource = SellerReviewReportResource::class;

    protected function getHeaderActions(): array
    {
        return [];
    }
}

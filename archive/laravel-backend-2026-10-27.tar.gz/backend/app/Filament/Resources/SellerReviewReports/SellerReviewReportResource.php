<?php

namespace App\Filament\Resources\SellerReviewReports;

use App\Filament\Resources\SellerReviewReports\Pages\EditSellerReviewReport;
use App\Filament\Resources\SellerReviewReports\Pages\ListSellerReviewReports;
use App\Filament\Resources\SellerReviewReports\Schemas\SellerReviewReportForm;
use App\Filament\Resources\SellerReviewReports\Tables\SellerReviewReportsTable;
use App\Models\Report;
use App\Models\Review;
use BackedEnum;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use UnitEnum;

class SellerReviewReportResource extends Resource
{
    protected static ?string $model = Report::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedFlag;

    protected static string | UnitEnum | null $navigationGroup = 'Seller Management';

    protected static ?string $navigationLabel = 'Seller Review Reports';

    protected static ?string $modelLabel = 'Seller Review Report';

    protected static ?string $pluralModelLabel = 'Seller Review Reports';

    protected static ?string $slug = 'seller-review-reports';

    protected static ?int $navigationSort = 4;

    /**
     * Only show Report rows that target a Review.
     */
    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()
            ->where('reportable_type', Review::class);
    }

    public static function form(Schema $schema): Schema
    {
        return SellerReviewReportForm::configure($schema);
    }

    public static function table(Table $table): Table
    {
        return SellerReviewReportsTable::configure($table);
    }

    public static function getPages(): array
    {
        return [
            'index' => ListSellerReviewReports::route('/'),
            'edit'  => EditSellerReviewReport::route('/{record}/edit'),
        ];
    }
}

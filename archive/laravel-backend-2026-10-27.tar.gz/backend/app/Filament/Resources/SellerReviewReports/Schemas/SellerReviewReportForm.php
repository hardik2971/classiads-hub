<?php

namespace App\Filament\Resources\SellerReviewReports\Schemas;

use Filament\Schemas\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Schemas\Schema;

class SellerReviewReportForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                Section::make('Review the Report')
                    ->schema([
                        TextInput::make('reporter.name')
                            ->label('Reported By')
                            ->disabled(),

                        TextInput::make('reason')
                            ->label('Reason')
                            ->disabled(),

                        Textarea::make('details')
                            ->label('Details from reporter')
                            ->disabled()
                            ->rows(3)
                            ->columnSpanFull(),

                        Select::make('status')
                            ->label('Decision')
                            ->options([
                                'open'      => 'Open',
                                'resolved'  => 'Resolved',
                                'dismissed' => 'Dismissed',
                            ])
                            ->required(),
                    ])
                    ->columns(2),
            ]);
    }
}

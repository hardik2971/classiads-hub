<?php

namespace App\Filament\Resources\Cities\Tables;

use App\Models\Country;
use App\Models\State;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Enums\FiltersLayout;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Table;

class CitiesTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->modifyQueryUsing(fn ($query) => $query->with(['country', 'state']))
            ->columns([
                TextColumn::make('id')
                    ->label('ID')
                    ->sortable()
                    ->weight('semibold'),

                TextColumn::make('name')
                    ->label('Name')
                    ->searchable()
                    ->color('info'),

                TextColumn::make('country.name')
                    ->label('Country Name'),

                TextColumn::make('state.name')
                    ->label('State Name')
                    ->color('info'),

                TextColumn::make('longitude')
                    ->label('Longitude')
                    ->placeholder('-'),

                TextColumn::make('latitude')
                    ->label('Latitude')
                    ->placeholder('-'),

                TextColumn::make('country.iso2')
                    ->label('Flag')
                    ->color('gray'),
            ])
            ->defaultSort('id', 'desc')
            ->filters([
                SelectFilter::make('country_id')
                    ->label('Country')
                    ->options(fn () => Country::orderBy('name')->pluck('name', 'id')->all())
                    ->searchable(),

                SelectFilter::make('state_id')
                    ->label('State')
                    ->options(fn () => State::orderBy('name')->limit(500)->pluck('name', 'id')->all())
                    ->searchable(),
            ], layout: FiltersLayout::AboveContent)
            ->filtersFormColumns(2)
            ->recordActions([
                EditAction::make()->iconButton(),
                DeleteAction::make()->iconButton(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ]);
    }
}

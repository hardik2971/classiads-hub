<?php

namespace App\Filament\Resources\Areas\Tables;

use App\Models\City;
use App\Models\Country;
use App\Models\State;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Enums\FiltersLayout;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Table;

class AreasTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->modifyQueryUsing(fn ($query) => $query->with(['country', 'state', 'city']))
            ->columns([
                TextColumn::make('id')
                    ->label('ID')
                    ->sortable()
                    ->weight('semibold'),

                TextColumn::make('name')
                    ->label('Name')
                    ->searchable()
                    ->color('info'),

                TextColumn::make('country.name')
                    ->label('Country'),

                TextColumn::make('state.name')
                    ->label('State'),

                TextColumn::make('city.name')
                    ->label('City')
                    ->color('info'),

                TextColumn::make('longitude')
                    ->label('Longitude')
                    ->placeholder('-'),

                TextColumn::make('latitude')
                    ->label('Latitude')
                    ->placeholder('-'),
            ])
            ->defaultSort('id', 'desc')
            ->filters([
                SelectFilter::make('country_id')
                    ->label('Country')
                    ->options(fn () => Country::orderBy('name')->pluck('name', 'id')->all())
                    ->searchable(),

                SelectFilter::make('state_id')
                    ->label('State')
                    ->options(fn () => State::orderBy('name')->limit(500)->pluck('name', 'id')->all())
                    ->searchable(),

                SelectFilter::make('city_id')
                    ->label('City')
                    ->options(fn () => City::orderBy('name')->limit(500)->pluck('name', 'id')->all())
                    ->searchable(),
            ], layout: FiltersLayout::AboveContent)
            ->filtersFormColumns(3)
            ->recordActions([
                EditAction::make()->iconButton(),
                DeleteAction::make()->iconButton(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ]);
    }
}

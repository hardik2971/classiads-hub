<?php

namespace App\Filament\Resources\Areas\Pages;

use App\Filament\Resources\Areas\AreaResource;
use Filament\Actions\Action;
use Filament\Actions\CreateAction;
use Filament\Resources\Pages\ListRecords;

class ListAreas extends ListRecords
{
    protected static string $resource = AreaResource::class;

    protected function getHeaderActions(): array
    {
        return [
            CreateAction::make()->label('Add Area'),

            Action::make('translate_areas')
                ->label('Translate Areas')
                ->icon('heroicon-o-language')
                ->color('info')
                ->url(fn () => route('filament.admin.resources.translations.index', [
                    'tableFilters[group][value]' => 'areas',
                ]))
                ->openUrlInNewTab(false),
        ];
    }
}

<?php

namespace App\Filament\Resources\Areas\Schemas;

use App\Models\City;
use App\Models\Country;
use App\Models\State;
use Filament\Forms\Components\Placeholder;
use Filament\Schemas\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Schemas\Schema;
use Illuminate\Support\HtmlString;

class AreaForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                Section::make('Add Area')
                    ->schema([
                        Select::make('country_id')
                            ->label('Country')
                            ->options(fn () => Country::orderBy('name')->pluck('name', 'id')->all())
                            ->searchable()
                            ->preload()
                            ->required()
                            ->live(),

                        Select::make('state_id')
                            ->label('State')
                            ->options(fn (callable $get) => State::query()
                                ->when($get('country_id'), fn ($q, $v) => $q->where('country_id', $v))
                                ->orderBy('name')
                                ->pluck('name', 'id')
                                ->all())
                            ->searchable()
                            ->required()
                            ->live(),

                        Select::make('city_id')
                            ->label('City')
                            ->options(fn (callable $get) => City::query()
                                ->when($get('state_id'), fn ($q, $v) => $q->where('state_id', $v))
                                ->orderBy('name')
                                ->pluck('name', 'id')
                                ->all())
                            ->searchable()
                            ->required(),

                        TextInput::make('name')
                            ->label('Area Name')
                            ->required()
                            ->maxLength(150),

                        TextInput::make('latitude')
                            ->label('Latitude')
                            ->numeric()
                            ->placeholder('Enter Latitude'),

                        TextInput::make('longitude')
                            ->label('Longitude')
                            ->numeric()
                            ->placeholder('Enter Longitude'),

                        Placeholder::make('map_hint')
                            ->label('')
                            ->content(new HtmlString(
                                '<div style="background:#FCD34D;border:1px solid #F59E0B;border-radius:8px;padding:10px 14px;color:#78350F;font-size:13px;">
                                    Please enter latitude / longitude above. Live map preview ships with the next Google Maps wiring task.
                                </div>'
                            ))
                            ->columnSpanFull(),

                        Toggle::make('is_active')
                            ->label('Active')
                            ->default(true),
                    ])
                    ->columns(3),
            ]);
    }
}

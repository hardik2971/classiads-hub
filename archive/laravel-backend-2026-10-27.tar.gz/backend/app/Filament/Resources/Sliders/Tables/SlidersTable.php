<?php

namespace App\Filament\Resources\Sliders\Tables;

use App\Models\Slider;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Tables\Columns\ImageColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;

class SlidersTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->modifyQueryUsing(fn ($query) => $query->with([
                'ad.country', 'ad.state', 'ad.city',
                'category',
            ]))
            ->columns([
                TextColumn::make('id')
                    ->label('ID')
                    ->sortable()
                    ->weight('semibold'),

                ImageColumn::make('image_path')
                    ->label('Image')
                    ->size(60),

                TextColumn::make('link_type')
                    ->label('Type')
                    ->formatStateUsing(fn (?string $s) => match ($s) {
                        'ad'       => 'Advertisement',
                        'category' => 'Category',
                        'external' => 'Link',
                        default    => '—',
                    })
                    ->badge()
                    ->color(fn (?string $s) => match ($s) {
                        'ad'       => 'success',
                        'category' => 'info',
                        'external' => 'warning',
                        default    => 'gray',
                    }),

                TextColumn::make('display_name')
                    ->label('Name')
                    ->getStateUsing(fn (Slider $r): string => $r->ad?->title
                        ?? $r->category?->name
                        ?? $r->title
                        ?? '—')
                    ->searchable(query: function (Builder $query, string $search): Builder {
                        return $query->where('title', 'like', "%{$search}%")
                            ->orWhereHas('ad', fn ($q) => $q->where('title', 'like', "%{$search}%"))
                            ->orWhereHas('category', fn ($q) => $q->where('name', 'like', "%{$search}%"));
                    }),

                TextColumn::make('country_name')
                    ->label('Country')
                    ->getStateUsing(fn (Slider $r): string => $r->ad?->country?->name ?? '—'),

                TextColumn::make('state_name')
                    ->label('State')
                    ->getStateUsing(fn (Slider $r): string => $r->ad?->state?->name ?? '—'),

                TextColumn::make('city_name')
                    ->label('City')
                    ->getStateUsing(fn (Slider $r): string => $r->ad?->city?->name ?? '—'),

                TextColumn::make('external_url')
                    ->label('Third Party Link')
                    ->limit(40)
                    ->copyable()
                    ->placeholder('—')
                    ->color('info'),
            ])
            ->defaultSort('id', 'desc')
            ->recordActions([
                DeleteAction::make()->iconButton(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ]);
    }
}

<?php

namespace App\Filament\Resources\Ads\Pages;

use App\Filament\Resources\Ads\AdResource;
use App\Models\Ad;
use Filament\Actions\CreateAction;
use Filament\Schemas\Components\Tabs\Tab;
use Filament\Resources\Pages\ListRecords;
use Illuminate\Database\Eloquent\Builder;

class ListAds extends ListRecords
{
    protected static string $resource = AdResource::class;

    protected function getHeaderActions(): array
    {
        return [
            CreateAction::make()->label('Create Advertisement'),
        ];
    }

    /**
     * Top-of-page tabs matching the reference mock:
     *   Active Advertisements · Requested Advertisements · All Advertisements.
     */
    public function getTabs(): array
    {
        return [
            'active' => Tab::make('Active Advertisements')
                ->modifyQueryUsing(fn (Builder $q) => $q->where('status', 'approved'))
                ->badge(fn () => Ad::query()->where('status', 'approved')->count())
                ->badgeColor('success'),

            'requested' => Tab::make('Requested Advertisements')
                ->modifyQueryUsing(fn (Builder $q) => $q->where('status', 'pending'))
                ->badge(fn () => Ad::query()->where('status', 'pending')->count())
                ->badgeColor('info'),

            'all' => Tab::make('All Advertisements')
                ->badge(fn () => Ad::query()->count())
                ->badgeColor('gray'),
        ];
    }

    public function getDefaultActiveTab(): string | int | null
    {
        return 'all';
    }
}

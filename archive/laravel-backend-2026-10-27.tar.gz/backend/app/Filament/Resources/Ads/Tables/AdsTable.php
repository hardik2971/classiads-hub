<?php

namespace App\Filament\Resources\Ads\Tables;

use App\Models\Ad;
use App\Models\Category;
use App\Models\City;
use App\Models\Country;
use App\Models\State;
use Filament\Actions\Action;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Forms\Components\Textarea;
use Filament\Notifications\Notification;
use Filament\Tables\Columns\ImageColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Enums\FiltersLayout;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Filters\TernaryFilter;
use Filament\Tables\Table;

class AdsTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('id')
                    ->label('ID')
                    ->sortable()
                    ->weight('semibold'),

                TextColumn::make('title')
                    ->label('Name')
                    ->searchable()
                    ->limit(20)
                    ->weight('semibold'),

                TextColumn::make('description')
                    ->label('Description')
                    ->limit(48)
                    ->tooltip(fn (Ad $r) => $r->description)
                    ->wrap()
                    ->color('gray'),

                TextColumn::make('user.name')
                    ->label('User')
                    ->searchable()
                    ->description(fn (Ad $r) => $r->user?->email),

                TextColumn::make('price')
                    ->label('Price')
                    ->money(currency: fn (Ad $r) => $r->currency_code, divideBy: 100)
                    ->sortable(),

                TextColumn::make('category.name')
                    ->label('Category'),

                ImageColumn::make('primary_image')
                    ->label('Image')
                    ->getStateUsing(fn (Ad $r) => optional($r->images->first())->url)
                    ->circular()
                    ->size(40),

                ImageColumn::make('other_images')
                    ->label('Other Images')
                    ->getStateUsing(fn (Ad $r) => $r->images->slice(1)->take(3)->pluck('url')->all())
                    ->circular()
                    ->stacked()
                    ->limit(3)
                    ->limitedRemainingText()
                    ->size(40),

                TextColumn::make('address_full')
                    ->label('Address')
                    ->getStateUsing(function (Ad $r): string {
                        return collect([
                            $r->city?->name,
                            $r->state?->name,
                            $r->country?->name,
                        ])->filter()->join(', ');
                    })
                    ->limit(40)
                    ->wrap(),

                TextColumn::make('is_featured')
                    ->label('Featured or Not')
                    ->badge()
                    ->formatStateUsing(fn ($state) => $state ? 'Featured' : 'Not Featured')
                    ->color(fn ($state) => $state ? 'warning' : 'info'),

                TextColumn::make('status')
                    ->label('Status')
                    ->badge()
                    ->formatStateUsing(fn (string $state): string => match ($state) {
                        'pending'  => 'Under Review',
                        'approved' => 'Active',
                        'rejected' => 'Rejected',
                        'sold'     => 'Sold',
                        'expired'  => 'Expired',
                        'draft'    => 'Draft',
                        default    => ucfirst($state),
                    })
                    ->color(fn (string $state): string => match ($state) {
                        'approved' => 'success',
                        'pending'  => 'info',
                        'rejected' => 'danger',
                        'sold'     => 'gray',
                        'expired'  => 'danger',
                        default    => 'gray',
                    }),
            ])
            ->defaultSort('id', 'desc')
            ->filters([
                SelectFilter::make('category_id')
                    ->label('Category')
                    ->options(fn () => Category::orderBy('name')->pluck('name', 'id')->all())
                    ->searchable(),

                SelectFilter::make('status')
                    ->label('Status')
                    ->options([
                        'pending'  => 'Under Review',
                        'approved' => 'Active',
                        'rejected' => 'Rejected',
                        'sold'     => 'Sold',
                        'expired'  => 'Expired',
                        'draft'    => 'Draft',
                    ]),

                TernaryFilter::make('is_featured')
                    ->label('Featured')
                    ->placeholder('All')
                    ->trueLabel('Featured')
                    ->falseLabel('Not Featured'),

                SelectFilter::make('country_id')
                    ->label('Country')
                    ->options(fn () => Country::orderBy('name')->pluck('name', 'id')->all())
                    ->searchable(),

                SelectFilter::make('state_id')
                    ->label('State')
                    ->options(fn () => State::orderBy('name')->limit(500)->pluck('name', 'id')->all())
                    ->searchable(),

                SelectFilter::make('city_id')
                    ->label('City')
                    ->options(fn () => City::orderBy('name')->limit(500)->pluck('name', 'id')->all())
                    ->searchable(),
            ], layout: FiltersLayout::AboveContent)
            ->filtersFormColumns(6)
            ->recordActions([
                Action::make('approve')
                    ->icon('heroicon-o-check-circle')
                    ->color('success')
                    ->visible(fn (Ad $record) => in_array($record->status, ['pending', 'rejected'], true))
                    ->requiresConfirmation()
                    ->action(function (Ad $record) {
                        $record->update([
                            'status' => 'approved',
                            'approved_at' => now(),
                            'published_at' => $record->published_at ?? now(),
                            'rejection_reason' => null,
                        ]);
                        Notification::make()->title('Ad approved')->success()->send();
                    }),
                Action::make('reject')
                    ->icon('heroicon-o-x-circle')
                    ->color('danger')
                    ->visible(fn (Ad $record) => $record->status === 'pending')
                    ->schema([
                        Textarea::make('reason')->label('Rejection reason')->required()->maxLength(255),
                    ])
                    ->action(function (array $data, Ad $record) {
                        $record->update(['status' => 'rejected', 'rejection_reason' => $data['reason']]);
                        Notification::make()->title('Ad rejected')->warning()->send();
                    }),
                Action::make('feature')
                    ->icon('heroicon-o-star')
                    ->color('warning')
                    ->label(fn (Ad $record) => $record->is_featured ? 'Unfeature' : 'Feature')
                    ->action(function (Ad $record) {
                        $on = ! $record->is_featured;
                        $record->update([
                            'is_featured' => $on,
                            'featured_until' => $on ? now()->addDays(30) : null,
                        ]);
                        Notification::make()->title($on ? 'Ad featured' : 'Feature removed')->success()->send();
                    }),
                EditAction::make(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ]);
    }
}

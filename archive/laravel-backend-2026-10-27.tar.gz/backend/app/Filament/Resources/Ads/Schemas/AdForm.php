<?php

namespace App\Filament\Resources\Ads\Schemas;

use Filament\Forms\Components\DateTimePicker;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\Toggle;
use Filament\Schemas\Schema;

class AdForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                Select::make('user_id')
                    ->relationship('user', 'name')
                    ->required(),
                Select::make('category_id')
                    ->relationship('category', 'name')
                    ->required(),
                TextInput::make('title')
                    ->required(),
                TextInput::make('slug')
                    ->required(),
                Textarea::make('description')
                    ->required()
                    ->columnSpanFull(),
                TextInput::make('price')
                    ->numeric()
                    ->default(null)
                    ->prefix('$'),
                TextInput::make('currency_code')
                    ->required()
                    ->default('USD'),
                Select::make('price_type')
                    ->options(['fixed' => 'Fixed', 'negotiable' => 'Negotiable', 'free' => 'Free', 'contact' => 'Contact'])
                    ->default('fixed')
                    ->required(),
                Select::make('condition')
                    ->options(['new' => 'New', 'used' => 'Used', 'refurbished' => 'Refurbished'])
                    ->default(null),
                TextInput::make('phone')
                    ->tel()
                    ->default(null),
                TextInput::make('video_url')
                    ->url()
                    ->default(null),
                Select::make('country_id')
                    ->relationship('country', 'name')
                    ->default(null),
                Select::make('state_id')
                    ->relationship('state', 'name')
                    ->default(null),
                Select::make('city_id')
                    ->relationship('city', 'name')
                    ->default(null),
                TextInput::make('address')
                    ->default(null),
                TextInput::make('latitude')
                    ->numeric()
                    ->default(null),
                TextInput::make('longitude')
                    ->numeric()
                    ->default(null),
                Select::make('status')
                    ->options([
            'draft' => 'Draft',
            'pending' => 'Pending',
            'approved' => 'Approved',
            'rejected' => 'Rejected',
            'sold' => 'Sold',
            'expired' => 'Expired',
        ])
                    ->default('pending')
                    ->required(),
                TextInput::make('rejection_reason')
                    ->default(null),
                Toggle::make('is_featured')
                    ->required(),
                DateTimePicker::make('featured_until'),
                TextInput::make('views_count')
                    ->required()
                    ->numeric()
                    ->default(0),
                TextInput::make('favorites_count')
                    ->required()
                    ->numeric()
                    ->default(0),
                DateTimePicker::make('approved_at'),
                DateTimePicker::make('sold_at'),
                DateTimePicker::make('published_at'),
                DateTimePicker::make('expires_at'),
            ]);
    }
}

<?php

namespace App\Filament\Resources\UserQueries\Tables;

use App\Models\UserQuery;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\ViewAction;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class UserQueriesTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('id')
                    ->label('ID')
                    ->sortable()
                    ->weight('semibold'),

                TextColumn::make('name')
                    ->label('Name')
                    ->searchable(),

                TextColumn::make('email')
                    ->label('Email')
                    ->searchable()
                    ->copyable(),

                TextColumn::make('subject')
                    ->label('Subject')
                    ->searchable()
                    ->color('info'),

                TextColumn::make('message')
                    ->label('Message')
                    ->limit(80)
                    ->wrap()
                    ->tooltip(fn (UserQuery $r) => $r->message),
            ])
            ->defaultSort('id', 'desc')
            ->recordActions([
                ViewAction::make()->iconButton(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ]);
    }
}

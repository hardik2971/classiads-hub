<?php

namespace App\Filament\Resources\UserQueries\Schemas;

use Filament\Schemas\Components\Section;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Schemas\Schema;

class UserQueryForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                Section::make('User Query')
                    ->schema([
                        TextInput::make('name')->label('Name')->disabled(),
                        TextInput::make('email')->label('Email')->disabled(),
                        TextInput::make('subject')->label('Subject')->disabled(),
                        Textarea::make('message')
                            ->label('Message')
                            ->disabled()
                            ->rows(6)
                            ->columnSpanFull(),
                    ])
                    ->columns(2),
            ]);
    }
}

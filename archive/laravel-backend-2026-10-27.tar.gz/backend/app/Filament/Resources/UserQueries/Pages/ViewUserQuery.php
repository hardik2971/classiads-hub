<?php

namespace App\Filament\Resources\UserQueries\Pages;

use App\Filament\Resources\UserQueries\UserQueryResource;
use Filament\Resources\Pages\ViewRecord;

class ViewUserQuery extends ViewRecord
{
    protected static string $resource = UserQueryResource::class;
}

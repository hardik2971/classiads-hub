<?php

namespace App\Filament\Resources\UserQueries;

use App\Filament\Resources\UserQueries\Pages\ListUserQueries;
use App\Filament\Resources\UserQueries\Pages\ViewUserQuery;
use App\Filament\Resources\UserQueries\Schemas\UserQueryForm;
use App\Filament\Resources\UserQueries\Tables\UserQueriesTable;
use App\Models\UserQuery;
use BackedEnum;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Table;
use UnitEnum;

class UserQueryResource extends Resource
{
    protected static ?string $model = UserQuery::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedEnvelope;

    protected static string | UnitEnum | null $navigationGroup = 'User & Roles';

    protected static ?string $navigationLabel = 'User Queries';

    protected static ?string $modelLabel = 'User Query';

    protected static ?string $pluralModelLabel = 'User Queries';

    protected static ?string $slug = 'user-queries';

    protected static ?int $navigationSort = 4;

    public static function form(Schema $schema): Schema
    {
        return UserQueryForm::configure($schema);
    }

    public static function table(Table $table): Table
    {
        return UserQueriesTable::configure($table);
    }

    public static function getPages(): array
    {
        return [
            'index' => ListUserQueries::route('/'),
            'view'  => ViewUserQuery::route('/{record}'),
        ];
    }
}

<?php

namespace App\Filament\Resources\Roles\Schemas;

use Filament\Forms\Components\CheckboxList;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Schemas\Schema;

class RoleForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                TextInput::make('name')
                    ->required()
                    ->maxLength(255)
                    ->unique(ignoreRecord: true),
                Select::make('guard_name')
                    ->options(['web' => 'web', 'api' => 'api'])
                    ->default('web')
                    ->required()
                    ->helperText('The auth guard this role belongs to (admin panel uses "web").'),
                CheckboxList::make('permissions')
                    ->relationship('permissions', 'name')
                    ->searchable()
                    ->bulkToggleable()
                    ->columns(3)
                    ->columnSpanFull()
                    ->helperText('super-admin is granted everything implicitly via Gate::before regardless of these.'),
            ]);
    }
}

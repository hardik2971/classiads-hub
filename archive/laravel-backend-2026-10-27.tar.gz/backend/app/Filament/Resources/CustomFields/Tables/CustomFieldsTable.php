<?php

namespace App\Filament\Resources\CustomFields\Tables;

use App\Models\CustomField;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Tables\Columns\ImageColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Enums\FiltersLayout;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Table;

class CustomFieldsTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->modifyQueryUsing(fn ($query) => $query->with('categories.parent.parent'))
            ->columns([
                TextColumn::make('id')
                    ->label('ID')
                    ->sortable()
                    ->weight('semibold'),

                ImageColumn::make('icon_path')
                    ->label('Image')
                    ->circular()
                    ->size(40),

                TextColumn::make('name')
                    ->label('Name')
                    ->searchable()
                    ->weight('semibold'),

                TextColumn::make('category_path')
                    ->label('Category')
                    ->getStateUsing(function (CustomField $r): string {
                        $cat = $r->categories->first();
                        if (! $cat) {
                            return '—';
                        }
                        $crumbs = [];
                        $current = $cat;
                        while ($current) {
                            array_unshift($crumbs, $current->name);
                            $current = $current->parent;
                        }
                        return implode(' > ', $crumbs);
                    })
                    ->color('info'),

                TextColumn::make('type')
                    ->label('Type')
                    ->color('gray'),
            ])
            ->defaultSort('id', 'desc')
            ->filters([
                SelectFilter::make('category')
                    ->label('Category')
                    ->relationship('categories', 'name')
                    ->searchable()
                    ->preload(),

                SelectFilter::make('type')
                    ->label('Type')
                    ->options([
                        'textbox'  => 'Textbox',
                        'textarea' => 'Textarea',
                        'number'   => 'Number',
                        'dropdown' => 'Dropdown',
                        'radio'    => 'Radio',
                        'checkbox' => 'Checkbox',
                        'date'     => 'Date',
                        'file'     => 'File',
                    ]),
            ], layout: FiltersLayout::AboveContent)
            ->filtersFormColumns(2)
            ->recordActions([
                EditAction::make()->iconButton(),
                DeleteAction::make()->iconButton(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ]);
    }
}

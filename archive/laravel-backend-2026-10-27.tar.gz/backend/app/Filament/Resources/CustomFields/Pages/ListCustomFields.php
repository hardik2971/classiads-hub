<?php

namespace App\Filament\Resources\CustomFields\Pages;

use App\Filament\Resources\CustomFields\CustomFieldResource;
use Filament\Actions\Action;
use Filament\Actions\CreateAction;
use Filament\Forms\Components\FileUpload;
use Filament\Notifications\Notification;
use Filament\Resources\Pages\ListRecords;

class ListCustomFields extends ListRecords
{
    protected static string $resource = CustomFieldResource::class;

    protected function getHeaderActions(): array
    {
        return [
            CreateAction::make()
                ->label('Create Custom Field')
                ->icon('heroicon-o-plus'),

            Action::make('bulk_upload')
                ->label('Bulk Upload')
                ->icon('heroicon-o-arrow-up-tray')
                ->color('success')
                ->schema([
                    FileUpload::make('file')
                        ->label('CSV file')
                        ->acceptedFileTypes(['text/csv'])
                        ->required(),
                ])
                ->action(fn () => Notification::make()
                    ->title('Bulk upload received — parser not yet wired.')
                    ->warning()
                    ->send()),

            Action::make('bulk_update')
                ->label('Bulk Update')
                ->icon('heroicon-o-pencil-square')
                ->color('warning')
                ->schema([
                    FileUpload::make('file')
                        ->label('CSV file with id + fields to update')
                        ->acceptedFileTypes(['text/csv'])
                        ->required(),
                ])
                ->action(fn () => Notification::make()
                    ->title('Bulk update received — parser not yet wired.')
                    ->warning()
                    ->send()),
        ];
    }
}

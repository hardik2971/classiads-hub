<?php

namespace App\Filament\Resources\CustomFields\Schemas;

use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Schemas\Schema;

class CustomFieldForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                TextInput::make('name')
                    ->required(),
                TextInput::make('code')
                    ->required(),
                Select::make('type')
                    ->options([
            'text' => 'Text',
            'number' => 'Number',
            'dropdown' => 'Dropdown',
            'radio' => 'Radio',
            'checkbox' => 'Checkbox',
            'boolean' => 'Boolean',
            'date' => 'Date',
        ])
                    ->required(),
                TextInput::make('icon_path')
                    ->default(null),
                Toggle::make('is_required')
                    ->required(),
                Toggle::make('is_filterable')
                    ->required(),
                TextInput::make('sort_order')
                    ->required()
                    ->numeric()
                    ->default(0),
            ]);
    }
}

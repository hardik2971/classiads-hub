<?php

namespace App\Filament\Resources\Categories\Tables;

use App\Models\Category;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Tables\Columns\ImageColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Columns\ToggleColumn;
use Filament\Tables\Table;

class CategoriesTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->modifyQueryUsing(fn ($q) => $q
                ->withCount(['children', 'customFields', 'ads'])
                ->whereNull('parent_id'))
            ->columns([
                TextColumn::make('id')
                    ->label('ID')
                    ->sortable()
                    ->weight('semibold'),

                TextColumn::make('name')
                    ->label('Name')
                    ->searchable()
                    ->weight('semibold')
                    ->description(fn (Category $r) => $r->children_count > 0
                        ? '+ '.$r->children_count.' subcategories'
                        : null),

                ImageColumn::make('image_path')
                    ->label('Image')
                    ->circular()
                    ->size(40),

                TextColumn::make('children_count')
                    ->label('Subcategories')
                    ->numeric()
                    ->sortable()
                    ->formatStateUsing(fn (int $state) => $state.' Subcategories')
                    ->color('gray'),

                TextColumn::make('custom_fields_count')
                    ->label('Custom Fields')
                    ->numeric()
                    ->sortable()
                    ->formatStateUsing(fn (int $state) => $state.' Custom Fields')
                    ->color('gray'),

                TextColumn::make('ads_count')
                    ->label('Advertisement Count')
                    ->numeric()
                    ->sortable()
                    ->weight('semibold'),

                ToggleColumn::make('is_active')
                    ->label('Active'),
            ])
            ->defaultSort('sort_order')
            ->recordActions([
                EditAction::make()->iconButton(),
                DeleteAction::make()->iconButton(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ]);
    }
}

<?php

namespace App\Filament\Resources\Categories\Pages;

use App\Filament\Resources\Categories\CategoryResource;
use App\Models\Category;
use Filament\Actions\Action;
use Filament\Actions\CreateAction;
use Filament\Forms\Components\FileUpload;
use Filament\Notifications\Notification;
use Filament\Resources\Pages\ListRecords;

class ListCategories extends ListRecords
{
    protected static string $resource = CategoryResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Action::make('set_order')
                ->label('Set Order of Categories')
                ->icon('heroicon-o-arrows-up-down')
                ->color('info')
                ->url(fn () => static::getResource()::getUrl('index').'?tableSort[column]=sort_order')
                ->openUrlInNewTab(false),

            CreateAction::make()
                ->label('Add Category')
                ->icon('heroicon-o-plus'),

            Action::make('bulk_upload')
                ->label('Bulk Upload')
                ->icon('heroicon-o-arrow-up-tray')
                ->color('success')
                ->schema([
                    FileUpload::make('file')
                        ->label('CSV file')
                        ->acceptedFileTypes(['text/csv', 'text/plain', 'application/vnd.ms-excel'])
                        ->required(),
                ])
                ->action(function (array $data): void {
                    // TODO: parse CSV at $data['file'] and seed Category rows.
                    Notification::make()
                        ->title('Bulk upload received — parser not yet wired.')
                        ->warning()
                        ->send();
                }),

            Action::make('bulk_update')
                ->label('Bulk Update')
                ->icon('heroicon-o-pencil-square')
                ->color('warning')
                ->schema([
                    FileUpload::make('file')
                        ->label('CSV file with id + fields to update')
                        ->acceptedFileTypes(['text/csv', 'text/plain', 'application/vnd.ms-excel'])
                        ->required(),
                ])
                ->action(function (array $data): void {
                    Notification::make()
                        ->title('Bulk update received — parser not yet wired.')
                        ->warning()
                        ->send();
                }),
        ];
    }
}

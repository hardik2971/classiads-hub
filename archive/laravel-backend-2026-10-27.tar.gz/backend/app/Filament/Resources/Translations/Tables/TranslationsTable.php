<?php

namespace App\Filament\Resources\Translations\Tables;

use App\Models\Language;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Table;

class TranslationsTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->defaultSort('key')
            ->columns([
                TextColumn::make('locale')->badge()->sortable(),
                TextColumn::make('group')->badge()->color('gray')->sortable(),
                TextColumn::make('key')->searchable()->sortable(),
                TextColumn::make('value')->searchable()->limit(60)->wrap(),
                TextColumn::make('updated_at')->dateTime()->sortable()->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                SelectFilter::make('locale')
                    ->options(fn (): array => Language::query()->pluck('code', 'code')->all()),
                SelectFilter::make('group')
                    ->options(fn (): array => \App\Models\Translation::query()->distinct()->pluck('group', 'group')->all()),
            ])
            ->recordActions([
                EditAction::make(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ]);
    }
}

<?php

namespace App\Filament\Resources\Translations\Schemas;

use App\Models\Language;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Textarea;
use Filament\Schemas\Schema;

class TranslationForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                Select::make('locale')
                    ->options(fn (): array => Language::query()->pluck('code', 'code')->all())
                    ->searchable()
                    ->required(),
                TextInput::make('group')
                    ->default('common')
                    ->required()
                    ->maxLength(60)
                    ->helperText('Logical group, e.g. common / ad / auth.'),
                TextInput::make('key')
                    ->required()
                    ->maxLength(191)
                    ->helperText('Dot-notated, e.g. common.search.'),
                Textarea::make('value')
                    ->required()
                    ->rows(2)
                    ->columnSpanFull(),
            ]);
    }
}

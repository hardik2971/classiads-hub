<?php

namespace App\Filament\Resources\Users\Tables;

use App\Models\User;
use Filament\Actions\Action;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteBulkAction;
use Filament\Notifications\Notification;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Columns\ToggleColumn;
use Filament\Tables\Columns\ViewColumn;
use Filament\Tables\Table;

class UsersTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->modifyQueryUsing(fn ($q) => $q
                ->withCount('ads')
                ->with('socialAccounts'))
            ->columns([
                TextColumn::make('id')
                    ->label('ID')
                    ->sortable()
                    ->weight('semibold'),

                ViewColumn::make('profile_avatar')
                    ->label('Profile')
                    ->view('filament.resources.users.profile-cell'),

                TextColumn::make('name')
                    ->label('Name')
                    ->searchable(),

                TextColumn::make('masked_email')
                    ->label('Email')
                    ->searchable(query: fn ($query, string $s) =>
                        $query->where('email', 'like', "%{$s}%"))
                    ->getStateUsing(fn (User $r): string => self::maskEmail($r->email)),

                TextColumn::make('phone')
                    ->label('Mobile')
                    ->placeholder('-'),

                TextColumn::make('account_type')
                    ->label('Type')
                    ->getStateUsing(fn (User $r): string =>
                        optional($r->socialAccounts->first())->provider ?? 'email'),

                TextColumn::make('address')
                    ->label('Address')
                    ->placeholder('-'),

                TextColumn::make('ads_count')
                    ->label('Total Post')
                    ->numeric()
                    ->sortable(),

                ToggleColumn::make('is_active_toggle')
                    ->label('Status')
                    ->getStateUsing(fn (User $r) => $r->status === 'active')
                    ->updateStateUsing(function (User $r, bool $state) {
                        $r->update(['status' => $state ? 'active' : 'suspended']);
                        return $state;
                    }),

                ToggleColumn::make('auto_approve_advertisement')
                    ->label('Auto Approve Advertisement'),
            ])
            ->defaultSort('id', 'desc')
            ->recordActions([
                Action::make('subscribe')
                    ->label('')
                    ->icon('heroicon-o-shopping-cart')
                    ->iconButton()
                    ->color('danger')
                    ->tooltip('Manage subscription')
                    ->url(fn (User $r) => route('filament.admin.resources.subscriptions.index', ['tableFilters[user_id][value]' => $r->id])),

                Action::make('toggle_ban')
                    ->label('')
                    ->icon(fn (User $r) => $r->status === 'banned' ? 'heroicon-o-arrow-uturn-up' : 'heroicon-o-no-symbol')
                    ->iconButton()
                    ->color('info')
                    ->tooltip(fn (User $r) => $r->status === 'banned' ? 'Unban' : 'Ban')
                    ->requiresConfirmation()
                    ->action(function (User $r): void {
                        $next = $r->status === 'banned' ? 'active' : 'banned';
                        $r->update(['status' => $next]);
                        Notification::make()
                            ->title("User {$next}")
                            ->success()
                            ->send();
                    }),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ]);
    }

    /**
     * Mask local part of an email so PII doesn't leak in screenshots /
     * shared sessions. Returns `aku****@yahoo.com` style.
     */
    private static function maskEmail(?string $email): string
    {
        if (! $email) {
            return '-';
        }
        [$local, $domain] = array_pad(explode('@', $email, 2), 2, null);
        if (! $domain) {
            return $email;
        }
        $masked = mb_substr($local, 0, 3) . str_repeat('*', max(0, mb_strlen($local) - 3));
        return $masked . '@' . $domain;
    }
}

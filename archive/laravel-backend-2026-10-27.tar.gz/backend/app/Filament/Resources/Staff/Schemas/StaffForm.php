<?php

namespace App\Filament\Resources\Staff\Schemas;

use Filament\Schemas\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Schemas\Schema;
use Spatie\Permission\Models\Role;

class StaffForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                Section::make()
                    ->schema([
                        TextInput::make('name')
                            ->required()
                            ->maxLength(150),

                        TextInput::make('email')
                            ->email()
                            ->required()
                            ->maxLength(191)
                            ->unique(ignoreRecord: true),

                        TextInput::make('phone')
                            ->tel()
                            ->maxLength(32),

                        TextInput::make('password')
                            ->password()
                            ->minLength(8)
                            ->required(fn (string $operation): bool => $operation === 'create')
                            ->dehydrated(fn (?string $state) => filled($state))
                            ->helperText('Leave blank to keep current password (edit only).'),

                        Select::make('roles')
                            ->label('Role')
                            ->multiple()
                            ->relationship('roles', 'name')
                            ->options(fn () => Role::query()
                                ->where('name', '!=', 'customer')
                                ->pluck('name', 'name')
                                ->all())
                            ->required()
                            ->columnSpanFull(),

                        Toggle::make('is_active')
                            ->label('Status')
                            ->dehydrated(false)
                            ->afterStateHydrated(fn (Toggle $component, $record) =>
                                $component->state($record?->status === 'active'))
                            ->afterStateUpdated(function (?bool $state, $record) {
                                if ($record) {
                                    $record->update(['status' => $state ? 'active' : 'suspended']);
                                }
                            }),
                    ])
                    ->columns(2),
            ]);
    }
}

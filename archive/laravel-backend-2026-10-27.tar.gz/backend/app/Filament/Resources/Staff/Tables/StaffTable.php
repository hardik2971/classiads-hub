<?php

namespace App\Filament\Resources\Staff\Tables;

use App\Models\User;
use Filament\Actions\Action;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Forms\Components\TextInput;
use Filament\Notifications\Notification;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Columns\ToggleColumn;
use Filament\Tables\Table;
use Illuminate\Support\Facades\Hash;

class StaffTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('id')
                    ->label('ID')
                    ->sortable()
                    ->weight('semibold'),

                TextColumn::make('name')
                    ->label('Name')
                    ->searchable()
                    ->weight('semibold')
                    ->color('info'),

                TextColumn::make('email')
                    ->label('Email')
                    ->searchable(),

                ToggleColumn::make('is_active_toggle')
                    ->label('Status')
                    ->getStateUsing(fn (User $r) => $r->status === 'active')
                    ->updateStateUsing(function (User $r, bool $state) {
                        $r->update(['status' => $state ? 'active' : 'suspended']);
                        return $state;
                    }),
            ])
            ->defaultSort('id', 'desc')
            ->recordActions([
                EditAction::make()->iconButton(),

                Action::make('reset_password')
                    ->label('')
                    ->icon('heroicon-o-key')
                    ->iconButton()
                    ->color('info')
                    ->tooltip('Reset password')
                    ->schema([
                        TextInput::make('password')
                            ->label('New password')
                            ->password()
                            ->minLength(8)
                            ->required(),
                    ])
                    ->action(function (array $data, User $r): void {
                        $r->update(['password' => Hash::make($data['password'])]);
                        Notification::make()
                            ->title('Password reset')
                            ->success()
                            ->send();
                    }),

                DeleteAction::make()->iconButton(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ]);
    }
}

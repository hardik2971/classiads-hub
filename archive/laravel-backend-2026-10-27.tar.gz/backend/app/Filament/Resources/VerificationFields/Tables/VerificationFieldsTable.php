<?php

namespace App\Filament\Resources\VerificationFields\Tables;

use App\Models\VerificationField;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class VerificationFieldsTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('id')
                    ->label('ID')
                    ->sortable()
                    ->weight('semibold'),

                TextColumn::make('name')
                    ->label('Name')
                    ->searchable()
                    ->weight('semibold')
                    ->color('info'),

                TextColumn::make('min_length')
                    ->label('Min Length')
                    ->placeholder('-')
                    ->sortable(),

                TextColumn::make('max_length')
                    ->label('Max Length')
                    ->placeholder('-')
                    ->sortable(),

                TextColumn::make('values_list')
                    ->label('Values')
                    ->getStateUsing(fn (VerificationField $r) =>
                        empty($r->values) ? '-' : implode(', ', (array) $r->values)),
            ])
            ->defaultSort('sort_order', 'desc')
            ->recordActions([
                EditAction::make()->iconButton(),
                DeleteAction::make()->iconButton(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ]);
    }
}

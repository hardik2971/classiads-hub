<?php

namespace App\Filament\Resources\VerificationFields\Schemas;

use Filament\Schemas\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TagsInput;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Schemas\Schema;

class VerificationFieldForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                Section::make()
                    ->schema([
                        TextInput::make('name')
                            ->label('Name')
                            ->required()
                            ->maxLength(150)
                            ->columnSpanFull(),

                        Select::make('field_type')
                            ->label('Field Type')
                            ->options([
                                'text'   => 'Text',
                                'number' => 'Number',
                                'file'   => 'File upload',
                                'select' => 'Select from values',
                            ])
                            ->default('text')
                            ->required()
                            ->live(),

                        Toggle::make('is_required')
                            ->label('Required')
                            ->default(true),

                        TextInput::make('min_length')
                            ->label('Min Length')
                            ->numeric()
                            ->minValue(0)
                            ->maxValue(10000)
                            ->visible(fn (callable $get) => in_array($get('field_type'), ['text', 'number'], true)),

                        TextInput::make('max_length')
                            ->label('Max Length')
                            ->numeric()
                            ->minValue(1)
                            ->maxValue(10000)
                            ->visible(fn (callable $get) => in_array($get('field_type'), ['text', 'number'], true)),

                        TagsInput::make('values')
                            ->label('Allowed Values')
                            ->helperText('Press Enter after each value. Only used when Field Type is "Select".')
                            ->visible(fn (callable $get) => $get('field_type') === 'select')
                            ->columnSpanFull(),

                        TextInput::make('sort_order')
                            ->label('Sort Order')
                            ->numeric()
                            ->default(0),

                        Toggle::make('is_active')
                            ->label('Active')
                            ->default(true),
                    ])
                    ->columns(2),
            ]);
    }
}

<?php

namespace App\Filament\Resources\VerificationFields;

use App\Filament\Resources\VerificationFields\Pages\CreateVerificationField;
use App\Filament\Resources\VerificationFields\Pages\EditVerificationField;
use App\Filament\Resources\VerificationFields\Pages\ListVerificationFields;
use App\Filament\Resources\VerificationFields\Schemas\VerificationFieldForm;
use App\Filament\Resources\VerificationFields\Tables\VerificationFieldsTable;
use App\Models\VerificationField;
use BackedEnum;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Table;
use UnitEnum;

class VerificationFieldResource extends Resource
{
    protected static ?string $model = VerificationField::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedShieldCheck;

    protected static string | UnitEnum | null $navigationGroup = 'Seller Management';

    protected static ?string $navigationLabel = 'Verification Fields';

    protected static ?string $pluralModelLabel = 'Verification Fields';

    protected static ?int $navigationSort = 1;

    public static function form(Schema $schema): Schema
    {
        return VerificationFieldForm::configure($schema);
    }

    public static function table(Table $table): Table
    {
        return VerificationFieldsTable::configure($table);
    }

    public static function getPages(): array
    {
        return [
            'index'  => ListVerificationFields::route('/'),
            'create' => CreateVerificationField::route('/create'),
            'edit'   => EditVerificationField::route('/{record}/edit'),
        ];
    }
}

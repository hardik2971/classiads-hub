<?php

namespace App\Filament\Resources\VerificationFields\Pages;

use App\Filament\Resources\VerificationFields\VerificationFieldResource;
use Filament\Resources\Pages\EditRecord;

class EditVerificationField extends EditRecord
{
    protected static string $resource = VerificationFieldResource::class;
}

<?php

namespace App\Filament\Resources\VerificationFields\Pages;

use App\Filament\Resources\VerificationFields\VerificationFieldResource;
use Filament\Actions\CreateAction;
use Filament\Resources\Pages\ListRecords;

class ListVerificationFields extends ListRecords
{
    protected static string $resource = VerificationFieldResource::class;

    protected function getHeaderActions(): array
    {
        return [
            CreateAction::make()->label('Create Verification Field'),
        ];
    }
}

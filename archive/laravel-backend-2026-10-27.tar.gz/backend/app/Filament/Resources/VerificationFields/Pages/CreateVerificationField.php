<?php

namespace App\Filament\Resources\VerificationFields\Pages;

use App\Filament\Resources\VerificationFields\VerificationFieldResource;
use Filament\Resources\Pages\CreateRecord;

class CreateVerificationField extends CreateRecord
{
    protected static string $resource = VerificationFieldResource::class;
}

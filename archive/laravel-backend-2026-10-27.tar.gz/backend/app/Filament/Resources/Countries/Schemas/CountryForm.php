<?php

namespace App\Filament\Resources\Countries\Schemas;

use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Schemas\Schema;

class CountryForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                TextInput::make('name')
                    ->required(),
                TextInput::make('iso2')
                    ->required(),
                TextInput::make('iso3')
                    ->default(null),
                TextInput::make('phone_code')
                    ->tel()
                    ->default(null),
                TextInput::make('currency_code')
                    ->default(null),
                TextInput::make('flag_path')
                    ->default(null),
                Toggle::make('is_active')
                    ->required(),
            ]);
    }
}

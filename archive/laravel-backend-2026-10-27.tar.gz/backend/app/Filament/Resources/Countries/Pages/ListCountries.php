<?php

namespace App\Filament\Resources\Countries\Pages;

use App\Filament\Resources\Countries\CountryResource;
use Filament\Actions\Action;
use Filament\Actions\CreateAction;
use Filament\Forms\Components\FileUpload;
use Filament\Notifications\Notification;
use Filament\Resources\Pages\ListRecords;

class ListCountries extends ListRecords
{
    protected static string $resource = CountryResource::class;

    protected function getHeaderActions(): array
    {
        return [
            CreateAction::make()
                ->label('+ Import Countries')
                ->icon('heroicon-o-arrow-up-tray')
                ->modalHeading('Import Countries from CSV')
                ->schema([
                    FileUpload::make('file')
                        ->label('CSV file (columns: name, iso2, iso3, phone_code)')
                        ->acceptedFileTypes(['text/csv'])
                        ->required(),
                ])
                ->using(function (array $data): void {
                    // TODO: parse the uploaded CSV and bulk-insert Country rows.
                    Notification::make()
                        ->title('Import received — parser not yet wired.')
                        ->warning()
                        ->send();
                }),

            Action::make('translate_countries')
                ->label('Translate Countries')
                ->icon('heroicon-o-language')
                ->color('info')
                ->url(fn () => route('filament.admin.resources.translations.index', [
                    'tableFilters[group][value]' => 'countries',
                ]))
                ->openUrlInNewTab(false),
        ];
    }
}

<?php

namespace App\Filament\Resources\Permissions\Schemas;

use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Schemas\Schema;

class PermissionForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                TextInput::make('name')
                    ->required()
                    ->maxLength(255)
                    ->unique(ignoreRecord: true)
                    ->helperText('Convention: "resource.action" (e.g. ads.approve).'),
                Select::make('guard_name')
                    ->options(['web' => 'web', 'api' => 'api'])
                    ->default('web')
                    ->required(),
            ]);
    }
}

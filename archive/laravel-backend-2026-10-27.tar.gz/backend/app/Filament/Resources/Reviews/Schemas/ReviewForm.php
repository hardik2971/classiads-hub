<?php

namespace App\Filament\Resources\Reviews\Schemas;

use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\Toggle;
use Filament\Schemas\Schema;

class ReviewForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                Select::make('ad_id')
                    ->relationship('ad', 'title')
                    ->default(null),
                Select::make('reviewer_id')
                    ->relationship('reviewer', 'name')
                    ->required(),
                Select::make('reviewee_id')
                    ->relationship('reviewee', 'name')
                    ->required(),
                TextInput::make('rating')
                    ->required()
                    ->numeric(),
                Textarea::make('comment')
                    ->default(null)
                    ->columnSpanFull(),
                Select::make('type')
                    ->options(['seller_review' => 'Seller review', 'buyer_review' => 'Buyer review'])
                    ->default('seller_review')
                    ->required(),
                Toggle::make('is_approved')
                    ->required(),
            ]);
    }
}

<?php

namespace App\Support;

use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Resources\Json\ResourceCollection;

/**
 * Standard API response envelope for ClassiAds_Hub.
 *
 * Shape (Master Plan §2.2):
 *   { "success": bool, "data": mixed, "message": string,
 *     "meta": { "pagination": {...} }|null, "errors": mixed|null }
 */
class ApiResponse
{
    /**
     * Successful response.
     */
    public static function success(
        mixed $data = null,
        string $message = '',
        int $status = 200,
        array $meta = []
    ): JsonResponse {
        // Auto-extract pagination metadata from paginators.
        if ($data instanceof LengthAwarePaginator) {
            $meta['pagination'] = self::paginationMeta($data);
            $data = $data->items();
        } elseif ($data instanceof ResourceCollection
            && $data->resource instanceof LengthAwarePaginator) {
            $meta['pagination'] = self::paginationMeta($data->resource);
        }

        return response()->json([
            'success' => true,
            'data'    => $data,
            'message' => $message,
            'meta'    => $meta ?: null,
            'errors'  => null,
        ], $status);
    }

    /**
     * Error response.
     */
    public static function error(
        string $message = 'Something went wrong.',
        int $status = 400,
        mixed $errors = null,
        mixed $data = null
    ): JsonResponse {
        return response()->json([
            'success' => false,
            'data'    => $data,
            'message' => $message,
            'meta'    => null,
            'errors'  => $errors,
        ], $status);
    }

    /**
     * Build pagination metadata from a paginator.
     */
    public static function paginationMeta(LengthAwarePaginator $p): array
    {
        return [
            'current_page' => $p->currentPage(),
            'per_page'     => $p->perPage(),
            'total'        => $p->total(),
            'last_page'    => $p->lastPage(),
            'from'         => $p->firstItem(),
            'to'           => $p->lastItem(),
        ];
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Defines a field that sellers must fill out during the verification flow.
 * Mobile reads this list to render the dynamic verification form; admin
 * curates it via `VerificationFieldResource` in the Filament panel.
 */
class VerificationField extends Model
{
    protected $fillable = [
        'name', 'field_type', 'min_length', 'max_length',
        'values', 'is_required', 'is_active', 'sort_order',
    ];

    protected function casts(): array
    {
        return [
            'values'      => 'array',
            'is_required' => 'boolean',
            'is_active'   => 'boolean',
            'min_length'  => 'integer',
            'max_length'  => 'integer',
            'sort_order'  => 'integer',
        ];
    }

    public function scopeActive($q)
    {
        return $q->where('is_active', true);
    }
}

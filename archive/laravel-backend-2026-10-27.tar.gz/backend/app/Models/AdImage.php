<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Facades\Storage;

class AdImage extends Model
{
    protected $fillable = ['ad_id', 'path', 'disk', 'is_primary', 'sort_order'];

    protected function casts(): array
    {
        return ['is_primary' => 'boolean', 'sort_order' => 'integer'];
    }

    protected static function booted(): void
    {
        // Remove the underlying file when the row is deleted.
        static::deleting(function (AdImage $image) {
            Storage::disk($image->disk)->delete($image->path);
        });
    }

    public function ad(): BelongsTo
    {
        return $this->belongsTo(Ad::class);
    }

    public function url(): ?string
    {
        return $this->path ? Storage::disk($this->disk)->url($this->path) : null;
    }
}

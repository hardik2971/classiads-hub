<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class Ad extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'user_id', 'category_id', 'title', 'slug', 'description',
        'price', 'currency_code', 'price_type', 'condition',
        'phone', 'video_url',
        'country_id', 'state_id', 'city_id', 'address', 'latitude', 'longitude',
        'status', 'rejection_reason', 'is_featured', 'featured_until',
        'views_count', 'favorites_count',
        'approved_at', 'sold_at', 'published_at', 'expires_at',
    ];

    protected function casts(): array
    {
        return [
            'price'           => 'integer',
            'is_featured'     => 'boolean',
            'latitude'        => 'decimal:7',
            'longitude'       => 'decimal:7',
            'views_count'     => 'integer',
            'favorites_count' => 'integer',
            'featured_until'  => 'datetime',
            'approved_at'     => 'datetime',
            'sold_at'         => 'datetime',
            'published_at'    => 'datetime',
            'expires_at'      => 'datetime',
        ];
    }

    protected static function booted(): void
    {
        static::creating(function (Ad $ad) {
            if (empty($ad->slug)) {
                $ad->slug = static::uniqueSlug($ad->title);
            }
        });
    }

    public static function uniqueSlug(string $title): string
    {
        $base = Str::slug(Str::limit($title, 80, ''));
        $slug = $base.'-'.Str::lower(Str::random(6));
        while (static::withTrashed()->where('slug', $slug)->exists()) {
            $slug = $base.'-'.Str::lower(Str::random(6));
        }

        return $slug;
    }

    // ----- Relations -----

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class);
    }

    public function country(): BelongsTo
    {
        return $this->belongsTo(Country::class);
    }

    public function state(): BelongsTo
    {
        return $this->belongsTo(State::class);
    }

    public function city(): BelongsTo
    {
        return $this->belongsTo(City::class);
    }

    public function images(): HasMany
    {
        return $this->hasMany(AdImage::class)->orderByDesc('is_primary')->orderBy('sort_order');
    }

    public function fieldValues(): HasMany
    {
        return $this->hasMany(AdCustomFieldValue::class);
    }

    public function favorites(): HasMany
    {
        return $this->hasMany(Favorite::class);
    }

    // ----- Scopes -----

    public function scopePublished(Builder $q): Builder
    {
        return $q->where('status', 'approved')
            ->where(fn ($q) => $q->whereNull('expires_at')->orWhere('expires_at', '>', now()));
    }

    public function scopeFilter(Builder $q, array $f): Builder
    {
        return $q
            ->when($f['category_id'] ?? null, fn ($q, $v) => $q->where('category_id', $v))
            ->when($f['category_slug'] ?? null, fn ($q, $v) =>
                $q->whereHas('category', fn ($c) => $c->where('slug', $v)))
            ->when($f['country_id'] ?? null, fn ($q, $v) => $q->where('country_id', $v))
            ->when($f['state_id'] ?? null, fn ($q, $v) => $q->where('state_id', $v))
            ->when($f['city_id'] ?? null, fn ($q, $v) => $q->where('city_id', $v))
            // Filter bounds arrive in major units; stored price is in minor units.
            ->when(isset($f['price_min']) && $f['price_min'] !== '', fn ($q) => $q->where('price', '>=', (int) round((float) $f['price_min'] * 100)))
            ->when(isset($f['price_max']) && $f['price_max'] !== '', fn ($q) => $q->where('price', '<=', (int) round((float) $f['price_max'] * 100)))
            ->when($f['condition'] ?? null, fn ($q, $v) => $q->where('condition', $v))
            ->when($f['featured'] ?? null, fn ($q) => $q->where('is_featured', true))
            ->when($f['user_id'] ?? null, fn ($q, $v) => $q->where('user_id', $v))
            ->when($f['q'] ?? null, function ($q, $term) {
                $q->where(function ($q) use ($term) {
                    $q->whereFullText(['title', 'description'], $term)
                        ->orWhere('title', 'like', "%{$term}%");
                });
            });
    }

    public function scopeSort(Builder $q, ?string $sort): Builder
    {
        return match ($sort) {
            'price_asc'   => $q->orderBy('price'),
            'price_desc'  => $q->orderByDesc('price'),
            'oldest'      => $q->orderBy('published_at'),
            'most_viewed' => $q->orderByDesc('views_count'),
            'most_liked'  => $q->orderByDesc('favorites_count'),
            default       => $q->orderByDesc('is_featured')->orderByDesc('published_at'),
        };
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Subscription extends Model
{
    protected $fillable = [
        'user_id', 'package_id', 'transaction_id', 'status',
        'starts_at', 'ends_at', 'ad_limit', 'is_unlimited', 'ads_used',
    ];

    protected function casts(): array
    {
        return [
            'starts_at'    => 'datetime',
            'ends_at'      => 'datetime',
            'ad_limit'     => 'integer',
            'is_unlimited' => 'boolean',
            'ads_used'     => 'integer',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function package(): BelongsTo
    {
        return $this->belongsTo(Package::class);
    }

    public function transaction(): BelongsTo
    {
        return $this->belongsTo(Transaction::class);
    }

    public function scopeActive($q)
    {
        return $q->where('status', 'active')
            ->where(fn ($q) => $q->whereNull('ends_at')->orWhere('ends_at', '>', now()));
    }

    public function isLive(): bool
    {
        return $this->status === 'active' && (! $this->ends_at || $this->ends_at->isFuture());
    }

    public function hasQuota(): bool
    {
        return $this->is_unlimited || $this->ads_used < ($this->ad_limit ?? 0);
    }

    public function remaining(): ?int
    {
        return $this->is_unlimited ? null : max(0, ($this->ad_limit ?? 0) - $this->ads_used);
    }
}

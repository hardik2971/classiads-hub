<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\MorphTo;

class SeoMeta extends Model
{
    protected $table = 'seo_meta';

    protected $fillable = [
        'seoable_type', 'seoable_id', 'route_key',
        'title', 'description', 'keywords', 'og_image', 'json_ld',
    ];

    protected function casts(): array
    {
        return ['json_ld' => 'array'];
    }

    public function seoable(): MorphTo
    {
        return $this->morphTo();
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Str;

class JobListing extends Model
{
    protected $fillable = [
        'user_id', 'category_id', 'city_id', 'title', 'slug', 'company_name',
        'description', 'employment_type', 'salary_min', 'salary_max',
        'currency_code', 'status', 'expires_at', 'applications_count',
    ];

    protected $attributes = ['currency_code' => 'USD', 'status' => 'open'];

    protected function casts(): array
    {
        return [
            'salary_min'         => 'integer',
            'salary_max'         => 'integer',
            'expires_at'         => 'datetime',
            'applications_count' => 'integer',
        ];
    }

    protected static function booted(): void
    {
        static::creating(function (JobListing $j) {
            if (empty($j->slug)) {
                $base = Str::slug(Str::limit($j->title, 80, ''));
                $j->slug = $base.'-'.Str::lower(Str::random(5));
            }
        });
    }

    public function employer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class);
    }

    public function city(): BelongsTo
    {
        return $this->belongsTo(City::class);
    }

    public function applications(): HasMany
    {
        return $this->hasMany(JobApplication::class);
    }

    public function scopeOpen($q)
    {
        return $q->where('status', 'open')
            ->where(fn ($q) => $q->whereNull('expires_at')->orWhere('expires_at', '>', now()));
    }
}

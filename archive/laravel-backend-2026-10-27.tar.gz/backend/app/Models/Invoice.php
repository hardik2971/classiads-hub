<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Invoice extends Model
{
    protected $fillable = [
        'transaction_id', 'user_id', 'number',
        'subtotal', 'tax_amount', 'total', 'currency_code', 'status', 'issued_at',
    ];

    protected function casts(): array
    {
        return [
            'subtotal'   => 'integer',
            'tax_amount' => 'integer',
            'total'      => 'integer',
            'issued_at'  => 'datetime',
        ];
    }

    public function transaction(): BelongsTo
    {
        return $this->belongsTo(Transaction::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}

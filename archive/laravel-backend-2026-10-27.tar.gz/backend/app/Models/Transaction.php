<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Transaction extends Model
{
    protected $fillable = [
        'user_id', 'type', 'package_id', 'featured_ad_plan_id', 'ad_id',
        'gateway', 'gateway_reference', 'amount', 'tax_amount', 'total',
        'currency_code', 'status', 'meta', 'paid_at',
    ];

    protected function casts(): array
    {
        return [
            'amount'     => 'integer',
            'tax_amount' => 'integer',
            'total'      => 'integer',
            'meta'       => 'array',
            'paid_at'    => 'datetime',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function package(): BelongsTo
    {
        return $this->belongsTo(Package::class);
    }

    public function featuredPlan(): BelongsTo
    {
        return $this->belongsTo(FeaturedAdPlan::class, 'featured_ad_plan_id');
    }

    public function ad(): BelongsTo
    {
        return $this->belongsTo(Ad::class);
    }

    public function subscription(): HasOne
    {
        return $this->hasOne(Subscription::class);
    }

    public function invoice(): HasOne
    {
        return $this->hasOne(Invoice::class);
    }

    public function isCompleted(): bool
    {
        return $this->status === 'completed';
    }

    public function totalDisplay(): string
    {
        return $this->currency_code.' '.number_format($this->total / 100, 2);
    }
}

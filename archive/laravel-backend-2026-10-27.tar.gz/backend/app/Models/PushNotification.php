<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class PushNotification extends Model
{
    protected $fillable = [
        'title', 'body', 'image_path', 'target',
        'target_role', 'target_user_id', 'target_user_ids',
        'item_type', 'item_id', 'sent_by', 'recipients_count',
    ];

    protected function casts(): array
    {
        return [
            'target_user_ids'   => 'array',
            'recipients_count'  => 'integer',
        ];
    }

    public function sender(): BelongsTo
    {
        return $this->belongsTo(User::class, 'sent_by');
    }

    public function targetUser(): BelongsTo
    {
        return $this->belongsTo(User::class, 'target_user_id');
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EmailTemplate extends Model
{
    protected $fillable = ['code', 'subject', 'body_html', 'variables', 'is_active'];

    protected function casts(): array
    {
        return ['variables' => 'array', 'is_active' => 'boolean'];
    }

    /**
     * Render the template by substituting {{ var }} placeholders.
     *
     * @param  array<string,mixed>  $data
     * @return array{subject:string, body:string}
     */
    public function render(array $data = []): array
    {
        $replace = function (string $text) use ($data) {
            return preg_replace_callback('/\{\{\s*(\w+)\s*\}\}/', function ($m) use ($data) {
                return (string) ($data[$m[1]] ?? '');
            }, $text);
        };

        return [
            'subject' => $replace($this->subject),
            'body'    => $replace($this->body_html),
        ];
    }
}

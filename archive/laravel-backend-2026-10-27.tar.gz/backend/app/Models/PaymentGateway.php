<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PaymentGateway extends Model
{
    protected $fillable = [
        'code', 'name', 'is_active', 'mode', 'config', 'supported_currencies', 'is_manual', 'sort_order',
    ];

    protected $hidden = ['config']; // secret credentials never exposed to clients

    protected function casts(): array
    {
        return [
            'is_active'            => 'boolean',
            'is_manual'           => 'boolean',
            'config'              => 'array',
            'supported_currencies' => 'array',
        ];
    }

    public function scopeActive($q)
    {
        return $q->where('is_active', true);
    }
}

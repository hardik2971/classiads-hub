<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class FeaturedSection extends Model
{
    protected $fillable = [
        'title', 'filter_type', 'category_id', 'style', 'item_limit', 'sort_order', 'is_active',
    ];

    protected function casts(): array
    {
        return [
            'is_active'  => 'boolean',
            'item_limit' => 'integer',
            'sort_order' => 'integer',
        ];
    }

    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class);
    }

    public function scopeActive($q)
    {
        return $q->where('is_active', true);
    }

    /**
     * Resolve the ads for this section based on its filter.
     */
    public function resolveAds()
    {
        $query = Ad::query()->published()->with(['images', 'city', 'category']);

        $query = match ($this->filter_type) {
            'most_viewed' => $query->orderByDesc('views_count'),
            'most_liked'  => $query->orderByDesc('favorites_count'),
            'featured'    => $query->where('is_featured', true)->orderByDesc('published_at'),
            'category'    => $query->where('category_id', $this->category_id)->orderByDesc('published_at'),
            default       => $query->orderByDesc('published_at'),
        };

        return $query->limit($this->item_limit)->get();
    }
}

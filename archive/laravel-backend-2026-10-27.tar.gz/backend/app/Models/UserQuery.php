<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Inbound contact-form submissions from the public website. Admin reviews
 * them via the Filament UserQueryResource.
 */
class UserQuery extends Model
{
    protected $fillable = ['name', 'email', 'subject', 'message', 'status'];

    public function scopeOpen($q)
    {
        return $q->where('status', 'open');
    }
}

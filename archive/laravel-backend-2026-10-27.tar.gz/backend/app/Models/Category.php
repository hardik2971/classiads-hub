<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Str;

class Category extends Model
{
    protected $fillable = [
        'parent_id',
        'name',
        'slug',
        'icon_path',
        'image_path',
        'type',
        'sort_order',
        'is_active',
        'ads_count',
    ];

    protected function casts(): array
    {
        return [
            'is_active'  => 'boolean',
            'sort_order' => 'integer',
            'ads_count'  => 'integer',
        ];
    }

    protected static function booted(): void
    {
        static::saving(function (Category $category) {
            if (empty($category->slug) && ! empty($category->name)) {
                $category->slug = static::uniqueSlug($category->name, $category->id);
            }
        });

        // Bust the cached public category tree on any change.
        static::saved(fn () => Cache::forget('categories.tree'));
        static::deleted(fn () => Cache::forget('categories.tree'));
    }

    public static function uniqueSlug(string $name, ?int $ignoreId = null): string
    {
        $base = Str::slug($name);
        $slug = $base;
        $i = 1;
        while (static::where('slug', $slug)
            ->when($ignoreId, fn ($q) => $q->where('id', '!=', $ignoreId))
            ->exists()) {
            $slug = $base.'-'.$i++;
        }

        return $slug;
    }

    // ----- Relations -----

    public function parent(): BelongsTo
    {
        return $this->belongsTo(self::class, 'parent_id');
    }

    public function children(): HasMany
    {
        return $this->hasMany(self::class, 'parent_id')->orderBy('sort_order');
    }

    public function customFields(): BelongsToMany
    {
        return $this->belongsToMany(CustomField::class, 'category_custom_field')
            ->withPivot(['is_required', 'sort_order'])
            ->withTimestamps()
            ->orderBy('sort_order');
    }

    public function ads(): HasMany
    {
        return $this->hasMany(Ad::class);
    }

    // ----- Scopes -----

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeRoots($query)
    {
        return $query->whereNull('parent_id');
    }
}

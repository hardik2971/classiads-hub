<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;

class CustomField extends Model
{
    protected $fillable = [
        'name',
        'code',
        'type',
        'icon_path',
        'is_required',
        'is_filterable',
        'sort_order',
    ];

    protected function casts(): array
    {
        return [
            'is_required'   => 'boolean',
            'is_filterable' => 'boolean',
            'sort_order'    => 'integer',
        ];
    }

    public function options(): HasMany
    {
        return $this->hasMany(CustomFieldOption::class)->orderBy('sort_order');
    }

    public function categories(): BelongsToMany
    {
        return $this->belongsToMany(Category::class, 'category_custom_field')
            ->withPivot(['is_required', 'sort_order'])
            ->withTimestamps();
    }

    public function hasOptions(): bool
    {
        return in_array($this->type, ['dropdown', 'radio', 'checkbox'], true);
    }
}

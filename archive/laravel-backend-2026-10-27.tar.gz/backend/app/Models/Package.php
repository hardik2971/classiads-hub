<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Package extends Model
{
    protected $fillable = [
        'name', 'ios_product_id', 'android_product_id', 'description',
        'price', 'discount_percent', 'final_price', 'currency_code',
        'duration_days', 'ad_limit', 'is_unlimited', 'icon_path', 'is_active', 'sort_order',
    ];

    protected $attributes = [
        'currency_code'    => 'USD',
        'discount_percent' => 0,
    ];

    protected function casts(): array
    {
        return [
            'price'            => 'integer',
            'final_price'      => 'integer',
            'discount_percent' => 'integer',
            'duration_days'    => 'integer',
            'ad_limit'         => 'integer',
            'is_unlimited'     => 'boolean',
            'is_active'        => 'boolean',
        ];
    }

    public function categories(): BelongsToMany
    {
        return $this->belongsToMany(Category::class, 'package_category')->withTimestamps();
    }

    public function scopeActive($q)
    {
        return $q->where('is_active', true);
    }

    /** Recompute final price from price + discount (minor units). */
    public static function computeFinal(int $price, int $discountPercent): int
    {
        return (int) round($price * (100 - $discountPercent) / 100);
    }
}

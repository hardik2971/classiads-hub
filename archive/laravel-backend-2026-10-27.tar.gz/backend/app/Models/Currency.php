<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Facades\Cache;

class Currency extends Model
{
    protected $fillable = [
        'code', 'symbol', 'name', 'is_default', 'decimal_digits', 'is_active',
        'country_id', 'symbol_position',
    ];

    public function country(): BelongsTo
    {
        return $this->belongsTo(Country::class);
    }

    protected static function booted(): void
    {
        $bust = fn () => Cache::forget('config.currencies');
        static::saved($bust);
        static::deleted($bust);
    }

    protected function casts(): array
    {
        return [
            'is_default'     => 'boolean',
            'is_active'      => 'boolean',
            'decimal_digits' => 'integer',
        ];
    }

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }
}

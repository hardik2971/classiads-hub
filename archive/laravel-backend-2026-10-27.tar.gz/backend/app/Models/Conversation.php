<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Conversation extends Model
{
    protected $fillable = [
        'ad_id', 'buyer_id', 'seller_id',
        'last_message', 'last_message_at', 'buyer_unread', 'seller_unread',
    ];

    // Ensure unread counters are 0 (not null) on freshly created instances.
    protected $attributes = [
        'buyer_unread'  => 0,
        'seller_unread' => 0,
    ];

    protected function casts(): array
    {
        return [
            'last_message_at' => 'datetime',
            'buyer_unread'    => 'integer',
            'seller_unread'   => 'integer',
        ];
    }

    public function ad(): BelongsTo
    {
        return $this->belongsTo(Ad::class);
    }

    public function buyer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'buyer_id');
    }

    public function seller(): BelongsTo
    {
        return $this->belongsTo(User::class, 'seller_id');
    }

    public function messages(): HasMany
    {
        return $this->hasMany(Message::class);
    }

    /** Is the given user a participant? */
    public function hasParticipant(int $userId): bool
    {
        return $this->buyer_id === $userId || $this->seller_id === $userId;
    }

    /** The other participant's id relative to $userId. */
    public function counterpartId(int $userId): int
    {
        return $this->buyer_id === $userId ? $this->seller_id : $this->buyer_id;
    }

    public function roleOf(int $userId): string
    {
        return $this->buyer_id === $userId ? 'buyer' : 'seller';
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Cache;

class Language extends Model
{
    protected $fillable = [
        'name', 'code', 'flag_path', 'is_rtl', 'is_default', 'is_active',
    ];

    protected static function booted(): void
    {
        $bust = fn () => Cache::forget('config.languages');
        static::saved($bust);
        static::deleted($bust);
    }

    protected function casts(): array
    {
        return [
            'is_rtl'     => 'boolean',
            'is_default' => 'boolean',
            'is_active'  => 'boolean',
        ];
    }

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }
}

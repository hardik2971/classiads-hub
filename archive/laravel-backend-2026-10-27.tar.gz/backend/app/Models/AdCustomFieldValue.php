<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class AdCustomFieldValue extends Model
{
    protected $fillable = ['ad_id', 'custom_field_id', 'value'];

    public function ad(): BelongsTo
    {
        return $this->belongsTo(Ad::class);
    }

    public function customField(): BelongsTo
    {
        return $this->belongsTo(CustomField::class);
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Offer extends Model
{
    protected $fillable = [
        'ad_id', 'conversation_id', 'buyer_id', 'seller_id', 'parent_offer_id',
        'amount', 'currency_code', 'status', 'message',
    ];

    protected function casts(): array
    {
        return ['amount' => 'integer'];
    }

    public function ad(): BelongsTo
    {
        return $this->belongsTo(Ad::class);
    }

    public function conversation(): BelongsTo
    {
        return $this->belongsTo(Conversation::class);
    }

    public function buyer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'buyer_id');
    }

    public function seller(): BelongsTo
    {
        return $this->belongsTo(User::class, 'seller_id');
    }

    public function amountDisplay(): string
    {
        return $this->currency_code.' '.number_format($this->amount / 100, 2);
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FeaturedAdPlan extends Model
{
    protected $fillable = [
        'name', 'description', 'price', 'currency_code', 'duration_days', 'is_active', 'sort_order',
    ];

    protected $attributes = ['currency_code' => 'USD'];

    protected function casts(): array
    {
        return [
            'price'         => 'integer',
            'duration_days' => 'integer',
            'is_active'     => 'boolean',
        ];
    }

    public function scopeActive($q)
    {
        return $q->where('is_active', true);
    }
}

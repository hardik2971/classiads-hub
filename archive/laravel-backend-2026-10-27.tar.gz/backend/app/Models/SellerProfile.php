<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class SellerProfile extends Model
{
    protected $fillable = [
        'user_id',
        'display_name',
        'bio',
        'business_name',
        'website',
        'rating_avg',
        'rating_count',
        'member_since',
    ];

    protected function casts(): array
    {
        return [
            'rating_avg'   => 'decimal:2',
            'rating_count' => 'integer',
            'member_since' => 'date',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}

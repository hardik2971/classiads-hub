<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Cache;

class Translation extends Model
{
    protected $fillable = ['locale', 'group', 'key', 'value'];

    protected static function booted(): void
    {
        // Keep the per-locale cache fresh whenever strings change.
        static::saved(fn (Translation $t) => Cache::forget("translations.{$t->locale}"));
        static::deleted(fn (Translation $t) => Cache::forget("translations.{$t->locale}"));
    }

    /**
     * Flat key→value map for a locale (cached).
     *
     * @return array<string, string>
     */
    public static function mapFor(string $locale): array
    {
        return Cache::remember("translations.{$locale}", now()->addHour(),
            fn () => static::where('locale', $locale)->pluck('value', 'key')->all());
    }
}

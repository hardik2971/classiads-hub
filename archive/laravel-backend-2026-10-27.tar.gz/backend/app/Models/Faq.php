<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Frequently-asked questions shown on the public web + mobile FAQ screen.
 * Admin curates these via the Filament FaqResource. English is the primary
 * record; other locales live in the `translations` JSON column.
 */
class Faq extends Model
{
    protected $fillable = [
        'question', 'answer', 'translations', 'sort_order', 'is_active',
    ];

    protected function casts(): array
    {
        return [
            'translations' => 'array',
            'is_active'    => 'boolean',
            'sort_order'   => 'integer',
        ];
    }

    public function scopeActive($q)
    {
        return $q->where('is_active', true);
    }

    /**
     * Pick the Q/A for a given locale, falling back to the canonical English
     * columns when the translation is missing.
     */
    public function translate(string $locale): array
    {
        $t = $this->translations[$locale] ?? null;
        return [
            'question' => $t['question'] ?? $this->question,
            'answer'   => $t['answer']   ?? $this->answer,
        ];
    }
}

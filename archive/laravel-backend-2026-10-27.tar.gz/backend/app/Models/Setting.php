<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Cache;

class Setting extends Model
{
    protected $fillable = ['group', 'key', 'value', 'type'];

    public $timestamps = true;

    protected static function booted(): void
    {
        static::saved(fn () => Cache::forget('settings.all'));
        static::deleted(fn () => Cache::forget('settings.all'));
    }

    /**
     * Cast the stored string value to its declared type.
     */
    public function typedValue(): mixed
    {
        return match ($this->type) {
            'int'    => (int) $this->value,
            'bool'   => filter_var($this->value, FILTER_VALIDATE_BOOLEAN),
            'json'   => json_decode((string) $this->value, true),
            default  => $this->value,
        };
    }

    /**
     * Get a setting value by "group.key" with optional default.
     */
    public static function get(string $group, string $key, mixed $default = null): mixed
    {
        $all = Cache::rememberForever('settings.all', fn () => static::all());
        $row = $all->firstWhere(fn ($s) => $s->group === $group && $s->key === $key);

        return $row ? $row->typedValue() : $default;
    }
}

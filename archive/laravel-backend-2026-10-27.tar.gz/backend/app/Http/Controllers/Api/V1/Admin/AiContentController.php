<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Services\Ai\AiContentService;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class AiContentController extends Controller
{
    public function __construct(private readonly AiContentService $ai) {}

    public function generate(Request $request): JsonResponse
    {
        if (! $this->ai->isEnabled()) {
            return ApiResponse::error('AI content generation is disabled.', 422);
        }

        $data = $request->validate([
            'prompt' => ['required', 'string', 'max:2000'],
            'type'   => ['nullable', Rule::in(['title', 'description', 'blog'])],
        ]);

        $result = $this->ai->generate($data['prompt'], $data['type'] ?? 'description');

        return ApiResponse::success($result, 'Content generated.');
    }
}

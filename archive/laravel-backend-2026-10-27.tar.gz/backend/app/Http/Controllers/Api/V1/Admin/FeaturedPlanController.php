<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Resources\FeaturedAdPlanResource;
use App\Models\FeaturedAdPlan;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class FeaturedPlanController extends Controller
{
    public function index(): JsonResponse
    {
        return ApiResponse::success(
            FeaturedAdPlanResource::collection(FeaturedAdPlan::orderBy('sort_order')->get()),
            'Featured ad plans.'
        );
    }

    public function store(Request $request): JsonResponse
    {
        $plan = FeaturedAdPlan::create($this->prepare($this->validateData($request)));

        return ApiResponse::success(new FeaturedAdPlanResource($plan), 'Plan created.', 201);
    }

    public function update(Request $request, int $id): JsonResponse
    {
        $plan = FeaturedAdPlan::findOrFail($id);
        $plan->update($this->prepare($this->validateData($request, partial: true)));

        return ApiResponse::success(new FeaturedAdPlanResource($plan), 'Plan updated.');
    }

    public function destroy(int $id): JsonResponse
    {
        FeaturedAdPlan::findOrFail($id)->delete();

        return ApiResponse::success(null, 'Plan deleted.');
    }

    private function validateData(Request $request, bool $partial = false): array
    {
        $req = $partial ? 'sometimes' : 'required';

        return $request->validate([
            'name'          => [$req, 'string', 'max:150'],
            'description'   => ['nullable', 'string'],
            'price'         => [$req, 'numeric', 'min:0'],
            'currency_code' => ['nullable', 'string', 'size:3'],
            'duration_days' => [$req, 'integer', 'min:1'],
            'is_active'     => ['nullable', 'boolean'],
            'sort_order'    => ['nullable', 'integer'],
        ]);
    }

    private function prepare(array $data): array
    {
        if (array_key_exists('price', $data)) {
            $data['price'] = (int) round((float) $data['price'] * 100);
        }

        return $data;
    }
}

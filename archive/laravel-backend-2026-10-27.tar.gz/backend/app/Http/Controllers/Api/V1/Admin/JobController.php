<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Resources\JobListingResource;
use App\Models\JobListing;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class JobController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $jobs = JobListing::with(['employer', 'category', 'city'])->withCount('applications')
            ->when($request->filled('status'), fn ($q) => $q->where('status', $request->string('status')))
            ->latest()
            ->paginate(min($request->integer('per_page', 20), 50));

        return ApiResponse::success(JobListingResource::collection($jobs), 'Jobs.');
    }

    public function setStatus(Request $request, int $id): JsonResponse
    {
        $data = $request->validate(['status' => ['required', Rule::in(['draft', 'open', 'closed'])]]);
        $job = JobListing::findOrFail($id);
        $job->update(['status' => $data['status']]);

        return ApiResponse::success(new JobListingResource($job), 'Job updated.');
    }

    public function destroy(int $id): JsonResponse
    {
        JobListing::findOrFail($id)->delete();

        return ApiResponse::success(null, 'Job deleted.');
    }
}

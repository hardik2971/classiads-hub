<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\TransactionResource;
use App\Models\Ad;
use App\Models\FeaturedAdPlan;
use App\Services\Billing\CheckoutService;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use RuntimeException;

class FeaturedController extends Controller
{
    public function __construct(private readonly CheckoutService $checkout) {}

    /**
     * Start a featured-ad purchase for one of the seller's own ads.
     */
    public function checkout(Request $request, int $adId): JsonResponse
    {
        $data = $request->validate([
            'plan_id' => ['required', 'integer', 'exists:featured_ad_plans,id'],
            'gateway' => ['required', 'string', 'max:50'],
        ]);

        $ad = Ad::findOrFail($adId);
        abort_unless($ad->user_id === $request->user()->id, 403, 'You can only feature your own ads.');

        $plan = FeaturedAdPlan::active()->findOrFail($data['plan_id']);

        try {
            $result = $this->checkout->featured($request->user(), $ad, $plan, $data['gateway']);
        } catch (RuntimeException $e) {
            return ApiResponse::error($e->getMessage(), 422);
        }

        return ApiResponse::success([
            'transaction' => new TransactionResource($result['transaction']),
            'payment'     => $result['payment'],
        ], 'Checkout started.', 201);
    }
}

<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Resources\BlogCategoryResource;
use App\Http\Resources\BlogPostResource;
use App\Models\BlogCategory;
use App\Models\BlogPost;
use App\Services\Media\MediaService;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class BlogController extends Controller
{
    public function __construct(private readonly MediaService $media) {}

    public function index(Request $request): JsonResponse
    {
        $posts = BlogPost::with(['category', 'author'])
            ->when($request->filled('status'), fn ($q) => $q->where('status', $request->string('status')))
            ->latest()
            ->paginate(min($request->integer('per_page', 20), 50));

        return ApiResponse::success(BlogPostResource::collection($posts), 'Blog posts.');
    }

    public function store(Request $request): JsonResponse
    {
        $data = $this->validatePost($request);
        $data['author_id'] = $request->user()->id;
        $data = $this->handleCover($request, $data);
        if (($data['status'] ?? 'draft') === 'published' && empty($data['published_at'])) {
            $data['published_at'] = now();
        }

        $post = BlogPost::create($data);

        return ApiResponse::success(new BlogPostResource($post->load('category')), 'Post created.', 201);
    }

    public function update(Request $request, int $id): JsonResponse
    {
        $post = BlogPost::findOrFail($id);
        $data = $this->handleCover($request, $this->validatePost($request, partial: true));

        if (($data['status'] ?? null) === 'published' && ! $post->published_at) {
            $data['published_at'] = now();
        }
        $post->update($data);

        return ApiResponse::success(new BlogPostResource($post->load('category')), 'Post updated.');
    }

    public function destroy(int $id): JsonResponse
    {
        BlogPost::findOrFail($id)->delete();

        return ApiResponse::success(null, 'Post deleted.');
    }

    // ----- categories -----

    public function categories(): JsonResponse
    {
        return ApiResponse::success(
            BlogCategoryResource::collection(BlogCategory::withCount('posts')->orderBy('sort_order')->get()),
            'Blog categories.'
        );
    }

    public function storeCategory(Request $request): JsonResponse
    {
        $data = $request->validate([
            'name'       => ['required', 'string', 'max:150'],
            'is_active'  => ['nullable', 'boolean'],
            'sort_order' => ['nullable', 'integer'],
        ]);
        $cat = BlogCategory::create($data);

        return ApiResponse::success(new BlogCategoryResource($cat), 'Category created.', 201);
    }

    public function destroyCategory(int $id): JsonResponse
    {
        BlogCategory::findOrFail($id)->delete();

        return ApiResponse::success(null, 'Category deleted.');
    }

    private function validatePost(Request $request, bool $partial = false): array
    {
        $req = $partial ? 'sometimes' : 'required';

        return $request->validate([
            'title'            => [$req, 'string', 'max:191'],
            'body'             => [$req, 'string'],
            'excerpt'          => ['nullable', 'string', 'max:500'],
            'blog_category_id' => ['nullable', 'integer', 'exists:blog_categories,id'],
            'status'           => ['nullable', Rule::in(['draft', 'published'])],
            'cover_image'      => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:5120'],
        ]);
    }

    private function handleCover(Request $request, array $data): array
    {
        if ($request->hasFile('cover_image')) {
            $data['cover_image_path'] = $this->media->storeImage($request->file('cover_image'), 'blog');
        }
        unset($data['cover_image']);

        return $data;
    }
}

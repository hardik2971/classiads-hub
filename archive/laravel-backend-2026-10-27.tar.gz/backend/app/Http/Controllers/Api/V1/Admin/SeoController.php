<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Models\Ad;
use App\Models\BlogPost;
use App\Models\Category;
use App\Models\Page;
use App\Models\SeoMeta;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class SeoController extends Controller
{
    public function index(): JsonResponse
    {
        return ApiResponse::success(SeoMeta::latest()->paginate(50), 'SEO meta.');
    }

    /**
     * Upsert SEO meta for a static route_key or an entity (type+id).
     */
    public function upsert(Request $request): JsonResponse
    {
        $data = $request->validate([
            'route_key'   => ['nullable', 'string', 'max:100', 'required_without:type'],
            'type'        => ['nullable', Rule::in(['ad', 'category', 'blog', 'page']), 'required_without:route_key'],
            'id'          => ['nullable', 'integer', 'required_with:type'],
            'title'       => ['nullable', 'string', 'max:191'],
            'description' => ['nullable', 'string', 'max:500'],
            'keywords'    => ['nullable', 'string', 'max:500'],
            'og_image'    => ['nullable', 'string', 'max:255'],
            'json_ld'     => ['nullable', 'array'],
        ]);

        $attrs = collect($data)->only(['title', 'description', 'keywords', 'og_image', 'json_ld'])->toArray();

        if (! empty($data['route_key'])) {
            $meta = SeoMeta::updateOrCreate(['route_key' => $data['route_key']], $attrs);
        } else {
            $class = [
                'ad' => Ad::class, 'category' => Category::class,
                'blog' => BlogPost::class, 'page' => Page::class,
            ][$data['type']];
            $meta = SeoMeta::updateOrCreate(
                ['seoable_type' => $class, 'seoable_id' => $data['id']],
                $attrs
            );
        }

        return ApiResponse::success($meta, 'SEO meta saved.');
    }

    public function destroy(int $id): JsonResponse
    {
        SeoMeta::findOrFail($id)->delete();

        return ApiResponse::success(null, 'SEO meta deleted.');
    }
}

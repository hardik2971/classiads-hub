<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\InvoiceResource;
use App\Http\Resources\TransactionResource;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class TransactionController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $txns = $request->user()->transactions()
            ->with(['invoice', 'package', 'ad'])
            ->when($request->filled('status'), fn ($q) => $q->where('status', $request->string('status')))
            ->latest()
            ->paginate(min($request->integer('per_page', 20), 50));

        return ApiResponse::success(TransactionResource::collection($txns), 'Transactions.');
    }

    public function invoices(Request $request): JsonResponse
    {
        $invoices = \App\Models\Invoice::where('user_id', $request->user()->id)
            ->latest()
            ->paginate(min($request->integer('per_page', 20), 50));

        return ApiResponse::success(InvoiceResource::collection($invoices), 'Invoices.');
    }

    public function showInvoice(Request $request, int $id): JsonResponse
    {
        $invoice = \App\Models\Invoice::where('user_id', $request->user()->id)->findOrFail($id);

        return ApiResponse::success(new InvoiceResource($invoice), 'Invoice.');
    }
}

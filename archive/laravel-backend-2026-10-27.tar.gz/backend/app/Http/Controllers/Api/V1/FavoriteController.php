<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\AdResource;
use App\Models\Ad;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class FavoriteController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $ads = Ad::query()
            ->whereIn('id', $request->user()->favorites()->select('ad_id'))
            ->with(['images', 'category', 'city'])
            ->latest()
            ->paginate(min($request->integer('per_page', 20), 50));

        $ads->getCollection()->each(fn ($ad) => $ad->is_favorited = true);

        return ApiResponse::success(AdResource::collection($ads), 'Favorites.');
    }

    /**
     * Toggle a favorite. Returns the new state.
     */
    public function toggle(Request $request, int $adId): JsonResponse
    {
        $ad = Ad::findOrFail($adId);
        $user = $request->user();

        $favorited = DB::transaction(function () use ($user, $ad) {
            $existing = $user->favorites()->where('ad_id', $ad->id)->first();

            if ($existing) {
                $existing->delete();
                Ad::whereKey($ad->id)->where('favorites_count', '>', 0)->decrement('favorites_count');

                return false;
            }

            $user->favorites()->create(['ad_id' => $ad->id]);
            Ad::whereKey($ad->id)->increment('favorites_count');

            return true;
        });

        return ApiResponse::success(
            ['ad_id' => $ad->id, 'favorited' => $favorited],
            $favorited ? 'Added to favorites.' : 'Removed from favorites.'
        );
    }
}

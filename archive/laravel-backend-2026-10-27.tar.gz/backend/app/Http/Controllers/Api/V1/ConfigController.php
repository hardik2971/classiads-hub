<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\CurrencyResource;
use App\Http\Resources\LanguageResource;
use App\Models\Currency;
use App\Models\Language;
use App\Models\Setting;
use App\Models\Translation;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Cache;

class ConfigController extends Controller
{
    /** Active languages (cached; busted by the Language model). */
    private function activeLanguages()
    {
        return Cache::remember('config.languages', now()->addHours(6), fn () => Language::active()->get());
    }

    /** Active currencies (cached; busted by the Currency model). */
    private function activeCurrencies()
    {
        return Cache::remember('config.currencies', now()->addHours(6), fn () => Currency::active()->get());
    }

    public function languages(): JsonResponse
    {
        return ApiResponse::success(
            LanguageResource::collection($this->activeLanguages()),
            'Languages.'
        );
    }

    public function currencies(): JsonResponse
    {
        return ApiResponse::success(
            CurrencyResource::collection($this->activeCurrencies()),
            'Currencies.'
        );
    }

    /**
     * UI translation strings for a locale (falls back to the default language
     * for any missing keys), consumed by mobile/web to localize the interface.
     */
    public function translations(string $locale): JsonResponse
    {
        $default = Language::where('is_default', true)->value('code') ?? 'en';

        $strings = Translation::mapFor($default);                 // base layer
        if ($locale !== $default) {
            $strings = array_merge($strings, Translation::mapFor($locale)); // locale overrides
        }

        return ApiResponse::success([
            'locale'       => $locale,
            'fallback'     => $default,
            'translations' => (object) $strings,
        ], 'Translations.');
    }

    /**
     * Public bootstrap config consumed by mobile/web on launch.
     * Only non-secret, client-safe settings are exposed.
     */
    public function appConfig(): JsonResponse
    {
        // Setting::all() is itself cached + busted inside the Setting model.
        $public = Cache::rememberForever('settings.all', fn () => Setting::all())
            ->where('type', '!=', 'secret')
            ->groupBy('group')
            ->map(fn ($rows) => $rows->mapWithKeys(fn ($s) => [$s->key => $s->typedValue()]));

        return ApiResponse::success([
            'settings'   => $public,
            'languages'  => LanguageResource::collection($this->activeLanguages()),
            'currencies' => CurrencyResource::collection($this->activeCurrencies()),
        ], 'App config.');
    }
}

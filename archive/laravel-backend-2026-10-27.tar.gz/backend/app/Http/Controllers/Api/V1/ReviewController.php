<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\ReviewResource;
use App\Http\Resources\UserResource;
use App\Models\Ad;
use App\Models\AdSale;
use App\Models\Conversation;
use App\Models\Review;
use App\Models\User;
use App\Services\Notifications\NotificationService;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

class ReviewController extends Controller
{
    public function __construct(private readonly NotificationService $notifications) {}

    /**
     * Create a review. type=seller_review (buyer→seller) or buyer_review (seller→buyer).
     */
    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'reviewee_id' => ['required', 'integer', 'exists:users,id', 'different:reviewer'],
            'ad_id'       => ['nullable', 'integer', 'exists:ads,id'],
            'rating'      => ['required', 'integer', 'min:1', 'max:5'],
            'comment'     => ['nullable', 'string', 'max:2000'],
            'type'        => ['required', Rule::in(['seller_review', 'buyer_review'])],
        ]);

        $reviewer = $request->user();
        if ($reviewer->id === (int) $data['reviewee_id']) {
            throw ValidationException::withMessages(['reviewee_id' => ['You cannot review yourself.']]);
        }

        $this->assertEligible($reviewer->id, (int) $data['reviewee_id'], $data['ad_id'] ?? null, $data['type']);

        $review = DB::transaction(function () use ($data, $reviewer) {
            $review = Review::updateOrCreate(
                [
                    'reviewer_id' => $reviewer->id,
                    'reviewee_id' => $data['reviewee_id'],
                    'ad_id'       => $data['ad_id'] ?? null,
                ],
                [
                    'rating'      => $data['rating'],
                    'comment'     => $data['comment'] ?? null,
                    'type'        => $data['type'],
                    'is_approved' => true,
                ]
            );

            if ($data['type'] === 'seller_review') {
                $this->recomputeSellerRating((int) $data['reviewee_id']);
            }

            return $review;
        });

        if ($reviewee = User::find($data['reviewee_id'])) {
            $this->notifications->notify($reviewee, 'review.received', 'New review',
                $reviewer->name.' left you a '.$data['rating'].'★ review.', ['review_id' => $review->id]);
        }

        return ApiResponse::success(new ReviewResource($review->load(['reviewer', 'reviewee'])), 'Review submitted.', 201);
    }

    /** Reviews written by the current user. */
    public function mine(Request $request): JsonResponse
    {
        $reviews = $request->user()->reviewsWritten()->with('reviewee')->latest()->paginate(20);

        return ApiResponse::success(ReviewResource::collection($reviews), 'Reviews given.');
    }

    /** Reviews received by the current user. */
    public function received(Request $request): JsonResponse
    {
        $reviews = $request->user()->reviewsReceived()->approved()->with('reviewer')->latest()->paginate(20);

        return ApiResponse::success(ReviewResource::collection($reviews), 'Reviews received.');
    }

    /**
     * "Who bought?" — candidate buyers (users who chatted/offered) for a seller's ad.
     */
    public function potentialBuyers(Request $request, int $adId): JsonResponse
    {
        $ad = Ad::findOrFail($adId);
        abort_unless($ad->user_id === $request->user()->id, 403);

        $buyerIds = Conversation::where('ad_id', $ad->id)->pluck('buyer_id')
            ->merge(\App\Models\Offer::where('ad_id', $ad->id)->pluck('buyer_id'))
            ->unique()->values();

        $buyers = User::whereIn('id', $buyerIds)->get();

        return ApiResponse::success(UserResource::collection($buyers), 'Potential buyers.');
    }

    /**
     * Seller confirms the buyer of an ad → records sale + marks sold.
     */
    public function confirmBuyer(Request $request, int $adId): JsonResponse
    {
        $data = $request->validate(['buyer_id' => ['required', 'integer', 'exists:users,id']]);

        $ad = Ad::findOrFail($adId);
        abort_unless($ad->user_id === $request->user()->id, 403, 'Only the ad owner can confirm a buyer.');
        if ((int) $data['buyer_id'] === $ad->user_id) {
            return ApiResponse::error('Buyer cannot be the seller.', 422);
        }

        $sale = DB::transaction(function () use ($ad, $data) {
            $sale = AdSale::updateOrCreate(
                ['ad_id' => $ad->id],
                ['seller_id' => $ad->user_id, 'buyer_id' => $data['buyer_id'], 'confirmed_at' => now()]
            );
            $ad->update(['status' => 'sold', 'sold_at' => now()]);

            return $sale;
        });

        if ($buyer = User::find($data['buyer_id'])) {
            $this->notifications->notify($buyer, 'sale.confirmed', 'Purchase confirmed',
                'You were confirmed as the buyer of "'.$ad->title.'". Leave a review!',
                ['ad_id' => $ad->id, 'seller_id' => $ad->user_id]);
        }

        return ApiResponse::success(
            ['ad_id' => $ad->id, 'buyer_id' => $sale->buyer_id, 'status' => 'sold'],
            'Buyer confirmed; ad marked sold.'
        );
    }

    // ----- helpers -----

    private function assertEligible(int $reviewerId, int $revieweeId, ?int $adId, string $type): void
    {
        if ($type === 'seller_review') {
            // Buyer reviewing a seller: require interaction (conversation or confirmed sale).
            $hasConvo = Conversation::where('buyer_id', $reviewerId)->where('seller_id', $revieweeId)
                ->when($adId, fn ($q) => $q->where('ad_id', $adId))->exists();
            $hasSale = AdSale::where('buyer_id', $reviewerId)->where('seller_id', $revieweeId)
                ->when($adId, fn ($q) => $q->where('ad_id', $adId))->exists();
            if (! $hasConvo && ! $hasSale) {
                throw ValidationException::withMessages(['reviewee_id' => ['You can only review sellers you have interacted with.']]);
            }
        } else {
            // Seller reviewing a buyer: require a confirmed sale.
            $hasSale = AdSale::where('seller_id', $reviewerId)->where('buyer_id', $revieweeId)
                ->when($adId, fn ($q) => $q->where('ad_id', $adId))->exists();
            if (! $hasSale) {
                throw ValidationException::withMessages(['reviewee_id' => ['You can only review confirmed buyers.']]);
            }
        }
    }

    private function recomputeSellerRating(int $sellerId): void
    {
        $agg = Review::approved()->where('reviewee_id', $sellerId)->where('type', 'seller_review')
            ->selectRaw('AVG(rating) avg, COUNT(*) cnt')->first();

        $user = User::find($sellerId);
        $user?->sellerProfile()->updateOrCreate([], [
            'rating_avg'   => round((float) ($agg->avg ?? 0), 2),
            'rating_count' => (int) ($agg->cnt ?? 0),
        ]);
    }
}

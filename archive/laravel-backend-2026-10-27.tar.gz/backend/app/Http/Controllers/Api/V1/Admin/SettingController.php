<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * Admin "All in One Settings" — read/update settings by group
 * (general, web, ads, media, otp, payments, admob, commerce, firebase...).
 */
class SettingController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $query = Setting::query()
            ->when($request->filled('group'), fn ($q) => $q->where('group', $request->string('group')));

        $grouped = $query->get()->groupBy('group')->map(
            fn ($rows) => $rows->mapWithKeys(fn ($s) => [$s->key => [
                'value' => $s->typedValue(),
                'type'  => $s->type,
            ]])
        );

        return ApiResponse::success($grouped, 'Settings.');
    }

    /**
     * Bulk upsert settings for a group: { group, settings: { key: value, ... } }.
     */
    public function update(Request $request): JsonResponse
    {
        $data = $request->validate([
            'group'    => ['required', 'string', 'max:64'],
            'settings' => ['required', 'array'],
        ]);

        foreach ($data['settings'] as $key => $value) {
            $existing = Setting::where('group', $data['group'])->where('key', $key)->first();
            $type = $existing?->type ?? $this->inferType($value);

            Setting::updateOrCreate(
                ['group' => $data['group'], 'key' => $key],
                ['value' => $this->serialize($value, $type), 'type' => $type]
            );
        }

        return ApiResponse::success(null, 'Settings updated.');
    }

    private function inferType(mixed $value): string
    {
        return match (true) {
            is_bool($value)             => 'bool',
            is_int($value)              => 'int',
            is_array($value)            => 'json',
            default                     => 'string',
        };
    }

    private function serialize(mixed $value, string $type): string
    {
        return match ($type) {
            'bool' => $value ? '1' : '0',
            'json' => json_encode($value),
            default => (string) $value,
        };
    }
}

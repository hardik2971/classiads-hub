<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Resources\TransactionResource;
use App\Models\Transaction;
use App\Services\Billing\PaymentService;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class TransactionAdminController extends Controller
{
    public function __construct(private readonly PaymentService $paymentService) {}

    public function index(Request $request): JsonResponse
    {
        $txns = Transaction::with(['user', 'package', 'ad', 'invoice'])
            ->when($request->filled('status'), fn ($q) => $q->where('status', $request->string('status')))
            ->when($request->filled('type'), fn ($q) => $q->where('type', $request->string('type')))
            ->when($request->filled('gateway'), fn ($q) => $q->where('gateway', $request->string('gateway')))
            ->latest()
            ->paginate(min($request->integer('per_page', 20), 50));

        return ApiResponse::success(TransactionResource::collection($txns), 'Transactions.');
    }

    /**
     * Manually confirm a pending payment (e.g. bank transfer received).
     */
    public function confirm(int $id): JsonResponse
    {
        $transaction = Transaction::findOrFail($id);

        if ($transaction->isCompleted()) {
            return ApiResponse::success(new TransactionResource($transaction), 'Already completed.');
        }
        if ($transaction->status !== 'pending') {
            return ApiResponse::error('Transaction is not payable.', 422);
        }

        $transaction = $this->paymentService->fulfil($transaction);

        return ApiResponse::success(new TransactionResource($transaction->load('invoice')), 'Payment confirmed.');
    }

    public function refund(int $id): JsonResponse
    {
        $transaction = Transaction::findOrFail($id);

        if (! $transaction->isCompleted()) {
            return ApiResponse::error('Only completed transactions can be refunded.', 422);
        }

        $transaction = $this->paymentService->refund($transaction);

        return ApiResponse::success(new TransactionResource($transaction), 'Transaction refunded.');
    }
}

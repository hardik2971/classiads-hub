<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\JobApplicationResource;
use App\Http\Resources\JobListingResource;
use App\Models\JobApplication;
use App\Models\JobListing;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class JobController extends Controller
{
    // ---------- Public ----------

    public function index(Request $request): JsonResponse
    {
        $jobs = JobListing::query()->open()
            ->with(['city', 'category', 'employer'])
            ->when($request->filled('q'), fn ($q) => $q->where('title', 'like', '%'.$request->string('q').'%'))
            ->when($request->filled('employment_type'), fn ($q) => $q->where('employment_type', $request->string('employment_type')))
            ->when($request->filled('city_id'), fn ($q) => $q->where('city_id', $request->integer('city_id')))
            ->latest()
            ->paginate(min($request->integer('per_page', 20), 50));

        return ApiResponse::success(JobListingResource::collection($jobs), 'Jobs.');
    }

    public function show(Request $request, string $slug): JsonResponse
    {
        $job = JobListing::where('slug', $slug)->with(['city', 'category', 'employer'])->firstOrFail();

        if ($user = $request->user('sanctum')) {
            $job->has_applied = $job->applications()->where('user_id', $user->id)->exists();
        }

        return ApiResponse::success(new JobListingResource($job), 'Job.');
    }

    // ---------- Employer ----------

    public function myJobs(Request $request): JsonResponse
    {
        $jobs = JobListing::where('user_id', $request->user()->id)
            ->withCount('applications')->latest()
            ->paginate(min($request->integer('per_page', 20), 50));

        return ApiResponse::success(JobListingResource::collection($jobs), 'My jobs.');
    }

    public function store(Request $request): JsonResponse
    {
        $data = $this->validateData($request);
        $data['user_id'] = $request->user()->id;
        $data = $this->convertSalary($data);

        $job = JobListing::create($data);

        return ApiResponse::success(new JobListingResource($job), 'Job posted.', 201);
    }

    public function update(Request $request, int $id): JsonResponse
    {
        $job = JobListing::findOrFail($id);
        abort_unless($job->user_id === $request->user()->id, 403);

        $job->update($this->convertSalary($this->validateData($request, partial: true)));

        return ApiResponse::success(new JobListingResource($job), 'Job updated.');
    }

    public function destroy(Request $request, int $id): JsonResponse
    {
        $job = JobListing::findOrFail($id);
        abort_unless($job->user_id === $request->user()->id, 403);
        $job->delete();

        return ApiResponse::success(null, 'Job deleted.');
    }

    /** Applicants for one of the employer's jobs. */
    public function applications(Request $request, int $id): JsonResponse
    {
        $job = JobListing::findOrFail($id);
        abort_unless($job->user_id === $request->user()->id, 403);

        $apps = $job->applications()->with('applicant')->latest()
            ->paginate(min($request->integer('per_page', 20), 50));

        return ApiResponse::success(JobApplicationResource::collection($apps), 'Applications.');
    }

    public function setApplicationStatus(Request $request, int $id, int $appId): JsonResponse
    {
        $job = JobListing::findOrFail($id);
        abort_unless($job->user_id === $request->user()->id, 403);

        $data = $request->validate([
            'status' => ['required', Rule::in(['submitted', 'reviewed', 'shortlisted', 'rejected', 'hired'])],
        ]);

        $app = JobApplication::where('job_listing_id', $job->id)->findOrFail($appId);
        $app->update(['status' => $data['status']]);

        return ApiResponse::success(new JobApplicationResource($app), 'Application updated.');
    }

    private function validateData(Request $request, bool $partial = false): array
    {
        $req = $partial ? 'sometimes' : 'required';

        return $request->validate([
            'title'           => [$req, 'string', 'max:191'],
            'description'     => [$req, 'string', 'min:10'],
            'company_name'    => ['nullable', 'string', 'max:191'],
            'category_id'     => ['nullable', 'integer', 'exists:categories,id'],
            'city_id'         => ['nullable', 'integer', 'exists:cities,id'],
            'employment_type' => ['nullable', Rule::in(['full_time', 'part_time', 'contract', 'internship', 'remote'])],
            'salary_min'      => ['nullable', 'numeric', 'min:0'],
            'salary_max'      => ['nullable', 'numeric', 'min:0'],
            'currency_code'   => ['nullable', 'string', 'size:3'],
            'status'          => ['nullable', Rule::in(['draft', 'open', 'closed'])],
            'expires_at'      => ['nullable', 'date'],
        ]);
    }

    private function convertSalary(array $data): array
    {
        foreach (['salary_min', 'salary_max'] as $k) {
            if (array_key_exists($k, $data) && $data[$k] !== null) {
                $data[$k] = (int) round((float) $data[$k] * 100);
            }
        }

        return $data;
    }
}

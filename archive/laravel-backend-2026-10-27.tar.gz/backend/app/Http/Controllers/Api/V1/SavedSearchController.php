<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\AdResource;
use App\Models\Ad;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class SavedSearchController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $searches = $request->user()->savedSearches()->latest()->get();

        return ApiResponse::success($searches, 'Saved searches.');
    }

    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'name'   => ['nullable', 'string', 'max:150'],
            'query'  => ['required', 'array'],
            'notify' => ['nullable', 'boolean'],
        ]);

        $search = $request->user()->savedSearches()->create([
            'name'   => $data['name'] ?? null,
            'query'  => $data['query'],
            'notify' => $data['notify'] ?? false,
        ]);

        return ApiResponse::success($search, 'Search saved.', 201);
    }

    public function destroy(Request $request, int $id): JsonResponse
    {
        $search = $request->user()->savedSearches()->findOrFail($id);
        $search->delete();

        return ApiResponse::success(null, 'Saved search removed.');
    }

    /**
     * Re-run a saved search and return matching ads.
     */
    public function run(Request $request, int $id): JsonResponse
    {
        $search = $request->user()->savedSearches()->findOrFail($id);
        $search->update(['last_run_at' => now()]);

        $f = $search->query;
        $ads = Ad::query()->published()
            ->with(['images', 'category', 'city'])
            ->filter($f)
            ->sort($f['sort'] ?? null)
            ->paginate(min((int) ($f['per_page'] ?? 20), 50));

        return ApiResponse::success(AdResource::collection($ads), 'Saved search results.');
    }
}

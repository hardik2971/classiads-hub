<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Resources\UserResource;
use App\Models\User;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class UserManagementController extends Controller
{
    /**
     * List users; ?role=seller|customer, ?q=search, ?status=.
     */
    public function index(Request $request): JsonResponse
    {
        $users = User::query()
            ->when($request->filled('role'), fn ($q) => $q->role($request->string('role')->toString()))
            ->when($request->filled('status'), fn ($q) => $q->where('status', $request->string('status')))
            ->when($request->filled('q'), function ($q) use ($request) {
                $term = '%'.$request->string('q').'%';
                $q->where(fn ($q) => $q->where('name', 'like', $term)
                    ->orWhere('email', 'like', $term)
                    ->orWhere('phone', 'like', $term));
            })
            ->with('roles')
            ->withCount('ads')
            ->latest()
            ->paginate(min($request->integer('per_page', 20), 50));

        return ApiResponse::success(UserResource::collection($users), 'Users.');
    }

    public function show(int $id): JsonResponse
    {
        $user = User::with(['roles', 'sellerProfile'])->withCount('ads')->findOrFail($id);

        return ApiResponse::success(new UserResource($user), 'User.');
    }

    /**
     * Change a user's account status (active|suspended|banned).
     */
    public function setStatus(Request $request, int $id): JsonResponse
    {
        $data = $request->validate([
            'status' => ['required', Rule::in(['active', 'suspended', 'banned'])],
        ]);

        $user = User::findOrFail($id);
        abort_if($user->hasRole('super-admin'), 403, 'Cannot modify a super-admin.');

        $user->update(['status' => $data['status']]);
        if ($data['status'] !== 'active') {
            $user->tokens()->delete(); // force logout
        }

        return ApiResponse::success(new UserResource($user->load('roles')), 'User status updated.');
    }
}

<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Models\PaymentGateway;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class PaymentGatewayController extends Controller
{
    public function index(): JsonResponse
    {
        // Admin may view config (credentials) to manage gateways.
        $gateways = PaymentGateway::orderBy('sort_order')->get()->makeVisible('config');

        return ApiResponse::success($gateways, 'Payment gateways.');
    }

    public function update(Request $request, int $id): JsonResponse
    {
        $gateway = PaymentGateway::findOrFail($id);

        $data = $request->validate([
            'name'                 => ['sometimes', 'string', 'max:100'],
            'is_active'            => ['sometimes', 'boolean'],
            'mode'                 => ['sometimes', Rule::in(['sandbox', 'live'])],
            'config'               => ['sometimes', 'nullable', 'array'],
            'supported_currencies' => ['sometimes', 'nullable', 'array'],
            'is_manual'            => ['sometimes', 'boolean'],
            'sort_order'           => ['sometimes', 'integer'],
        ]);

        $gateway->update($data);

        return ApiResponse::success($gateway->makeVisible('config'), 'Gateway updated.');
    }
}

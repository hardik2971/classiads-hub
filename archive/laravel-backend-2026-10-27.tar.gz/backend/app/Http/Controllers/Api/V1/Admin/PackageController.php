<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Resources\PackageResource;
use App\Models\Package;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class PackageController extends Controller
{
    public function index(): JsonResponse
    {
        return ApiResponse::success(
            PackageResource::collection(Package::with('categories')->orderBy('sort_order')->get()),
            'Packages.'
        );
    }

    public function store(Request $request): JsonResponse
    {
        $data = $this->validateData($request);
        $package = Package::create($this->prepare($data));
        $this->syncCategories($package, $data);

        return ApiResponse::success(new PackageResource($package->load('categories')), 'Package created.', 201);
    }

    public function update(Request $request, int $id): JsonResponse
    {
        $package = Package::findOrFail($id);
        $data = $this->validateData($request, partial: true);
        $package->update($this->prepare($data, $package));
        $this->syncCategories($package, $data);

        return ApiResponse::success(new PackageResource($package->load('categories')), 'Package updated.');
    }

    public function destroy(int $id): JsonResponse
    {
        Package::findOrFail($id)->delete();

        return ApiResponse::success(null, 'Package deleted.');
    }

    private function validateData(Request $request, bool $partial = false): array
    {
        $req = $partial ? 'sometimes' : 'required';

        return $request->validate([
            'name'               => [$req, 'string', 'max:150'],
            'description'        => ['nullable', 'string'],
            'price'              => [$req, 'numeric', 'min:0'],          // major units
            'discount_percent'   => ['nullable', 'integer', 'min:0', 'max:100'],
            'currency_code'      => ['nullable', 'string', 'size:3'],
            'duration_days'      => [$req, 'integer', 'min:1'],
            'ad_limit'           => ['nullable', 'integer', 'min:0'],
            'is_unlimited'       => ['nullable', 'boolean'],
            'ios_product_id'     => ['nullable', 'string', 'max:191'],
            'android_product_id' => ['nullable', 'string', 'max:191'],
            'is_active'          => ['nullable', 'boolean'],
            'sort_order'         => ['nullable', 'integer'],
            'category_ids'       => ['nullable', 'array'],
            'category_ids.*'     => ['integer', 'exists:categories,id'],
        ]);
    }

    private function prepare(array $data, ?Package $existing = null): array
    {
        $attrs = collect($data)->except(['price', 'category_ids'])->toArray();

        $discount = $data['discount_percent'] ?? $existing?->discount_percent ?? 0;

        if (array_key_exists('price', $data)) {
            $priceMinor = (int) round((float) $data['price'] * 100);
            $attrs['price'] = $priceMinor;
            $attrs['final_price'] = Package::computeFinal($priceMinor, (int) $discount);
        } elseif (array_key_exists('discount_percent', $data) && $existing) {
            $attrs['final_price'] = Package::computeFinal((int) $existing->price, (int) $discount);
        }

        return $attrs;
    }

    private function syncCategories(Package $package, array $data): void
    {
        if (array_key_exists('category_ids', $data)) {
            $package->categories()->sync($data['category_ids'] ?? []);
        }
    }
}

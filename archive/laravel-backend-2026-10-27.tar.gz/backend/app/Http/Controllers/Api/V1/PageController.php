<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\PageResource;
use App\Models\Page;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;

class PageController extends Controller
{
    public function index(): JsonResponse
    {
        $pages = Page::published()->get(['key', 'title', 'updated_at']);

        return ApiResponse::success(PageResource::collection($pages), 'Pages.');
    }

    public function show(string $key): JsonResponse
    {
        $page = Page::published()->where('key', $key)->firstOrFail();

        return ApiResponse::success(new PageResource($page), 'Page.');
    }
}

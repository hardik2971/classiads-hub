<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Models\PushNotification;
use App\Models\User;
use App\Services\Notifications\NotificationService;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class PushNotificationController extends Controller
{
    public function __construct(private readonly NotificationService $notifications) {}

    /** Sent-notification history. */
    public function index(Request $request): JsonResponse
    {
        $history = PushNotification::with(['sender', 'targetUser'])
            ->latest()
            ->paginate(min($request->integer('per_page', 20), 50));

        return ApiResponse::success($history, 'Push notification history.');
    }

    /**
     * Compose + send a push notification to all / a role / a single user.
     */
    public function send(Request $request): JsonResponse
    {
        $data = $request->validate([
            'title'          => ['required', 'string', 'max:191'],
            'body'           => ['required', 'string', 'max:2000'],
            'target'         => ['required', Rule::in(['all', 'role', 'user'])],
            'target_role'    => ['required_if:target,role', 'nullable', 'string', 'max:50'],
            'target_user_id' => ['required_if:target,user', 'nullable', 'integer', 'exists:users,id'],
            'item_type'      => ['nullable', 'string', 'max:100'],
            'item_id'        => ['nullable', 'integer'],
        ]);

        $recipients = match ($data['target']) {
            'user' => User::where('id', $data['target_user_id'])->get(),
            'role' => User::role($data['target_role'])->get(),
            default => User::query()->where('status', 'active')->get(),
        };

        $payload = array_filter([
            'item_type' => $data['item_type'] ?? null,
            'item_id'   => $data['item_id'] ?? null,
        ]);

        $count = $this->notifications->notifyMany(
            $recipients, 'admin.broadcast', $data['title'], $data['body'], $payload
        );

        $record = PushNotification::create([
            'title'            => $data['title'],
            'body'             => $data['body'],
            'target'           => $data['target'],
            'target_role'      => $data['target_role'] ?? null,
            'target_user_id'   => $data['target_user_id'] ?? null,
            'item_type'        => $data['item_type'] ?? null,
            'item_id'          => $data['item_id'] ?? null,
            'sent_by'          => $request->user()->id,
            'recipients_count' => $count,
        ]);

        return ApiResponse::success(
            ['id' => $record->id, 'recipients_count' => $count],
            "Sent to {$count} recipient(s).",
            201
        );
    }
}

<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\VerificationRequestResource;
use App\Models\VerificationRequest;
use App\Services\Media\MediaService;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class VerificationController extends Controller
{
    public function __construct(private readonly MediaService $media) {}

    /** Current user's latest verification request + verified flag. */
    public function status(Request $request): JsonResponse
    {
        $latest = VerificationRequest::where('user_id', $request->user()->id)->latest()->first();

        return ApiResponse::success([
            'is_verified' => (bool) $request->user()->is_verified,
            'request'     => $latest ? new VerificationRequestResource($latest) : null,
        ], 'Verification status.');
    }

    /** Submit KYC documents. */
    public function submit(Request $request): JsonResponse
    {
        $user = $request->user();

        if ($user->is_verified) {
            return ApiResponse::error('Your account is already verified.', 422);
        }
        if (VerificationRequest::where('user_id', $user->id)->where('status', 'pending')->exists()) {
            return ApiResponse::error('You already have a pending verification request.', 422);
        }

        $data = $request->validate([
            'document_type'   => ['required', Rule::in(['id_card', 'passport', 'driving_license', 'other'])],
            'document_number' => ['nullable', 'string', 'max:100'],
            'front_image'     => ['required', 'image', 'mimes:jpg,jpeg,png,webp', 'max:5120'],
            'back_image'      => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:5120'],
            'selfie_image'    => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:5120'],
        ]);

        $req = VerificationRequest::create([
            'user_id'           => $user->id,
            'document_type'     => $data['document_type'],
            'document_number'   => $data['document_number'] ?? null,
            'front_image_path'  => $this->media->storeImage($request->file('front_image'), "kyc/{$user->id}"),
            'back_image_path'   => $request->hasFile('back_image') ? $this->media->storeImage($request->file('back_image'), "kyc/{$user->id}") : null,
            'selfie_image_path' => $request->hasFile('selfie_image') ? $this->media->storeImage($request->file('selfie_image'), "kyc/{$user->id}") : null,
            'status'            => 'pending',
        ]);

        return ApiResponse::success(new VerificationRequestResource($req), 'Verification submitted for review.', 201);
    }
}

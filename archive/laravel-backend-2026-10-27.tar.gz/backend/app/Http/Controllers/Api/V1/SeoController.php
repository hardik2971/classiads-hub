<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Ad;
use App\Models\BlogPost;
use App\Models\Category;
use App\Services\Seo\SeoService;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * Serves SEO metadata + JSON-LD to the Next.js frontend for SSR/ISR rendering.
 */
class SeoController extends Controller
{
    public function __construct(private readonly SeoService $seo) {}

    /**
     * GET /seo?route=home   or   /seo?type=ad&slug=...
     */
    public function show(Request $request): JsonResponse
    {
        if ($request->filled('route')) {
            return ApiResponse::success($this->seo->forRoute($request->string('route')->toString()), 'SEO.');
        }

        $type = $request->string('type')->toString();
        $slug = $request->string('slug')->toString();

        $model = match ($type) {
            'ad'       => Ad::where('slug', $slug)->first(),
            'category' => Category::where('slug', $slug)->first(),
            'blog'     => BlogPost::where('slug', $slug)->first(),
            default    => null,
        };

        if (! $model) {
            return ApiResponse::success($this->seo->forRoute('home'), 'SEO (default).');
        }

        return ApiResponse::success($this->seo->forModel($model), 'SEO.');
    }
}

<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\UserResource;
use App\Models\User;
use App\Services\Otp\OtpService;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

class AuthController extends Controller
{
    public function __construct(private readonly OtpService $otp) {}

    /**
     * Register a new account (customer by default).
     */
    public function register(Request $request): JsonResponse
    {
        $data = $request->validate([
            'name'     => ['required', 'string', 'max:150'],
            'email'    => ['nullable', 'email', 'max:191', 'unique:users,email'],
            'phone'    => ['nullable', 'string', 'max:32', 'unique:users,phone'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
        ]);

        if (empty($data['email']) && empty($data['phone'])) {
            throw ValidationException::withMessages([
                'email' => ['Either email or phone is required.'],
            ]);
        }

        $user = User::create([
            'name'     => $data['name'],
            'email'    => $data['email'] ?? null,
            'phone'    => $data['phone'] ?? null,
            'password' => Hash::make($data['password']),
            'status'   => 'active',
        ]);
        $user->assignRole('customer');

        // Issue OTP for verification of the provided channel.
        $identifier = $data['email'] ?? $data['phone'];
        $channel    = ! empty($data['email']) ? 'email' : 'sms';
        $otp        = $this->otp->send($identifier, $channel, 'register');

        $token = $user->createToken('api')->plainTextToken;

        return ApiResponse::success([
            'user'  => new UserResource($user->load('roles')),
            'token' => $token,
            'otp'   => ['otp_id' => $otp['otp_id'], 'debug_code' => $otp['debug_code']],
        ], 'Registered. Verify the OTP sent to your '.$channel.'.', 201);
    }

    /**
     * Login with email/phone + password.
     */
    public function login(Request $request): JsonResponse
    {
        $data = $request->validate([
            'login'    => ['required', 'string'], // email or phone
            'password' => ['required', 'string'],
            'device'   => ['nullable', 'string', 'max:191'],
        ]);

        $user = User::where('email', $data['login'])
            ->orWhere('phone', $data['login'])
            ->first();

        if (! $user || ! $user->password || ! Hash::check($data['password'], $user->password)) {
            throw ValidationException::withMessages([
                'login' => ['These credentials do not match our records.'],
            ]);
        }

        if (! $user->isActive()) {
            return ApiResponse::error('Your account is '.$user->status.'.', 403);
        }

        $user->forceFill(['last_login_at' => now()])->save();

        $token = $user->createToken($data['device'] ?? 'api')->plainTextToken;

        return ApiResponse::success([
            'user'  => new UserResource($user->load(['roles', 'sellerProfile'])),
            'token' => $token,
        ], 'Logged in.');
    }

    /**
     * Send an OTP to an email or phone for a given purpose.
     */
    public function sendOtp(Request $request): JsonResponse
    {
        $data = $request->validate([
            'identifier' => ['required', 'string', 'max:191'],
            'channel'    => ['required', Rule::in(['sms', 'email'])],
            'purpose'    => ['required', Rule::in(['register', 'login', 'reset', 'verify'])],
        ]);

        $otp = $this->otp->send($data['identifier'], $data['channel'], $data['purpose']);

        return ApiResponse::success(
            ['otp_id' => $otp['otp_id'], 'debug_code' => $otp['debug_code']],
            'OTP sent.'
        );
    }

    /**
     * Verify an OTP code. For "verify"/"register" purposes it also marks the user verified.
     */
    public function verifyOtp(Request $request): JsonResponse
    {
        $data = $request->validate([
            'identifier' => ['required', 'string', 'max:191'],
            'purpose'    => ['required', Rule::in(['register', 'login', 'reset', 'verify'])],
            'code'       => ['required', 'string'],
        ]);

        if (! $this->otp->verify($data['identifier'], $data['purpose'], $data['code'])) {
            throw ValidationException::withMessages([
                'code' => ['Invalid or expired code.'],
            ]);
        }

        // Mark the matching channel verified.
        $user = User::where('email', $data['identifier'])
            ->orWhere('phone', $data['identifier'])
            ->first();

        if ($user && in_array($data['purpose'], ['register', 'verify'], true)) {
            $field = $user->email === $data['identifier'] ? 'email_verified_at' : 'phone_verified_at';
            $user->forceFill([$field => now()])->save();
        }

        return ApiResponse::success(['verified' => true], 'OTP verified.');
    }

    /**
     * Forgot password — issues a reset OTP.
     */
    public function forgotPassword(Request $request): JsonResponse
    {
        $data = $request->validate([
            'login' => ['required', 'string'],
        ]);

        $user = User::where('email', $data['login'])->orWhere('phone', $data['login'])->first();

        // Always respond success to avoid user enumeration.
        if ($user) {
            $identifier = $user->email === $data['login'] ? $user->email : $user->phone;
            $channel    = $user->email === $data['login'] ? 'email' : 'sms';
            $otp        = $this->otp->send($identifier, $channel, 'reset');

            return ApiResponse::success(
                ['otp_id' => $otp['otp_id'], 'debug_code' => $otp['debug_code']],
                'If the account exists, a reset code has been sent.'
            );
        }

        return ApiResponse::success(null, 'If the account exists, a reset code has been sent.');
    }

    /**
     * Reset password using a verified OTP code.
     */
    public function resetPassword(Request $request): JsonResponse
    {
        $data = $request->validate([
            'login'    => ['required', 'string'],
            'code'     => ['required', 'string'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
        ]);

        if (! $this->otp->verify($data['login'], 'reset', $data['code'])) {
            throw ValidationException::withMessages([
                'code' => ['Invalid or expired code.'],
            ]);
        }

        $user = User::where('email', $data['login'])->orWhere('phone', $data['login'])->firstOrFail();
        $user->forceFill(['password' => Hash::make($data['password'])])->save();
        $user->tokens()->delete(); // revoke all sessions

        return ApiResponse::success(null, 'Password reset. Please log in again.');
    }

    /**
     * Current authenticated user.
     */
    public function me(Request $request): JsonResponse
    {
        return ApiResponse::success(
            new UserResource($request->user()->load(['roles', 'sellerProfile'])),
            'OK'
        );
    }

    /**
     * Update own profile.
     */
    public function updateProfile(Request $request): JsonResponse
    {
        $user = $request->user();

        $data = $request->validate([
            'name'               => ['sometimes', 'string', 'max:150'],
            'email'              => ['sometimes', 'nullable', 'email', 'max:191', Rule::unique('users', 'email')->ignore($user->id)],
            'phone'              => ['sometimes', 'nullable', 'string', 'max:32', Rule::unique('users', 'phone')->ignore($user->id)],
            'preferred_language' => ['sometimes', 'nullable', 'string', 'max:8'],
            'preferred_currency' => ['sometimes', 'nullable', 'string', 'max:8'],
        ]);

        $user->update($data);

        return ApiResponse::success(
            new UserResource($user->fresh()->load(['roles', 'sellerProfile'])),
            'Profile updated.'
        );
    }

    /**
     * Logout — revoke current token.
     */
    public function logout(Request $request): JsonResponse
    {
        $request->user()->currentAccessToken()->delete();

        return ApiResponse::success(null, 'Logged out.');
    }

    /**
     * Register/refresh an FCM device token.
     */
    public function registerDevice(Request $request): JsonResponse
    {
        $data = $request->validate([
            'fcm_token'   => ['required', 'string', 'max:255'],
            'platform'    => ['required', Rule::in(['android', 'ios', 'web'])],
            'device_name' => ['nullable', 'string', 'max:191'],
        ]);

        $device = $request->user()->devices()->updateOrCreate(
            ['fcm_token' => $data['fcm_token']],
            ['platform' => $data['platform'], 'device_name' => $data['device_name'] ?? null, 'last_active_at' => now()]
        );

        return ApiResponse::success(['device_id' => $device->id], 'Device registered.');
    }

    /**
     * Delete own account (GDPR / store-compliance). Requires password confirmation
     * for password accounts. Anonymizes PII, revokes tokens, soft-deletes.
     */
    public function deleteAccount(Request $request): JsonResponse
    {
        $user = $request->user();

        if ($user->password) {
            $request->validate(['password' => ['required', 'string']]);
            if (! Hash::check($request->input('password'), $user->password)) {
                throw ValidationException::withMessages(['password' => ['Password is incorrect.']]);
            }
        }

        // Free up unique identifiers and scrub PII so re-registration is possible.
        $user->forceFill([
            'email'  => $user->email ? 'deleted_'.$user->id.'_'.substr(md5($user->email), 0, 8).'@deleted.local' : null,
            'phone'  => null,
            'name'   => 'Deleted User',
            'avatar_path' => null,
            'status' => 'banned',
        ])->save();

        $user->tokens()->delete();
        $user->devices()->delete();
        $user->delete(); // soft delete

        return ApiResponse::success(null, 'Your account has been deleted.');
    }
}

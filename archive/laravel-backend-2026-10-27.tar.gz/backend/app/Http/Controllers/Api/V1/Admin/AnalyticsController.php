<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Models\Ad;
use App\Models\Category;
use App\Models\CustomField;
use App\Models\Subscription;
use App\Models\Transaction;
use App\Models\User;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;

/**
 * Insightful dashboard — KPIs, revenue, and recent activity.
 */
class AnalyticsController extends Controller
{
    public function dashboard(): JsonResponse
    {
        $customerRole = Role::where('name', 'customer')->first();

        $revenueCents = (int) Transaction::where('status', 'completed')->sum('total');

        return ApiResponse::success([
            'kpis' => [
                'total_customers'      => $customerRole ? $customerRole->users()->count() : User::count(),
                'total_users'          => User::count(),
                'total_ads'            => Ad::count(),
                'pending_ads'          => Ad::where('status', 'pending')->count(),
                'total_categories'     => Category::count(),
                'custom_fields'        => CustomField::count(),
                'active_subscriptions' => Subscription::where('status', 'active')->count(),
                'total_revenue'        => $revenueCents,
                'total_revenue_display' => 'USD '.number_format($revenueCents / 100, 2),
            ],
            'ads_by_status' => Ad::select('status', DB::raw('count(*) as count'))
                ->groupBy('status')->pluck('count', 'status'),
            'revenue_by_type' => Transaction::where('status', 'completed')
                ->select('type', DB::raw('sum(total) as total'))
                ->groupBy('type')->pluck('total', 'type'),
            'top_viewed_ads' => Ad::query()->published()
                ->orderByDesc('views_count')->limit(5)
                ->get(['id', 'title', 'slug', 'views_count']),
            'recent_transactions' => Transaction::with('user')
                ->where('status', 'completed')->latest()->limit(5)
                ->get(['id', 'user_id', 'type', 'total', 'currency_code', 'paid_at']),
        ], 'Dashboard.');
    }
}

<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\AdResource;
use App\Http\Resources\ReviewResource;
use App\Http\Resources\UserResource;
use App\Models\Ad;
use App\Models\Review;
use App\Models\User;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class SellerController extends Controller
{
    /**
     * Public seller profile: info, follow counts, rating summary.
     */
    public function show(Request $request, int $id): JsonResponse
    {
        $seller = User::with('sellerProfile')
            ->withCount(['followers', 'following', 'ads' => fn ($q) => $q->where('status', 'approved')])
            ->findOrFail($id);

        // Public route: resolve the optional viewer via the sanctum guard (bearer token).
        $viewer = $request->user('sanctum');
        $isFollowing = $viewer
            ? $viewer->following()->wherePivot('following_id', $seller->id)->exists()
            : false;

        return ApiResponse::success([
            'seller'        => new UserResource($seller),
            'followers'     => $seller->followers_count,
            'following'     => $seller->following_count,
            'live_ads'      => $seller->ads_count,
            'rating_avg'    => (float) ($seller->sellerProfile->rating_avg ?? 0),
            'rating_count'  => (int) ($seller->sellerProfile->rating_count ?? 0),
            'is_following'  => $isFollowing,
        ], 'Seller profile.');
    }

    /**
     * A seller's live (approved) ads.
     */
    public function ads(Request $request, int $id): JsonResponse
    {
        $ads = Ad::query()->published()
            ->where('user_id', $id)
            ->with(['images', 'city'])
            ->latest('published_at')
            ->paginate(min($request->integer('per_page', 20), 50));

        return ApiResponse::success(AdResource::collection($ads), 'Seller ads.');
    }

    /**
     * Reviews received by a seller.
     */
    public function reviews(Request $request, int $id): JsonResponse
    {
        $reviews = Review::query()->approved()
            ->where('reviewee_id', $id)
            ->where('type', 'seller_review')
            ->with('reviewer')
            ->latest()
            ->paginate(min($request->integer('per_page', 20), 50));

        return ApiResponse::success(ReviewResource::collection($reviews), 'Seller reviews.');
    }
}

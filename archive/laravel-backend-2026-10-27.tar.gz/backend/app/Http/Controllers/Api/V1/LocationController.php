<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\CityResource;
use App\Http\Resources\CountryResource;
use App\Http\Resources\StateResource;
use App\Models\City;
use App\Models\Country;
use App\Models\State;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class LocationController extends Controller
{
    public function countries(): JsonResponse
    {
        return ApiResponse::success(
            CountryResource::collection(Country::active()->orderBy('name')->get()),
            'Countries.'
        );
    }

    public function states(Request $request): JsonResponse
    {
        $request->validate(['country_id' => ['required', 'integer', 'exists:countries,id']]);

        $states = State::active()
            ->where('country_id', $request->integer('country_id'))
            ->orderBy('name')->get();

        return ApiResponse::success(StateResource::collection($states), 'States.');
    }

    public function cities(Request $request): JsonResponse
    {
        $request->validate([
            'state_id'   => ['nullable', 'integer', 'exists:states,id'],
            'country_id' => ['nullable', 'integer', 'exists:countries,id'],
        ]);

        $cities = City::active()
            ->when($request->filled('state_id'), fn ($q) => $q->where('state_id', $request->integer('state_id')))
            ->when($request->filled('country_id'), fn ($q) => $q->where('country_id', $request->integer('country_id')))
            ->orderBy('name')->get();

        return ApiResponse::success(CityResource::collection($cities), 'Cities.');
    }
}

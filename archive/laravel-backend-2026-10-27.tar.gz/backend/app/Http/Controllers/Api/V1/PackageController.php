<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\FeaturedAdPlanResource;
use App\Http\Resources\PackageResource;
use App\Models\FeaturedAdPlan;
use App\Models\Package;
use App\Services\Payments\PaymentManager;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class PackageController extends Controller
{
    /**
     * Public subscription packages, optionally filtered by category.
     */
    public function index(Request $request): JsonResponse
    {
        $packages = Package::active()->with('categories')
            ->when($request->filled('category_id'), function ($q) use ($request) {
                $cid = $request->integer('category_id');
                $q->whereHas('categories', fn ($c) => $c->where('categories.id', $cid));
            })
            ->orderBy('sort_order')
            ->get();

        return ApiResponse::success(PackageResource::collection($packages), 'Packages.');
    }

    public function show(int $id): JsonResponse
    {
        $package = Package::active()->with('categories')->findOrFail($id);

        return ApiResponse::success(new PackageResource($package), 'Package.');
    }

    /** Featured-ad pricing plans. */
    public function featuredPlans(): JsonResponse
    {
        return ApiResponse::success(
            FeaturedAdPlanResource::collection(FeaturedAdPlan::active()->orderBy('sort_order')->get()),
            'Featured ad plans.'
        );
    }

    /** Payment gateways available to clients (no secrets). */
    public function gateways(PaymentManager $payments): JsonResponse
    {
        return ApiResponse::success($payments->availableGateways(), 'Payment gateways.');
    }
}

<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\AdImageResource;
use App\Models\Ad;
use App\Models\Setting;
use App\Services\Media\MediaService;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class AdImageController extends Controller
{
    public function __construct(private readonly MediaService $media) {}

    /**
     * Upload one or more images for an ad (owner only).
     */
    public function store(Request $request, int $adId): JsonResponse
    {
        $ad = Ad::findOrFail($adId);
        $this->authorizeOwner($request, $ad);

        $max = (int) Setting::get('ads', 'max_images_per_ad', 10);

        $request->validate([
            'images'   => ['required', 'array', 'min:1'],
            'images.*' => ['image', 'mimes:jpg,jpeg,png,webp', 'max:5120'],
        ]);

        $current = $ad->images()->count();
        if ($current + count($request->file('images')) > $max) {
            return ApiResponse::error("Maximum {$max} images per ad.", 422);
        }

        $created = [];
        foreach ($request->file('images') as $i => $file) {
            $path = $this->media->storeImage($file, "ads/{$ad->id}");
            $created[] = $ad->images()->create([
                'path'       => $path,
                'disk'       => $this->media->disk(),
                'is_primary' => $current === 0 && $i === 0,
                'sort_order' => $current + $i,
            ]);
        }

        return ApiResponse::success(
            AdImageResource::collection(collect($created)),
            'Images uploaded.',
            201
        );
    }

    public function setPrimary(Request $request, int $adId, int $imageId): JsonResponse
    {
        $ad = Ad::findOrFail($adId);
        $this->authorizeOwner($request, $ad);

        $ad->images()->update(['is_primary' => false]);
        $ad->images()->whereKey($imageId)->update(['is_primary' => true]);

        return ApiResponse::success(null, 'Primary image set.');
    }

    public function destroy(Request $request, int $adId, int $imageId): JsonResponse
    {
        $ad = Ad::findOrFail($adId);
        $this->authorizeOwner($request, $ad);

        $image = $ad->images()->findOrFail($imageId);
        $image->delete(); // model event removes the file

        return ApiResponse::success(null, 'Image deleted.');
    }

    private function authorizeOwner(Request $request, Ad $ad): void
    {
        $user = $request->user();
        abort_unless($user->id === $ad->user_id || $user->hasAnyRole(['admin', 'super-admin']), 403);
    }
}

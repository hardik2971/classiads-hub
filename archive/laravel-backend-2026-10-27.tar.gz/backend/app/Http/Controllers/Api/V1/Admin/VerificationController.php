<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Resources\VerificationRequestResource;
use App\Models\VerificationRequest;
use App\Services\Audit\AuditLogger;
use App\Services\Notifications\NotificationService;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class VerificationController extends Controller
{
    public function __construct(
        private readonly NotificationService $notifications,
        private readonly AuditLogger $audit,
    ) {}

    public function index(Request $request): JsonResponse
    {
        $reqs = VerificationRequest::with('user')
            ->when($request->filled('status'), fn ($q) => $q->where('status', $request->string('status')), fn ($q) => $q->where('status', 'pending'))
            ->latest()
            ->paginate(min($request->integer('per_page', 20), 50));

        return ApiResponse::success(VerificationRequestResource::collection($reqs), 'Verification requests.');
    }

    public function approve(Request $request, int $id): JsonResponse
    {
        $req = VerificationRequest::findOrFail($id);
        $req->update(['status' => 'approved', 'reviewed_by' => $request->user()->id, 'reviewed_at' => now(), 'rejection_reason' => null]);
        $req->user->update(['is_verified' => true]);

        $this->audit->log('verification.approved', $req, ['user_id' => $req->user_id]);
        $this->notifications->notify($req->user, 'verification.approved', 'You are verified!',
            'Your account has been verified. The verified badge is now on your profile.', []);

        return ApiResponse::success(new VerificationRequestResource($req), 'Verification approved.');
    }

    public function reject(Request $request, int $id): JsonResponse
    {
        $data = $request->validate(['reason' => ['required', 'string', 'max:255']]);

        $req = VerificationRequest::findOrFail($id);
        $req->update(['status' => 'rejected', 'reviewed_by' => $request->user()->id, 'reviewed_at' => now(), 'rejection_reason' => $data['reason']]);

        $this->audit->log('verification.rejected', $req, ['reason' => $data['reason']]);
        $this->notifications->notify($req->user, 'verification.rejected', 'Verification rejected',
            'Your verification was rejected: '.$data['reason'], []);

        return ApiResponse::success(new VerificationRequestResource($req), 'Verification rejected.');
    }
}

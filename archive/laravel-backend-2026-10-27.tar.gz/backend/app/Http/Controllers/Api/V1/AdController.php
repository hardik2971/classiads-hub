<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreAdRequest;
use App\Http\Requests\UpdateAdRequest;
use App\Http\Resources\AdResource;
use App\Models\Ad;
use App\Models\Category;
use App\Models\Setting;
use App\Services\Ads\AdFieldService;
use App\Services\Billing\SubscriptionService;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AdController extends Controller
{
    public function __construct(
        private readonly AdFieldService $fields,
        private readonly SubscriptionService $subscriptions,
    ) {}

    /**
     * Public search / browse — only published ads.
     */
    public function index(Request $request): JsonResponse
    {
        $filters = $request->only([
            'category_id', 'category_slug', 'country_id', 'state_id', 'city_id',
            'price_min', 'price_max', 'condition', 'featured', 'q',
        ]);

        $query = Ad::query()->published()
            ->with(['images', 'category', 'city', 'state', 'country', 'user'])
            ->filter($filters)
            ->sort($request->string('sort')->toString());

        // Custom-field filters: ?cf[brand]=toyota&cf[fuel_type]=petrol
        if ($request->filled('cf') && is_array($request->cf)) {
            foreach ($request->cf as $code => $value) {
                $query->whereHas('fieldValues', function ($q) use ($code, $value) {
                    $q->whereHas('customField', fn ($c) => $c->where('code', $code))
                        ->where('value', $value);
                });
            }
        }

        $ads = $query->paginate(min($request->integer('per_page', 20), 50));
        $this->markFavorited($ads->getCollection(), $request);

        return ApiResponse::success(AdResource::collection($ads), 'Ads.');
    }

    /**
     * Nearby ads within a radius (km) of a coordinate.
     */
    public function nearby(Request $request): JsonResponse
    {
        $data = $request->validate([
            'latitude'  => ['required', 'numeric', 'between:-90,90'],
            'longitude' => ['required', 'numeric', 'between:-180,180'],
            'radius'    => ['nullable', 'numeric', 'min:1', 'max:500'],
        ]);

        $radius = $data['radius'] ?? Setting::get('ads', 'nearby_radius_km', 25);
        $haversine = '(6371 * acos(cos(radians(?)) * cos(radians(latitude)) * cos(radians(longitude) - radians(?)) + sin(radians(?)) * sin(radians(latitude))))';

        $ads = Ad::query()->published()
            ->whereNotNull('latitude')->whereNotNull('longitude')
            ->select('*')
            ->selectRaw("$haversine AS distance_km", [$data['latitude'], $data['longitude'], $data['latitude']])
            ->whereRaw("$haversine <= ?", [$data['latitude'], $data['longitude'], $data['latitude'], $radius])
            ->with(['images', 'category', 'city'])
            ->orderBy('distance_km')
            ->paginate(min($request->integer('per_page', 20), 50));

        $this->markFavorited($ads->getCollection(), $request);

        return ApiResponse::success(AdResource::collection($ads), 'Nearby ads.');
    }

    /**
     * Single ad by slug (increments views).
     */
    public function show(Request $request, string $slug): JsonResponse
    {
        $ad = Ad::query()
            ->where('slug', $slug)
            ->with(['images', 'category.customFields', 'city', 'state', 'country',
                'user.sellerProfile', 'fieldValues.customField'])
            ->firstOrFail();

        // Only owner/staff may view non-published ads (public route → sanctum guard).
        if ($ad->status !== 'approved') {
            $user = $request->user('sanctum');
            $isOwner = $user && $user->id === $ad->user_id;
            $isStaff = $user && $user->hasAnyRole(['admin', 'super-admin', 'staff']);
            abort_unless($isOwner || $isStaff, 404);
        } else {
            Ad::whereKey($ad->id)->increment('views_count');
        }

        $this->markFavorited(collect([$ad]), $request);

        return ApiResponse::success(new AdResource($ad), 'Ad.');
    }

    /**
     * Related ads (same category, excludes current).
     */
    public function related(string $slug): JsonResponse
    {
        $ad = Ad::where('slug', $slug)->firstOrFail();

        $related = Ad::query()->published()
            ->where('category_id', $ad->category_id)
            ->whereKeyNot($ad->id)
            ->with(['images', 'city'])
            ->latest('published_at')
            ->limit(10)->get();

        return ApiResponse::success(AdResource::collection($related), 'Related ads.');
    }

    /**
     * Create an ad (approval workflow applies).
     */
    public function store(StoreAdRequest $request): JsonResponse
    {
        $user = $request->user();
        $category = Category::findOrFail($request->integer('category_id'));

        $requireApproval = (bool) Setting::get('ads', 'require_approval', true);
        $isDraft = $request->input('status') === 'draft';

        // Enforce subscription quota when enabled (no-op otherwise).
        $subscription = $this->subscriptions->resolveForPosting($user, $category);

        $ad = DB::transaction(function () use ($request, $user, $category, $requireApproval, $isDraft, $subscription) {
            $ad = new Ad($this->baseAttributes($request));
            $ad->user_id = $user->id;
            $ad->category_id = $category->id;

            if ($isDraft) {
                $ad->status = 'draft';
            } elseif ($requireApproval) {
                $ad->status = 'pending';
            } else {
                $ad->status = 'approved';
                $ad->approved_at = now();
                $ad->published_at = now();
            }

            $ad->expires_at = now()->addDays((int) Setting::get('ads', 'default_expiry_days', 30));
            $ad->save();

            $this->fields->sync($ad, $category, (array) $request->input('custom_fields', []));

            // Consume quota only for non-draft posts.
            if (! $isDraft) {
                $this->subscriptions->consume($subscription);
            }

            return $ad;
        });

        // First-time posters become sellers.
        if (! $user->hasRole('seller')) {
            $user->assignRole('seller');
            $user->sellerProfile()->firstOrCreate([], ['member_since' => now()]);
        }

        return ApiResponse::success(
            new AdResource($ad->load(['images', 'category', 'fieldValues.customField'])),
            $ad->status === 'pending' ? 'Ad submitted for approval.' : 'Ad created.',
            201
        );
    }

    public function update(UpdateAdRequest $request, int $id): JsonResponse
    {
        $ad = Ad::findOrFail($id);
        $this->authorizeOwner($request, $ad);

        $category = $request->filled('category_id')
            ? Category::findOrFail($request->integer('category_id'))
            : $ad->category;

        DB::transaction(function () use ($request, $ad, $category) {
            $ad->fill($this->baseAttributes($request, partial: true));
            $ad->category_id = $category->id;

            // Edits re-enter moderation if approval is required.
            if ($ad->status === 'approved' && (bool) Setting::get('ads', 'require_approval', true)) {
                $ad->status = 'pending';
            }
            $ad->save();

            if ($request->has('custom_fields')) {
                $this->fields->sync($ad, $category, (array) $request->input('custom_fields', []));
            }
        });

        return ApiResponse::success(
            new AdResource($ad->fresh()->load(['images', 'category', 'fieldValues.customField'])),
            'Ad updated.'
        );
    }

    public function destroy(Request $request, int $id): JsonResponse
    {
        $ad = Ad::findOrFail($id);
        $this->authorizeOwner($request, $ad);
        $ad->delete();

        return ApiResponse::success(null, 'Ad deleted.');
    }

    /**
     * Authenticated user's own ads (all statuses).
     */
    public function myAds(Request $request): JsonResponse
    {
        $ads = Ad::query()
            ->where('user_id', $request->user()->id)
            ->when($request->filled('status'), fn ($q) => $q->where('status', $request->string('status')))
            ->with(['images', 'category'])
            ->latest()
            ->paginate(min($request->integer('per_page', 20), 50));

        return ApiResponse::success(AdResource::collection($ads), 'My ads.');
    }

    public function markSold(Request $request, int $id): JsonResponse
    {
        $ad = Ad::findOrFail($id);
        $this->authorizeOwner($request, $ad);
        $ad->update(['status' => 'sold', 'sold_at' => now()]);

        return ApiResponse::success(new AdResource($ad), 'Marked as sold.');
    }

    public function renew(Request $request, int $id): JsonResponse
    {
        $ad = Ad::findOrFail($id);
        $this->authorizeOwner($request, $ad);

        $days = (int) Setting::get('ads', 'default_expiry_days', 30);
        $requireApproval = (bool) Setting::get('ads', 'require_approval', true);

        $ad->update([
            'expires_at' => now()->addDays($days),
            'status'     => $requireApproval ? 'pending' : 'approved',
            'published_at' => $requireApproval ? $ad->published_at : now(),
        ]);

        return ApiResponse::success(new AdResource($ad), 'Ad renewed.');
    }

    // ----- helpers -----

    private function baseAttributes(Request $request, bool $partial = false): array
    {
        $attrs = $request->only([
            'title', 'description', 'currency_code', 'price_type', 'condition',
            'phone', 'video_url', 'country_id', 'state_id', 'city_id',
            'address', 'latitude', 'longitude',
        ]);

        // Convert major-unit price to minor units.
        if ($request->has('price')) {
            $attrs['price'] = $request->input('price') !== null
                ? (int) round((float) $request->input('price') * 100)
                : null;
        }

        return $partial ? array_filter($attrs, fn ($v) => $v !== null || true) : $attrs;
    }

    private function authorizeOwner(Request $request, Ad $ad): void
    {
        $user = $request->user();
        $isOwner = $user->id === $ad->user_id;
        $isStaff = $user->hasAnyRole(['admin', 'super-admin']);
        abort_unless($isOwner || $isStaff, 403, 'This action is unauthorized.');
    }

    /**
     * Annotate ads with is_favorited for the current user.
     */
    private function markFavorited($ads, Request $request): void
    {
        // These run on public routes too; resolve the optional viewer via sanctum.
        $user = $request->user('sanctum');
        if (! $user || $ads->isEmpty()) {
            return;
        }

        $favIds = $user->favorites()
            ->whereIn('ad_id', $ads->pluck('id'))
            ->pluck('ad_id')->flip();

        $ads->each(fn ($ad) => $ad->is_favorited = $favIds->has($ad->id));
    }
}

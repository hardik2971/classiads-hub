<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\TransactionResource;
use App\Models\PaymentGateway;
use App\Models\Transaction;
use App\Services\Billing\PaymentService;
use App\Services\Payments\PaymentManager;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class PaymentController extends Controller
{
    public function __construct(
        private readonly PaymentManager $payments,
        private readonly PaymentService $paymentService,
    ) {}

    /**
     * Confirm/capture a payment (sandbox + automatic gateways).
     * Manual gateways (bank transfer) must be confirmed by an admin.
     */
    public function confirm(Request $request, int $id): JsonResponse
    {
        $transaction = Transaction::findOrFail($id);
        abort_unless($transaction->user_id === $request->user()->id, 403);

        if ($transaction->isCompleted()) {
            return ApiResponse::success(new TransactionResource($transaction), 'Already completed.');
        }
        if ($transaction->status !== 'pending') {
            return ApiResponse::error('Transaction is not payable.', 422);
        }

        $gateway = PaymentGateway::where('code', $transaction->gateway)->first();
        if ($gateway && $gateway->is_manual) {
            return ApiResponse::error('This payment must be confirmed by an administrator.', 422);
        }

        $driver = $this->payments->resolve($transaction->gateway);

        if ($driver->confirm($transaction, $request->all())) {
            $transaction = $this->paymentService->fulfil($transaction);
            $msg = 'Payment successful.';
        } else {
            $transaction = $this->paymentService->fail($transaction);
            $msg = 'Payment failed.';
        }

        return ApiResponse::success(
            new TransactionResource($transaction->load(['invoice', 'package', 'ad'])),
            $msg
        );
    }

    public function show(Request $request, int $id): JsonResponse
    {
        $transaction = Transaction::with(['invoice', 'package', 'ad'])->findOrFail($id);
        abort_unless($transaction->user_id === $request->user()->id, 403);

        return ApiResponse::success(new TransactionResource($transaction), 'Transaction.');
    }
}

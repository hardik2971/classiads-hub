<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\SubscriptionResource;
use App\Http\Resources\TransactionResource;
use App\Models\Package;
use App\Services\Billing\CheckoutService;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;use RuntimeException;

class SubscriptionController extends Controller
{
    public function __construct(private readonly CheckoutService $checkout) {}

    /** Current user's subscriptions. */
    public function index(Request $request): JsonResponse
    {
        $subs = $request->user()->subscriptions()->with('package')->latest()->get();

        return ApiResponse::success(SubscriptionResource::collection($subs), 'Subscriptions.');
    }

    public function active(Request $request): JsonResponse
    {
        $sub = $request->user()->activeSubscription();

        return ApiResponse::success(
            $sub ? new SubscriptionResource($sub->load('package')) : null,
            $sub ? 'Active subscription.' : 'No active subscription.'
        );
    }

    /**
     * Start a subscription purchase. Returns the pending transaction + gateway action.
     */
    public function checkout(Request $request): JsonResponse
    {
        $data = $request->validate([
            'package_id' => ['required', 'integer', 'exists:packages,id'],
            'gateway'    => ['required', 'string', 'max:50'],
        ]);

        $package = Package::active()->findOrFail($data['package_id']);

        try {
            $result = $this->checkout->subscription($request->user(), $package, $data['gateway']);
        } catch (RuntimeException $e) {
            return ApiResponse::error($e->getMessage(), 422);
        }

        return ApiResponse::success([
            'transaction' => new TransactionResource($result['transaction']),
            'subscription' => new SubscriptionResource($result['subscription']),
            'payment'      => $result['payment'],
        ], 'Checkout started.', 201);
    }
}

<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\UserResource;
use App\Models\SocialAccount;
use App\Models\User;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Laravel\Socialite\Facades\Socialite;
use Laravel\Socialite\Two\InvalidStateException;
use Throwable;

class SocialAuthController extends Controller
{
    /** Providers we accept token sign-in for. */
    private const PROVIDERS = ['google', 'facebook'];

    /**
     * Sign in (or register) with a provider access token obtained client-side.
     *
     * POST /auth/social/{provider}  body: { access_token, device? }
     */
    public function callback(Request $request, string $provider): JsonResponse
    {
        $provider = strtolower($provider);

        if (! in_array($provider, self::PROVIDERS, true)) {
            return ApiResponse::error("Unsupported social provider [{$provider}].", 422);
        }

        $data = $request->validate([
            'access_token' => ['required', 'string'],
            'device'       => ['nullable', 'string', 'max:191'],
        ]);

        // Exchange the access token for the provider's user profile (stateless).
        try {
            $socialUser = Socialite::driver($provider)->stateless()->userFromToken($data['access_token']);
        } catch (InvalidStateException) {
            return ApiResponse::error('Invalid social token.', 401);
        } catch (Throwable) {
            return ApiResponse::error('Could not verify the social account. Check the access token.', 401);
        }

        $providerId = (string) $socialUser->getId();
        if ($providerId === '') {
            return ApiResponse::error('Social provider did not return an account id.', 422);
        }

        $email  = $socialUser->getEmail();
        $name   = $socialUser->getName() ?: $socialUser->getNickname() ?: 'User';
        $avatar = $socialUser->getAvatar();

        $user = DB::transaction(function () use ($provider, $providerId, $email, $name, $avatar): User {
            // 1) Already linked → that user.
            $link = SocialAccount::where('provider', $provider)
                ->where('provider_user_id', $providerId)
                ->first();

            if ($link) {
                $user = $link->user;
                $link->update(['avatar' => $avatar]);

                return $user;
            }

            // 2) Match an existing user by email → link the provider.
            $user = $email ? User::where('email', $email)->first() : null;

            // 3) Otherwise create a fresh verified account.
            if (! $user) {
                $user = User::create([
                    'name'              => $name,
                    'email'             => $email,
                    'password'          => null,
                    'status'            => 'active',
                    'is_verified'       => false,
                    'email_verified_at' => $email ? now() : null,
                    'avatar_path'       => $avatar,
                ]);
                $user->assignRole('customer');
            }

            $user->socialAccounts()->create([
                'provider'         => $provider,
                'provider_user_id' => $providerId,
                'avatar'           => $avatar,
            ]);

            return $user;
        });

        if (! $user->isActive()) {
            return ApiResponse::error('Your account is '.$user->status.'.', 403);
        }

        $user->forceFill(['last_login_at' => now()])->save();

        $token = $user->createToken($data['device'] ?? 'social')->plainTextToken;

        return ApiResponse::success([
            'user'  => new UserResource($user->load(['roles', 'sellerProfile'])),
            'token' => $token,
        ], 'Logged in with '.ucfirst($provider).'.');
    }
}

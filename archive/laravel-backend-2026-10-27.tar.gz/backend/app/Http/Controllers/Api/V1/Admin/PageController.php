<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Resources\PageResource;
use App\Models\Page;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class PageController extends Controller
{
    public function index(): JsonResponse
    {
        return ApiResponse::success(PageResource::collection(Page::all()), 'Pages.');
    }

    /** Create or update a CMS page by key. */
    public function upsert(Request $request): JsonResponse
    {
        $data = $request->validate([
            'key'          => ['required', 'string', 'max:64'],
            'title'        => ['required', 'string', 'max:191'],
            'body'         => ['nullable', 'string'],
            'is_published' => ['nullable', 'boolean'],
        ]);

        $page = Page::updateOrCreate(
            ['key' => $data['key']],
            ['title' => $data['title'], 'body' => $data['body'] ?? null, 'is_published' => $data['is_published'] ?? true]
        );

        return ApiResponse::success(new PageResource($page), 'Page saved.');
    }

    public function destroy(int $id): JsonResponse
    {
        Page::findOrFail($id)->delete();

        return ApiResponse::success(null, 'Page deleted.');
    }
}

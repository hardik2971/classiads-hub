<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\OfferResource;
use App\Models\Ad;
use App\Models\Conversation;
use App\Models\Offer;
use App\Models\User;
use App\Services\Notifications\NotificationService;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class OfferController extends Controller
{
    public function __construct(private readonly NotificationService $notifications) {}

    /**
     * Offers for the current user (made + received), optional ?ad_id=, ?role=buyer|seller.
     */
    public function index(Request $request): JsonResponse
    {
        $uid = $request->user()->id;

        $offers = Offer::query()
            ->when($request->filled('ad_id'), fn ($q) => $q->where('ad_id', $request->integer('ad_id')))
            ->when($request->string('role')->toString() === 'buyer', fn ($q) => $q->where('buyer_id', $uid))
            ->when($request->string('role')->toString() === 'seller', fn ($q) => $q->where('seller_id', $uid))
            ->when(! $request->filled('role'), fn ($q) => $q->where(fn ($q) => $q->where('buyer_id', $uid)->orWhere('seller_id', $uid)))
            ->with('ad.images')
            ->latest()
            ->paginate(min($request->integer('per_page', 20), 50));

        return ApiResponse::success(OfferResource::collection($offers), 'Offers.');
    }

    /**
     * Buyer makes an offer on an ad (creates/links a conversation + offer message).
     */
    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'ad_id'   => ['required', 'integer', 'exists:ads,id'],
            'amount'  => ['required', 'numeric', 'min:0', 'max:999999999'],
            'message' => ['nullable', 'string', 'max:500'],
        ]);

        $ad = Ad::findOrFail($data['ad_id']);
        $buyer = $request->user();

        if ($ad->user_id === $buyer->id) {
            return ApiResponse::error('You cannot make an offer on your own ad.', 422);
        }

        $offer = DB::transaction(function () use ($ad, $buyer, $data) {
            $conversation = Conversation::firstOrCreate(
                ['ad_id' => $ad->id, 'buyer_id' => $buyer->id, 'seller_id' => $ad->user_id]
            );

            $offer = Offer::create([
                'ad_id'           => $ad->id,
                'conversation_id' => $conversation->id,
                'buyer_id'        => $buyer->id,
                'seller_id'       => $ad->user_id,
                'amount'          => (int) round((float) $data['amount'] * 100),
                'currency_code'   => $ad->currency_code,
                'status'          => 'pending',
                'message'         => $data['message'] ?? null,
            ]);

            $this->systemOfferMessage($conversation, $buyer->id, $offer, $offer->amountDisplay().' offered');

            return $offer;
        });

        $this->notifySeller($offer, 'offer.received', 'New offer', $offer->amountDisplay().' on '.$ad->title);

        return ApiResponse::success(new OfferResource($offer->load('ad')), 'Offer sent.', 201);
    }

    public function accept(Request $request, int $id): JsonResponse
    {
        $offer = Offer::findOrFail($id);
        $this->authorizeSeller($request, $offer);
        $this->guardPending($offer);

        $offer->update(['status' => 'accepted']);
        $this->systemMessageToConversation($offer, 'Offer accepted: '.$offer->amountDisplay());
        $this->notifyBuyer($offer, 'offer.accepted', 'Offer accepted', 'Your offer '.$offer->amountDisplay().' was accepted.');

        return ApiResponse::success(new OfferResource($offer), 'Offer accepted.');
    }

    public function reject(Request $request, int $id): JsonResponse
    {
        $offer = Offer::findOrFail($id);
        $this->authorizeSeller($request, $offer);
        $this->guardPending($offer);

        $offer->update(['status' => 'rejected']);
        $this->systemMessageToConversation($offer, 'Offer rejected: '.$offer->amountDisplay());
        $this->notifyBuyer($offer, 'offer.rejected', 'Offer rejected', 'Your offer '.$offer->amountDisplay().' was rejected.');

        return ApiResponse::success(new OfferResource($offer), 'Offer rejected.');
    }

    /**
     * Counter an offer (seller or buyer). Creates a new linked offer.
     */
    public function counter(Request $request, int $id): JsonResponse
    {
        $data = $request->validate([
            'amount'  => ['required', 'numeric', 'min:0', 'max:999999999'],
            'message' => ['nullable', 'string', 'max:500'],
        ]);

        $parent = Offer::findOrFail($id);
        $uid = $request->user()->id;
        abort_unless(in_array($uid, [$parent->buyer_id, $parent->seller_id], true), 403);
        $this->guardPending($parent);

        $counter = DB::transaction(function () use ($parent, $data) {
            $parent->update(['status' => 'countered']);

            $counter = Offer::create([
                'ad_id'           => $parent->ad_id,
                'conversation_id' => $parent->conversation_id,
                'buyer_id'        => $parent->buyer_id,
                'seller_id'       => $parent->seller_id,
                'parent_offer_id' => $parent->id,
                'amount'          => (int) round((float) $data['amount'] * 100),
                'currency_code'   => $parent->currency_code,
                'status'          => 'pending',
                'message'         => $data['message'] ?? null,
            ]);

            if ($parent->conversation_id) {
                $conversation = Conversation::find($parent->conversation_id);
                $this->systemOfferMessage($conversation, request()->user()->id, $counter, 'Counter offer: '.$counter->amountDisplay());
            }

            return $counter;
        });

        // Notify the other party.
        $recipientId = $uid === $parent->buyer_id ? $parent->seller_id : $parent->buyer_id;
        if ($recipient = User::find($recipientId)) {
            $this->notifications->notify($recipient, 'offer.countered', 'Counter offer', $counter->amountDisplay(),
                ['offer_id' => $counter->id, 'ad_id' => $counter->ad_id]);
        }

        return ApiResponse::success(new OfferResource($counter), 'Counter offer sent.', 201);
    }

    public function withdraw(Request $request, int $id): JsonResponse
    {
        $offer = Offer::findOrFail($id);
        abort_unless($offer->buyer_id === $request->user()->id, 403);
        $this->guardPending($offer);

        $offer->update(['status' => 'withdrawn']);

        return ApiResponse::success(new OfferResource($offer), 'Offer withdrawn.');
    }

    // ----- helpers -----

    private function guardPending(Offer $offer): void
    {
        abort_if($offer->status !== 'pending', 422, 'This offer is no longer pending.');
    }

    private function authorizeSeller(Request $request, Offer $offer): void
    {
        abort_unless($offer->seller_id === $request->user()->id, 403, 'Only the seller can do this.');
    }

    private function systemOfferMessage(?Conversation $conversation, int $senderId, Offer $offer, string $text): void
    {
        if (! $conversation) {
            return;
        }
        $conversation->messages()->create([
            'sender_id' => $senderId,
            'body'      => $text,
            'type'      => 'offer',
            'offer_id'  => $offer->id,
        ]);
        $conversation->update(['last_message' => $text, 'last_message_at' => now()]);
    }

    private function systemMessageToConversation(Offer $offer, string $text): void
    {
        if (! $offer->conversation_id) {
            return;
        }
        $conversation = Conversation::find($offer->conversation_id);
        $conversation?->messages()->create([
            'sender_id' => $offer->seller_id,
            'body'      => $text,
            'type'      => 'system',
            'offer_id'  => $offer->id,
        ]);
        $conversation?->update(['last_message' => $text, 'last_message_at' => now()]);
    }

    private function notifySeller(Offer $offer, string $type, string $title, string $body): void
    {
        if ($seller = User::find($offer->seller_id)) {
            $this->notifications->notify($seller, $type, $title, $body, ['offer_id' => $offer->id, 'ad_id' => $offer->ad_id]);
        }
    }

    private function notifyBuyer(Offer $offer, string $type, string $title, string $body): void
    {
        if ($buyer = User::find($offer->buyer_id)) {
            $this->notifications->notify($buyer, $type, $title, $body, ['offer_id' => $offer->id, 'ad_id' => $offer->ad_id]);
        }
    }
}

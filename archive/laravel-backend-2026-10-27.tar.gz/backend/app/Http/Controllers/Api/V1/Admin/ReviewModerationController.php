<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Resources\ReviewResource;
use App\Models\Review;
use App\Models\User;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ReviewModerationController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $reviews = Review::with(['reviewer', 'reviewee', 'ad'])
            ->when($request->filled('type'), fn ($q) => $q->where('type', $request->string('type')))
            ->when($request->filled('approved'), fn ($q) => $q->where('is_approved', $request->boolean('approved')))
            ->latest()
            ->paginate(min($request->integer('per_page', 20), 50));

        return ApiResponse::success(ReviewResource::collection($reviews), 'Reviews.');
    }

    public function setApproval(Request $request, int $id): JsonResponse
    {
        $data = $request->validate(['is_approved' => ['required', 'boolean']]);

        $review = Review::findOrFail($id);
        $review->update(['is_approved' => $data['is_approved']]);

        if ($review->type === 'seller_review') {
            $this->recomputeSellerRating($review->reviewee_id);
        }

        return ApiResponse::success(new ReviewResource($review), 'Review updated.');
    }

    public function destroy(int $id): JsonResponse
    {
        $review = Review::findOrFail($id);
        $revieweeId = $review->reviewee_id;
        $type = $review->type;
        $review->delete();

        if ($type === 'seller_review') {
            $this->recomputeSellerRating($revieweeId);
        }

        return ApiResponse::success(null, 'Review deleted.');
    }

    private function recomputeSellerRating(int $sellerId): void
    {
        $agg = Review::where('is_approved', true)->where('reviewee_id', $sellerId)
            ->where('type', 'seller_review')
            ->selectRaw('AVG(rating) avg, COUNT(*) cnt')->first();

        User::find($sellerId)?->sellerProfile()->updateOrCreate([], [
            'rating_avg'   => round((float) ($agg->avg ?? 0), 2),
            'rating_count' => (int) ($agg->cnt ?? 0),
        ]);
    }
}

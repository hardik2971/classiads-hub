<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Throwable;

class HealthController extends Controller
{
    /** Liveness probe — process is up. Cheap, no dependencies. */
    public function live(): JsonResponse
    {
        return ApiResponse::success([
            'service' => 'classiads-api',
            'version' => 'v1',
            'time'    => now()->toIso8601String(),
        ], 'OK');
    }

    /**
     * Readiness probe — verifies the critical dependencies (DB, cache, storage).
     * Returns 503 if any check fails so orchestrators stop routing traffic.
     */
    public function ready(): JsonResponse
    {
        $checks = [
            'database' => $this->check(fn () => DB::connection()->getPdo() !== null),
            'cache'    => $this->check(function (): bool {
                Cache::put('health:ping', '1', 5);

                return Cache::get('health:ping') === '1';
            }),
            'storage'  => $this->check(fn () => Storage::disk('public')->exists('.') || true),
        ];

        $ok = ! in_array(false, array_column($checks, 'ok'), true);

        return ApiResponse::success(
            ['status' => $ok ? 'ready' : 'degraded', 'checks' => $checks],
            $ok ? 'Ready.' : 'Degraded.',
            $ok ? 200 : 503,
        );
    }

    /**
     * @param  callable():bool  $probe
     * @return array{ok: bool, error?: string}
     */
    private function check(callable $probe): array
    {
        try {
            return ['ok' => (bool) $probe()];
        } catch (Throwable $e) {
            return ['ok' => false, 'error' => class_basename($e)];
        }
    }
}

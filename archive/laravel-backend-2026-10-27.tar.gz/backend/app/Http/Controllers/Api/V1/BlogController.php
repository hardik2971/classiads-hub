<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\BlogCategoryResource;
use App\Http\Resources\BlogPostResource;
use App\Models\BlogCategory;
use App\Models\BlogPost;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class BlogController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $posts = BlogPost::query()->published()
            ->with(['category', 'author'])
            ->when($request->filled('category'), fn ($q) => $q->whereHas('category', fn ($c) => $c->where('slug', $request->string('category'))))
            ->when($request->filled('q'), fn ($q) => $q->where('title', 'like', '%'.$request->string('q').'%'))
            ->latest('published_at')
            ->paginate(min($request->integer('per_page', 12), 50));

        return ApiResponse::success(BlogPostResource::collection($posts), 'Blog posts.');
    }

    public function show(string $slug): JsonResponse
    {
        $post = BlogPost::published()->where('slug', $slug)->with(['category', 'author', 'seo'])->firstOrFail();
        BlogPost::whereKey($post->id)->increment('views_count');

        return ApiResponse::success(new BlogPostResource($post), 'Blog post.');
    }

    public function categories(): JsonResponse
    {
        $cats = BlogCategory::active()->withCount(['posts' => fn ($q) => $q->published()])->orderBy('sort_order')->get();

        return ApiResponse::success(BlogCategoryResource::collection($cats), 'Blog categories.');
    }
}

<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\AdResource;
use App\Http\Resources\CategoryResource;
use App\Http\Resources\FeaturedSectionResource;
use App\Http\Resources\SliderResource;
use App\Models\Category;
use App\Models\FeaturedSection;
use App\Models\Slider;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;

class HomeController extends Controller
{
    public function sliders(): JsonResponse
    {
        $sliders = Slider::active()->with(['ad', 'category'])->orderBy('sort_order')->get();

        return ApiResponse::success(SliderResource::collection($sliders), 'Sliders.');
    }

    public function featuredSections(): JsonResponse
    {
        $sections = FeaturedSection::active()->orderBy('sort_order')->get();

        // Attach resolved ads to each section for the resource.
        $sections->each(fn ($s) => $s->setRelation('resolvedAds', $s->resolveAds()));

        return ApiResponse::success(FeaturedSectionResource::collection($sections), 'Featured sections.');
    }

    /**
     * Aggregated home payload for mobile/web first paint.
     */
    public function home(): JsonResponse
    {
        $sliders  = Slider::active()->with(['ad', 'category'])->orderBy('sort_order')->get();
        $categories = Category::active()->roots()->orderBy('sort_order')->get();
        $sections = FeaturedSection::active()->orderBy('sort_order')->get();
        $sections->each(fn ($s) => $s->setRelation('resolvedAds', $s->resolveAds()));

        return ApiResponse::success([
            'sliders'          => SliderResource::collection($sliders),
            'categories'       => CategoryResource::collection($categories),
            'featured_sections' => FeaturedSectionResource::collection($sections),
        ], 'Home.');
    }
}

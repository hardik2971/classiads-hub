<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\CategoryResource;
use App\Models\Category;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;

class CategoryController extends Controller
{
    /**
     * Flat list of categories (optionally filter by parent_id).
     */
    public function index(Request $request): JsonResponse
    {
        $query = Category::query()->active()->orderBy('sort_order');

        if ($request->filled('parent_id')) {
            $query->where('parent_id', $request->integer('parent_id'));
        } elseif ($request->boolean('roots_only')) {
            $query->roots();
        }

        return ApiResponse::success(
            CategoryResource::collection($query->get()),
            'Categories.'
        );
    }

    /**
     * Nested category tree (roots → children).
     */
    public function tree(): JsonResponse
    {
        // Cached; busted by the Category model on save/delete.
        $roots = Cache::remember('categories.tree', now()->addHours(6), fn () => Category::query()
            ->active()->roots()
            ->with(['children' => fn ($q) => $q->active()])
            ->orderBy('sort_order')
            ->get());

        return ApiResponse::success(CategoryResource::collection($roots), 'Category tree.');
    }

    /**
     * Single category by slug, with its custom fields + options.
     */
    public function show(string $slug): JsonResponse
    {
        $category = Category::query()->active()
            ->where('slug', $slug)
            ->with(['children' => fn ($q) => $q->active(), 'customFields.options'])
            ->firstOrFail();

        return ApiResponse::success(new CategoryResource($category), 'Category.');
    }

    /**
     * Custom fields applicable to a category (drives the Post-Ad form).
     */
    public function customFields(int $id): JsonResponse
    {
        $category = Category::with(['customFields.options'])->findOrFail($id);

        return ApiResponse::success(
            \App\Http\Resources\CustomFieldResource::collection($category->customFields),
            'Custom fields.'
        );
    }
}

<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Transaction;
use App\Services\Billing\PaymentService;
use App\Services\Payments\PaymentManager;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * Public gateway webhook receiver. Each driver verifies + normalizes its own
 * payload; this controller maps the result to fulfilment.
 */
class PaymentWebhookController extends Controller
{
    public function __construct(
        private readonly PaymentManager $payments,
        private readonly PaymentService $paymentService,
    ) {}

    public function handle(Request $request, string $gateway): JsonResponse
    {
        try {
            $driver = $this->payments->resolve($gateway);
        } catch (\Throwable $e) {
            return ApiResponse::error('Unknown gateway.', 404);
        }

        $result = $driver->parseWebhook($request);
        if (! $result) {
            return ApiResponse::error('Unhandled webhook.', 422);
        }

        $transaction = Transaction::query()
            ->when($result['transaction_id'] ?? null, fn ($q, $v) => $q->whereKey($v))
            ->when($result['gateway_reference'] ?? null, fn ($q, $v) => $q->orWhere('gateway_reference', $v))
            ->first();

        if (! $transaction) {
            return ApiResponse::error('Transaction not found.', 404);
        }

        if (($result['status'] ?? null) === 'completed') {
            $this->paymentService->fulfil($transaction);
        } elseif (($result['status'] ?? null) === 'failed') {
            $this->paymentService->fail($transaction);
        }

        return ApiResponse::success(['status' => $transaction->fresh()->status], 'Webhook processed.');
    }
}

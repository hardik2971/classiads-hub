<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Models\EmailTemplate;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class EmailTemplateController extends Controller
{
    public function index(): JsonResponse
    {
        return ApiResponse::success(EmailTemplate::orderBy('code')->get(), 'Email templates.');
    }

    public function upsert(Request $request): JsonResponse
    {
        $data = $request->validate([
            'code'      => ['required', 'string', 'max:100'],
            'subject'   => ['required', 'string', 'max:191'],
            'body_html' => ['required', 'string'],
            'variables' => ['nullable', 'array'],
            'is_active' => ['nullable', 'boolean'],
        ]);

        $tpl = EmailTemplate::updateOrCreate(
            ['code' => $data['code']],
            collect($data)->except('code')->toArray()
        );

        return ApiResponse::success($tpl, 'Template saved.');
    }

    public function destroy(int $id): JsonResponse
    {
        EmailTemplate::findOrFail($id)->delete();

        return ApiResponse::success(null, 'Template deleted.');
    }
}

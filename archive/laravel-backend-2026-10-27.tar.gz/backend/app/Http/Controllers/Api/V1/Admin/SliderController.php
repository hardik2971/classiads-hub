<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Resources\SliderResource;
use App\Models\Slider;
use App\Services\Media\MediaService;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class SliderController extends Controller
{
    public function __construct(private readonly MediaService $media) {}

    public function index(): JsonResponse
    {
        return ApiResponse::success(
            SliderResource::collection(Slider::orderBy('sort_order')->get()),
            'Sliders.'
        );
    }

    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'image'        => ['required', 'image', 'mimes:jpg,jpeg,png,webp', 'max:5120'],
            'link_type'    => ['nullable', Rule::in(['none', 'ad', 'category', 'external'])],
            'ad_id'        => ['nullable', 'integer', 'exists:ads,id'],
            'category_id'  => ['nullable', 'integer', 'exists:categories,id'],
            'external_url' => ['nullable', 'url', 'max:255'],
            'title'        => ['nullable', 'string', 'max:150'],
            'sort_order'   => ['nullable', 'integer'],
            'is_active'    => ['nullable', 'boolean'],
        ]);

        $data['image_path'] = $this->media->storeImage($request->file('image'), 'sliders');
        unset($data['image']);

        $slider = Slider::create($data);

        return ApiResponse::success(new SliderResource($slider), 'Slider created.', 201);
    }

    public function update(Request $request, int $id): JsonResponse
    {
        $slider = Slider::findOrFail($id);

        $data = $request->validate([
            'image'        => ['sometimes', 'image', 'mimes:jpg,jpeg,png,webp', 'max:5120'],
            'link_type'    => ['sometimes', Rule::in(['none', 'ad', 'category', 'external'])],
            'ad_id'        => ['nullable', 'integer', 'exists:ads,id'],
            'category_id'  => ['nullable', 'integer', 'exists:categories,id'],
            'external_url' => ['nullable', 'url', 'max:255'],
            'title'        => ['nullable', 'string', 'max:150'],
            'sort_order'   => ['nullable', 'integer'],
            'is_active'    => ['nullable', 'boolean'],
        ]);

        if ($request->hasFile('image')) {
            $data['image_path'] = $this->media->storeImage($request->file('image'), 'sliders');
        }
        unset($data['image']);

        $slider->update($data);

        return ApiResponse::success(new SliderResource($slider), 'Slider updated.');
    }

    public function destroy(int $id): JsonResponse
    {
        Slider::findOrFail($id)->delete();

        return ApiResponse::success(null, 'Slider deleted.');
    }
}

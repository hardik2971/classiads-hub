<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Resources\AdResource;
use App\Models\Ad;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class AdModerationController extends Controller
{
    /**
     * List ads for moderation, filterable by status / featured / location.
     */
    public function index(Request $request): JsonResponse
    {
        $ads = Ad::query()
            ->when($request->filled('status'), fn ($q) => $q->where('status', $request->string('status')), fn ($q) => $q->where('status', 'pending'))
            ->when($request->filled('featured'), fn ($q) => $q->where('is_featured', $request->boolean('featured')))
            ->when($request->filled('country_id'), fn ($q) => $q->where('country_id', $request->integer('country_id')))
            ->when($request->filled('city_id'), fn ($q) => $q->where('city_id', $request->integer('city_id')))
            ->when($request->filled('q'), fn ($q) => $q->where('title', 'like', '%'.$request->string('q').'%'))
            ->with(['images', 'category', 'user', 'city', 'country'])
            ->latest()
            ->paginate(min($request->integer('per_page', 20), 50));

        return ApiResponse::success(AdResource::collection($ads), 'Ads for moderation.');
    }

    public function approve(int $id): JsonResponse
    {
        $ad = Ad::findOrFail($id);
        $ad->update([
            'status'           => 'approved',
            'approved_at'      => now(),
            'published_at'     => $ad->published_at ?? now(),
            'rejection_reason' => null,
        ]);

        return ApiResponse::success(new AdResource($ad), 'Ad approved.');
    }

    public function reject(Request $request, int $id): JsonResponse
    {
        $data = $request->validate(['reason' => ['required', 'string', 'max:255']]);

        $ad = Ad::findOrFail($id);
        $ad->update(['status' => 'rejected', 'rejection_reason' => $data['reason']]);

        return ApiResponse::success(new AdResource($ad), 'Ad rejected.');
    }

    /**
     * Toggle featured/premium flag.
     */
    public function toggleFeatured(Request $request, int $id): JsonResponse
    {
        $ad = Ad::findOrFail($id);
        $featured = ! $ad->is_featured;
        $ad->update([
            'is_featured'    => $featured,
            'featured_until' => $featured ? now()->addDays($request->integer('days', 30)) : null,
        ]);

        return ApiResponse::success(new AdResource($ad), $featured ? 'Ad featured.' : 'Feature removed.');
    }

    public function destroy(int $id): JsonResponse
    {
        Ad::findOrFail($id)->delete();

        return ApiResponse::success(null, 'Ad removed.');
    }
}

<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Models\FeaturedSection;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class FeaturedSectionController extends Controller
{
    public function index(): JsonResponse
    {
        return ApiResponse::success(
            FeaturedSection::orderBy('sort_order')->get(),
            'Featured sections.'
        );
    }

    public function store(Request $request): JsonResponse
    {
        $data = $this->validateData($request);
        $section = FeaturedSection::create($data);

        return ApiResponse::success($section, 'Featured section created.', 201);
    }

    public function update(Request $request, int $id): JsonResponse
    {
        $section = FeaturedSection::findOrFail($id);
        $section->update($this->validateData($request, partial: true));

        return ApiResponse::success($section, 'Featured section updated.');
    }

    public function destroy(int $id): JsonResponse
    {
        FeaturedSection::findOrFail($id)->delete();

        return ApiResponse::success(null, 'Featured section deleted.');
    }

    private function validateData(Request $request, bool $partial = false): array
    {
        $req = $partial ? 'sometimes' : 'required';

        return $request->validate([
            'title'       => [$req, 'string', 'max:150'],
            'filter_type' => [$req, Rule::in(['latest', 'most_viewed', 'most_liked', 'featured', 'category'])],
            'category_id' => ['nullable', 'integer', 'exists:categories,id'],
            'style'       => ['nullable', 'string', 'max:50'],
            'item_limit'  => ['nullable', 'integer', 'min:1', 'max:50'],
            'sort_order'  => ['nullable', 'integer'],
            'is_active'   => ['nullable', 'boolean'],
        ]);
    }
}

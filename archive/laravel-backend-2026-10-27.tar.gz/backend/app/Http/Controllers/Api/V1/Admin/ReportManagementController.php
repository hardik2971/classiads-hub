<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Resources\ReportResource;
use App\Models\Report;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class ReportManagementController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $reports = Report::with(['reporter', 'reportable'])
            ->when($request->filled('status'), fn ($q) => $q->where('status', $request->string('status')), fn ($q) => $q->where('status', 'open'))
            ->when($request->filled('type'), fn ($q) => $q->where('reportable_type', 'App\\Models\\'.ucfirst($request->string('type'))))
            ->latest()
            ->paginate(min($request->integer('per_page', 20), 50));

        return ApiResponse::success(ReportResource::collection($reports), 'Reports.');
    }

    public function updateStatus(Request $request, int $id): JsonResponse
    {
        $data = $request->validate([
            'status' => ['required', Rule::in(['open', 'reviewing', 'resolved', 'dismissed'])],
        ]);

        $report = Report::findOrFail($id);
        $report->update([
            'status'      => $data['status'],
            'resolved_by' => in_array($data['status'], ['resolved', 'dismissed'], true) ? $request->user()->id : null,
            'resolved_at' => in_array($data['status'], ['resolved', 'dismissed'], true) ? now() : null,
        ]);

        return ApiResponse::success(new ReportResource($report->load('reporter')), 'Report updated.');
    }
}

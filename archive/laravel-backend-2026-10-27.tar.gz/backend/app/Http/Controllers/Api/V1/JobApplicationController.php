<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\JobApplicationResource;
use App\Models\JobListing;
use App\Services\Notifications\NotificationService;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class JobApplicationController extends Controller
{
    public function __construct(private readonly NotificationService $notifications) {}

    /** Apply to a job. */
    public function store(Request $request, int $jobId): JsonResponse
    {
        $job = JobListing::open()->findOrFail($jobId);
        $user = $request->user();

        if ($job->user_id === $user->id) {
            return ApiResponse::error('You cannot apply to your own job listing.', 422);
        }
        if ($job->applications()->where('user_id', $user->id)->exists()) {
            return ApiResponse::error('You have already applied to this job.', 422);
        }

        $data = $request->validate([
            'cover_letter' => ['nullable', 'string', 'max:5000'],
            'resume_path'  => ['nullable', 'string', 'max:255'],
        ]);

        $app = DB::transaction(function () use ($job, $user, $data) {
            $app = $job->applications()->create([
                'user_id'      => $user->id,
                'cover_letter' => $data['cover_letter'] ?? null,
                'resume_path'  => $data['resume_path'] ?? null,
            ]);
            $job->increment('applications_count');

            return $app;
        });

        $this->notifications->notify(
            $job->employer, 'job.application', 'New job application',
            $user->name.' applied to "'.$job->title.'".',
            ['job_id' => $job->id, 'application_id' => $app->id]
        );

        return ApiResponse::success(new JobApplicationResource($app), 'Application submitted.', 201);
    }

    /** Applications the current user has submitted. */
    public function mine(Request $request): JsonResponse
    {
        $apps = \App\Models\JobApplication::where('user_id', $request->user()->id)
            ->with('jobListing')
            ->latest()
            ->paginate(min($request->integer('per_page', 20), 50));

        return ApiResponse::success(JobApplicationResource::collection($apps), 'My applications.');
    }
}

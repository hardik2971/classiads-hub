<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Ad;
use App\Models\Report;
use App\Models\User;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class ReportController extends Controller
{
    /**
     * Report an ad or a user.
     */
    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'type'    => ['required', Rule::in(['ad', 'user'])],
            'id'      => ['required', 'integer'],
            'reason'  => ['required', 'string', 'max:150'],
            'details' => ['nullable', 'string', 'max:2000'],
        ]);

        $model = $data['type'] === 'ad'
            ? Ad::findOrFail($data['id'])
            : User::findOrFail($data['id']);

        // Prevent duplicate open reports by the same user on the same target.
        $report = Report::firstOrCreate(
            [
                'reporter_id'     => $request->user()->id,
                'reportable_type' => $model::class,
                'reportable_id'   => $model->id,
                'status'          => 'open',
            ],
            ['reason' => $data['reason'], 'details' => $data['details'] ?? null]
        );

        return ApiResponse::success(['report_id' => $report->id], 'Report submitted. Thank you.', 201);
    }
}

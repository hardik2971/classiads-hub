<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\UserResource;
use App\Models\User;
use App\Services\Notifications\NotificationService;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class FollowController extends Controller
{
    public function __construct(private readonly NotificationService $notifications) {}

    /**
     * Toggle following a seller.
     */
    public function toggle(Request $request, int $userId): JsonResponse
    {
        $target = User::findOrFail($userId);
        $me = $request->user();

        if ($target->id === $me->id) {
            return ApiResponse::error('You cannot follow yourself.', 422);
        }

        $following = $me->following()->wherePivot('following_id', $target->id)->exists();

        if ($following) {
            $me->following()->detach($target->id);
            $state = false;
        } else {
            $me->following()->attach($target->id);
            $state = true;
            $this->notifications->notify($target, 'follow.new', 'New follower',
                $me->name.' started following you.', ['user_id' => $me->id]);
        }

        return ApiResponse::success(
            ['user_id' => $target->id, 'following' => $state],
            $state ? 'Now following.' : 'Unfollowed.'
        );
    }

    public function following(Request $request): JsonResponse
    {
        $users = $request->user()->following()->paginate(min($request->integer('per_page', 20), 50));

        return ApiResponse::success(UserResource::collection($users), 'Following.');
    }

    public function followers(Request $request): JsonResponse
    {
        $users = $request->user()->followers()->paginate(min($request->integer('per_page', 20), 50));

        return ApiResponse::success(UserResource::collection($users), 'Followers.');
    }
}

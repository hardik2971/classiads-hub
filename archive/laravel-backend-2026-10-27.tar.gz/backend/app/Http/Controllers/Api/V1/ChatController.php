<?php

namespace App\Http\Controllers\Api\V1;

use App\Events\MessageSent;
use App\Http\Controllers\Controller;
use App\Http\Resources\ConversationResource;
use App\Http\Resources\MessageResource;
use App\Models\Ad;
use App\Models\Conversation;
use App\Services\Notifications\NotificationService;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ChatController extends Controller
{
    public function __construct(private readonly NotificationService $notifications) {}

    /**
     * Conversation list. ?tab=selling|buying (default both).
     */
    public function index(Request $request): JsonResponse
    {
        $uid = $request->user()->id;
        $tab = $request->string('tab')->toString();

        $conversations = Conversation::query()
            ->when($tab === 'selling', fn ($q) => $q->where('seller_id', $uid))
            ->when($tab === 'buying', fn ($q) => $q->where('buyer_id', $uid))
            ->when(! in_array($tab, ['selling', 'buying'], true),
                fn ($q) => $q->where(fn ($q) => $q->where('buyer_id', $uid)->orWhere('seller_id', $uid)))
            ->with(['ad.images', 'buyer', 'seller'])
            ->orderByDesc('last_message_at')
            ->paginate(min($request->integer('per_page', 20), 50));

        return ApiResponse::success(ConversationResource::collection($conversations), 'Conversations.');
    }

    /**
     * Start (or fetch) a conversation about an ad. Buyer-initiated.
     */
    public function start(Request $request): JsonResponse
    {
        $data = $request->validate([
            'ad_id'   => ['required', 'integer', 'exists:ads,id'],
            'message' => ['nullable', 'string', 'max:5000'],
        ]);

        $ad = Ad::findOrFail($data['ad_id']);
        $buyer = $request->user();

        if ($ad->user_id === $buyer->id) {
            return ApiResponse::error('You cannot start a conversation on your own ad.', 422);
        }

        $conversation = Conversation::firstOrCreate(
            ['ad_id' => $ad->id, 'buyer_id' => $buyer->id, 'seller_id' => $ad->user_id],
        );

        if (! empty($data['message'])) {
            $this->persistMessage($conversation, $buyer->id, $data['message']);
        }

        return ApiResponse::success(
            new ConversationResource($conversation->load(['ad.images', 'buyer', 'seller'])),
            'Conversation ready.',
            201
        );
    }

    /**
     * Show a conversation with paginated messages; marks read for the viewer.
     */
    public function show(Request $request, int $id): JsonResponse
    {
        $conversation = Conversation::with(['ad.images', 'buyer', 'seller'])->findOrFail($id);
        $this->authorizeParticipant($request, $conversation);

        $messages = $conversation->messages()
            ->with('offer')
            ->orderByDesc('id')
            ->paginate(min($request->integer('per_page', 30), 100));

        $this->markRead($request, $conversation);

        return ApiResponse::success([
            'conversation' => new ConversationResource($conversation),
            'messages'     => MessageResource::collection($messages),
        ], 'Conversation.');
    }

    public function sendMessage(Request $request, int $id): JsonResponse
    {
        $data = $request->validate(['body' => ['required', 'string', 'max:5000']]);

        $conversation = Conversation::findOrFail($id);
        $this->authorizeParticipant($request, $conversation);

        $message = $this->persistMessage($conversation, $request->user()->id, $data['body']);

        return ApiResponse::success(
            new MessageResource($message),
            'Message sent.',
            201
        );
    }

    public function markReadEndpoint(Request $request, int $id): JsonResponse
    {
        $conversation = Conversation::findOrFail($id);
        $this->authorizeParticipant($request, $conversation);
        $this->markRead($request, $conversation);

        return ApiResponse::success(null, 'Marked as read.');
    }

    // ----- helpers -----

    private function persistMessage(Conversation $conversation, int $senderId, string $body)
    {
        $message = DB::transaction(function () use ($conversation, $senderId, $body) {
            $message = $conversation->messages()->create([
                'sender_id' => $senderId,
                'body'      => $body,
                'type'      => 'text',
            ]);

            $isBuyer = $senderId === $conversation->buyer_id;
            $conversation->update([
                'last_message'    => mb_strimwidth($body, 0, 140, '…'),
                'last_message_at' => now(),
                'buyer_unread'    => $isBuyer ? $conversation->buyer_unread : $conversation->buyer_unread + 1,
                'seller_unread'   => $isBuyer ? $conversation->seller_unread + 1 : $conversation->seller_unread,
            ]);

            return $message;
        });

        // Realtime (safe: never break the send if broadcasting misconfigured).
        try {
            broadcast(new MessageSent($message))->toOthers();
        } catch (\Throwable $e) {
            report($e);
        }

        // Notify the recipient.
        $recipientId = $conversation->counterpartId($senderId);
        $recipient = \App\Models\User::find($recipientId);
        if ($recipient) {
            $this->notifications->notify(
                $recipient,
                'chat.message',
                'New message',
                mb_strimwidth($body, 0, 80, '…'),
                ['conversation_id' => $conversation->id, 'ad_id' => $conversation->ad_id]
            );
        }

        return $message->load('offer');
    }

    private function markRead(Request $request, Conversation $conversation): void
    {
        $uid = $request->user()->id;
        $field = $conversation->buyer_id === $uid ? 'buyer_unread' : 'seller_unread';

        $conversation->update([$field => 0]);
        $conversation->messages()
            ->where('sender_id', '!=', $uid)
            ->whereNull('read_at')
            ->update(['read_at' => now()]);
    }

    private function authorizeParticipant(Request $request, Conversation $conversation): void
    {
        abort_unless($conversation->hasParticipant($request->user()->id), 403, 'Not a participant.');
    }
}

<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Resources\ConversationResource;
use App\Http\Resources\MessageResource;
use App\Models\Conversation;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ChatModerationController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $conversations = Conversation::with(['ad', 'buyer', 'seller'])
            ->when($request->filled('ad_id'), fn ($q) => $q->where('ad_id', $request->integer('ad_id')))
            ->orderByDesc('last_message_at')
            ->paginate(min($request->integer('per_page', 20), 50));

        return ApiResponse::success(ConversationResource::collection($conversations), 'Conversations.');
    }

    public function show(int $id): JsonResponse
    {
        $conversation = Conversation::with(['ad', 'buyer', 'seller'])->findOrFail($id);
        $messages = $conversation->messages()->with('offer')->orderBy('id')->paginate(50);

        return ApiResponse::success([
            'conversation' => new ConversationResource($conversation),
            'messages'     => MessageResource::collection($messages),
        ], 'Conversation.');
    }

    public function destroy(int $id): JsonResponse
    {
        Conversation::findOrFail($id)->delete();

        return ApiResponse::success(null, 'Conversation deleted.');
    }
}

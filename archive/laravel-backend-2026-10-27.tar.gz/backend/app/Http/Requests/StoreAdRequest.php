<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreAdRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user() !== null;
    }

    public function rules(): array
    {
        return [
            'category_id'  => ['required', 'integer', 'exists:categories,id'],
            'title'        => ['required', 'string', 'min:3', 'max:191'],
            'description'  => ['required', 'string', 'min:10'],
            'price'        => ['nullable', 'numeric', 'min:0', 'max:999999999'],
            'currency_code' => ['nullable', 'string', 'size:3'],
            'price_type'   => ['nullable', Rule::in(['fixed', 'negotiable', 'free', 'contact'])],
            'condition'    => ['nullable', Rule::in(['new', 'used', 'refurbished'])],
            'phone'        => ['nullable', 'string', 'max:32'],
            'video_url'    => ['nullable', 'url', 'max:255'],

            'country_id'   => ['nullable', 'integer', 'exists:countries,id'],
            'state_id'     => ['nullable', 'integer', 'exists:states,id'],
            'city_id'      => ['nullable', 'integer', 'exists:cities,id'],
            'address'      => ['nullable', 'string', 'max:255'],
            'latitude'     => ['nullable', 'numeric', 'between:-90,90'],
            'longitude'    => ['nullable', 'numeric', 'between:-180,180'],

            // custom fields: { code: value, ... }
            'custom_fields'   => ['nullable', 'array'],
            'custom_fields.*' => ['nullable'],

            'status'       => ['nullable', Rule::in(['draft', 'pending'])],
        ];
    }
}

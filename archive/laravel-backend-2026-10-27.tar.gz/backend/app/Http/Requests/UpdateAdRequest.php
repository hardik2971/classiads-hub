<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateAdRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user() !== null;
    }

    public function rules(): array
    {
        return [
            'category_id'   => ['sometimes', 'integer', 'exists:categories,id'],
            'title'         => ['sometimes', 'string', 'min:3', 'max:191'],
            'description'   => ['sometimes', 'string', 'min:10'],
            'price'         => ['sometimes', 'nullable', 'numeric', 'min:0', 'max:999999999'],
            'currency_code' => ['sometimes', 'string', 'size:3'],
            'price_type'    => ['sometimes', Rule::in(['fixed', 'negotiable', 'free', 'contact'])],
            'condition'     => ['sometimes', 'nullable', Rule::in(['new', 'used', 'refurbished'])],
            'phone'         => ['sometimes', 'nullable', 'string', 'max:32'],
            'video_url'     => ['sometimes', 'nullable', 'url', 'max:255'],

            'country_id'    => ['sometimes', 'nullable', 'integer', 'exists:countries,id'],
            'state_id'      => ['sometimes', 'nullable', 'integer', 'exists:states,id'],
            'city_id'       => ['sometimes', 'nullable', 'integer', 'exists:cities,id'],
            'address'       => ['sometimes', 'nullable', 'string', 'max:255'],
            'latitude'      => ['sometimes', 'nullable', 'numeric', 'between:-90,90'],
            'longitude'     => ['sometimes', 'nullable', 'numeric', 'between:-180,180'],

            'custom_fields'   => ['sometimes', 'array'],
            'custom_fields.*' => ['nullable'],
        ];
    }
}

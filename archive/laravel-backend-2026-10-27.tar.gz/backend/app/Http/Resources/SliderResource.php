<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class SliderResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'           => $this->id,
            'image_url'    => $this->imageUrl(),
            'title'        => $this->title,
            'link_type'    => $this->link_type,
            'ad_id'        => $this->ad_id,
            'ad_slug'      => $this->whenLoaded('ad', fn () => $this->ad?->slug),
            'category_id'  => $this->category_id,
            'category_slug' => $this->whenLoaded('category', fn () => $this->category?->slug),
            'external_url' => $this->external_url,
            'sort_order'   => $this->sort_order,
        ];
    }
}

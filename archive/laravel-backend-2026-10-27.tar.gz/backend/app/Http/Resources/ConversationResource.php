<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ConversationResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        $uid  = $request->user()?->id;
        $role = $uid ? $this->roleOf($uid) : null;
        $unread = $role === 'buyer' ? $this->buyer_unread : $this->seller_unread;

        // The "other" participant relative to the viewer.
        $other = $role === 'buyer' ? $this->whenLoaded('seller') : $this->whenLoaded('buyer');

        return [
            'id'              => $this->id,
            'role'            => $role, // viewer is buyer or seller in this thread
            'unread_count'    => (int) $unread,
            'last_message'    => $this->last_message,
            'last_message_at' => $this->last_message_at,
            'ad'              => new AdResource($this->whenLoaded('ad')),
            'counterpart'     => new UserResource($other),
            'messages'        => MessageResource::collection($this->whenLoaded('messages')),
            'created_at'      => $this->created_at,
        ];
    }
}

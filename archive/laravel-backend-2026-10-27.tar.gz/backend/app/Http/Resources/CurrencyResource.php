<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class CurrencyResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'             => $this->id,
            'code'           => $this->code,
            'symbol'         => $this->symbol,
            'name'           => $this->name,
            'is_default'     => (bool) $this->is_default,
            'decimal_digits' => (int) $this->decimal_digits,
        ];
    }
}

<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/** Wraps an Illuminate\Notifications\DatabaseNotification. */
class NotificationResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        $data = is_array($this->data) ? $this->data : json_decode((string) $this->data, true);

        return [
            'id'         => $this->id,
            'type'       => $data['type'] ?? $this->type,
            'title'      => $data['title'] ?? null,
            'body'       => $data['body'] ?? null,
            'data'       => $data,
            'read'       => $this->read_at !== null,
            'read_at'    => $this->read_at,
            'created_at' => $this->created_at,
        ];
    }
}

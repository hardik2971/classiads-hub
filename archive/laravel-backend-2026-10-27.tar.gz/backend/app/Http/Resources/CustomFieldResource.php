<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class CustomFieldResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        // is_required can be overridden per-category via the pivot.
        $required = $this->whenPivotLoaded('category_custom_field', function () {
            return $this->pivot->is_required ?? $this->is_required;
        }, $this->is_required);

        return [
            'id'            => $this->id,
            'name'          => $this->name,
            'code'          => $this->code,
            'type'          => $this->type,
            'icon_path'     => $this->icon_path,
            'is_required'   => (bool) $required,
            'is_filterable' => (bool) $this->is_filterable,
            'sort_order'    => $this->whenPivotLoaded('category_custom_field', fn () => $this->pivot->sort_order, $this->sort_order),
            'options'       => CustomFieldOptionResource::collection($this->whenLoaded('options')),
        ];
    }
}

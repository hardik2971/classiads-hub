<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class CityResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'         => $this->id,
            'country_id' => $this->country_id,
            'state_id'   => $this->state_id,
            'name'       => $this->name,
            'latitude'   => $this->latitude !== null ? (float) $this->latitude : null,
            'longitude'  => $this->longitude !== null ? (float) $this->longitude : null,
        ];
    }
}

<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class SubscriptionResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'           => $this->id,
            'status'       => $this->status,
            'starts_at'    => $this->starts_at,
            'ends_at'      => $this->ends_at,
            'ad_limit'     => $this->ad_limit,
            'is_unlimited' => (bool) $this->is_unlimited,
            'ads_used'     => (int) $this->ads_used,
            'remaining'    => $this->remaining(),
            'is_live'      => $this->isLive(),
            'package'      => new PackageResource($this->whenLoaded('package')),
            'created_at'   => $this->created_at,
        ];
    }
}

<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class SellerProfileResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'            => $this->id,
            'display_name'  => $this->display_name,
            'bio'           => $this->bio,
            'business_name' => $this->business_name,
            'website'       => $this->website,
            'rating_avg'    => (float) $this->rating_avg,
            'rating_count'  => (int) $this->rating_count,
            'member_since'  => $this->member_since,
        ];
    }
}

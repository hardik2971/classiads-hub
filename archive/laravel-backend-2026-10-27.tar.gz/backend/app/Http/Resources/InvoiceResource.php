<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class InvoiceResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'             => $this->id,
            'number'         => $this->number,
            'subtotal'       => (int) $this->subtotal,
            'tax_amount'     => (int) $this->tax_amount,
            'total'          => (int) $this->total,
            'total_display'  => $this->currency_code.' '.number_format($this->total / 100, 2),
            'currency_code'  => $this->currency_code,
            'status'         => $this->status,
            'issued_at'      => $this->issued_at,
            'transaction_id' => $this->transaction_id,
        ];
    }
}

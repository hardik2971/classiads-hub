<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class UserResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'                 => $this->id,
            'name'               => $this->name,
            'email'              => $this->email,
            'phone'              => $this->phone,
            'avatar_path'        => $this->avatar_path,
            'status'             => $this->status,
            'is_verified'        => (bool) $this->is_verified,
            'email_verified'     => $this->email_verified_at !== null,
            'phone_verified'     => $this->phone_verified_at !== null,
            'preferred_language' => $this->preferred_language,
            'preferred_currency' => $this->preferred_currency,
            'roles'              => $this->whenLoaded('roles', fn () => $this->getRoleNames()),
            'seller_profile'     => new SellerProfileResource($this->whenLoaded('sellerProfile')),
            'created_at'         => $this->created_at,
        ];
    }
}

<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class CategoryResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'         => $this->id,
            'parent_id'  => $this->parent_id,
            'name'       => $this->name,
            'slug'       => $this->slug,
            'icon_path'  => $this->icon_path,
            'image_path' => $this->image_path,
            'type'       => $this->type,
            'sort_order' => $this->sort_order,
            'is_active'  => (bool) $this->is_active,
            'ads_count'  => (int) $this->ads_count,
            'children'   => CategoryResource::collection($this->whenLoaded('children')),
            'custom_fields' => CustomFieldResource::collection($this->whenLoaded('customFields')),
        ];
    }
}

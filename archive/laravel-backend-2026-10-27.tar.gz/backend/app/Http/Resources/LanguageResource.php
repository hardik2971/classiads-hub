<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class LanguageResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'         => $this->id,
            'name'       => $this->name,
            'code'       => $this->code,
            'flag_path'  => $this->flag_path,
            'is_rtl'     => (bool) $this->is_rtl,
            'is_default' => (bool) $this->is_default,
        ];
    }
}

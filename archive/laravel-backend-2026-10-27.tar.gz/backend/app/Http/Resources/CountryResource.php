<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class CountryResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'            => $this->id,
            'name'          => $this->name,
            'iso2'          => $this->iso2,
            'iso3'          => $this->iso3,
            'phone_code'    => $this->phone_code,
            'currency_code' => $this->currency_code,
            'flag_path'     => $this->flag_path,
            'states'        => StateResource::collection($this->whenLoaded('states')),
        ];
    }
}

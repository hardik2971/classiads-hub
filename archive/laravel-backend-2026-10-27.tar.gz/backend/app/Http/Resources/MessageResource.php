<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class MessageResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'              => $this->id,
            'conversation_id' => $this->conversation_id,
            'sender_id'       => $this->sender_id,
            'is_mine'         => $request->user()?->id === $this->sender_id,
            'type'            => $this->type,
            'body'            => $this->body,
            'offer'           => new OfferResource($this->whenLoaded('offer')),
            'read_at'         => $this->read_at,
            'created_at'      => $this->created_at,
        ];
    }
}

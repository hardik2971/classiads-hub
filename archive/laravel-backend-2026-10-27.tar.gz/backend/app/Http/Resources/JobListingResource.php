<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class JobListingResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'                 => $this->id,
            'title'              => $this->title,
            'slug'               => $this->slug,
            'company_name'       => $this->company_name,
            'description'        => $this->description,
            'employment_type'    => $this->employment_type,
            'salary_min'         => $this->salary_min,
            'salary_max'         => $this->salary_max,
            'salary_display'     => $this->salaryDisplay(),
            'currency_code'      => $this->currency_code,
            'status'             => $this->status,
            'applications_count' => (int) $this->applications_count,
            'city'               => $this->whenLoaded('city', fn () => $this->city?->name),
            'category'           => new CategoryResource($this->whenLoaded('category')),
            'employer'           => new UserResource($this->whenLoaded('employer')),
            'has_applied'        => $this->when(isset($this->has_applied), fn () => (bool) $this->has_applied),
            'expires_at'         => $this->expires_at,
            'created_at'         => $this->created_at,
        ];
    }

    private function salaryDisplay(): ?string
    {
        if (! $this->salary_min && ! $this->salary_max) {
            return null;
        }
        $fmt = fn ($v) => $this->currency_code.' '.number_format($v / 100, 0);

        return match (true) {
            $this->salary_min && $this->salary_max => $fmt($this->salary_min).' - '.$fmt($this->salary_max),
            (bool) $this->salary_min               => 'From '.$fmt($this->salary_min),
            default                                => 'Up to '.$fmt($this->salary_max),
        };
    }
}

<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class FeaturedSectionResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'          => $this->id,
            'title'       => $this->title,
            'filter_type' => $this->filter_type,
            'style'       => $this->style,
            'category_id' => $this->category_id,
            'ads'         => AdResource::collection($this->whenLoaded('resolvedAds')),
        ];
    }
}

<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class BlogPostResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        $full = $request->routeIs('*.show') || $request->is('*/blog/*');

        return [
            'id'           => $this->id,
            'title'        => $this->title,
            'slug'         => $this->slug,
            'excerpt'      => $this->excerpt,
            'body'         => $this->when($full || $request->boolean('full'), $this->body),
            'cover_image'  => $this->cover_image_path,
            'status'       => $this->status,
            'views_count'  => (int) $this->views_count,
            'category'     => new BlogCategoryResource($this->whenLoaded('category')),
            'author'       => new UserResource($this->whenLoaded('author')),
            'published_at' => $this->published_at,
            'created_at'   => $this->created_at,
        ];
    }
}

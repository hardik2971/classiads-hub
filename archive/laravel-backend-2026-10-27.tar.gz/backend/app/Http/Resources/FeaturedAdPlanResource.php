<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class FeaturedAdPlanResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'            => $this->id,
            'name'          => $this->name,
            'description'   => $this->description,
            'price'         => (int) $this->price,
            'price_display' => $this->currency_code.' '.number_format($this->price / 100, 2),
            'currency_code' => $this->currency_code,
            'duration_days' => (int) $this->duration_days,
        ];
    }
}

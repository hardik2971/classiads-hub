<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ReviewResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'          => $this->id,
            'ad_id'       => $this->ad_id,
            'rating'      => (int) $this->rating,
            'comment'     => $this->comment,
            'type'        => $this->type,
            'is_approved' => (bool) $this->is_approved,
            'reviewer'    => new UserResource($this->whenLoaded('reviewer')),
            'reviewee'    => new UserResource($this->whenLoaded('reviewee')),
            'created_at'  => $this->created_at,
        ];
    }
}

<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class VerificationRequestResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'               => $this->id,
            'document_type'    => $this->document_type,
            'document_number'  => $this->document_number,
            'status'           => $this->status,
            'rejection_reason' => $this->rejection_reason,
            'reviewed_at'      => $this->reviewed_at,
            'user'             => new UserResource($this->whenLoaded('user')),
            'created_at'       => $this->created_at,
        ];
    }
}

<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class TransactionResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'            => $this->id,
            'type'          => $this->type,
            'gateway'       => $this->gateway,
            'reference'     => $this->gateway_reference,
            'amount'        => (int) $this->amount,
            'tax_amount'    => (int) $this->tax_amount,
            'total'         => (int) $this->total,
            'total_display' => $this->totalDisplay(),
            'currency_code' => $this->currency_code,
            'status'        => $this->status,
            'paid_at'       => $this->paid_at,
            'package'       => new PackageResource($this->whenLoaded('package')),
            'ad'            => new AdResource($this->whenLoaded('ad')),
            'invoice'       => new InvoiceResource($this->whenLoaded('invoice')),
            'created_at'    => $this->created_at,
        ];
    }
}

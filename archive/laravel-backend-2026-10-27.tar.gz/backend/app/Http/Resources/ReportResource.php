<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ReportResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'              => $this->id,
            'reportable_type' => class_basename($this->reportable_type),
            'reportable_id'   => $this->reportable_id,
            'reason'          => $this->reason,
            'details'         => $this->details,
            'status'          => $this->status,
            'reporter'        => new UserResource($this->whenLoaded('reporter')),
            'created_at'      => $this->created_at,
            'resolved_at'     => $this->resolved_at,
        ];
    }
}

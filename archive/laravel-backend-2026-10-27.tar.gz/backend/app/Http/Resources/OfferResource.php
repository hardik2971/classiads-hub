<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class OfferResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'              => $this->id,
            'ad_id'           => $this->ad_id,
            'conversation_id' => $this->conversation_id,
            'buyer_id'        => $this->buyer_id,
            'seller_id'       => $this->seller_id,
            'parent_offer_id' => $this->parent_offer_id,
            'amount'          => (int) $this->amount,
            'amount_display'  => $this->amountDisplay(),
            'currency_code'   => $this->currency_code,
            'status'          => $this->status,
            'message'         => $this->message,
            'ad'              => new AdResource($this->whenLoaded('ad')),
            'created_at'      => $this->created_at,
        ];
    }
}

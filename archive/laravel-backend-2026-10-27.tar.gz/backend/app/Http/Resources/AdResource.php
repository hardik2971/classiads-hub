<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class AdResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'              => $this->id,
            'title'           => $this->title,
            'slug'            => $this->slug,
            'description'     => $this->description,
            'price'           => $this->price !== null ? (int) $this->price : null,
            'price_display'   => $this->priceDisplay(),
            'currency_code'   => $this->currency_code,
            'price_type'      => $this->price_type,
            'condition'       => $this->condition,
            'phone'           => $this->phone,
            'video_url'       => $this->video_url,
            'status'          => $this->status,
            'is_featured'     => (bool) $this->is_featured,
            'views_count'     => (int) $this->views_count,
            'favorites_count' => (int) $this->favorites_count,
            'is_favorited'    => $this->when(isset($this->is_favorited), fn () => (bool) $this->is_favorited),
            'location'        => [
                'address'   => $this->address,
                'latitude'  => $this->latitude !== null ? (float) $this->latitude : null,
                'longitude' => $this->longitude !== null ? (float) $this->longitude : null,
                'city'      => $this->whenLoaded('city', fn () => $this->city?->name),
                'state'     => $this->whenLoaded('state', fn () => $this->state?->name),
                'country'   => $this->whenLoaded('country', fn () => $this->country?->name),
            ],
            'distance_km'     => $this->when(isset($this->distance_km), fn () => round((float) $this->distance_km, 1)),
            'category'        => new CategoryResource($this->whenLoaded('category')),
            'seller'          => new UserResource($this->whenLoaded('user')),
            'images'          => AdImageResource::collection($this->whenLoaded('images')),
            'custom_fields'   => AdFieldValueResource::collection($this->whenLoaded('fieldValues')),
            'published_at'    => $this->published_at,
            'expires_at'      => $this->expires_at,
            'created_at'      => $this->created_at,
        ];
    }

    private function priceDisplay(): ?string
    {
        if ($this->price_type === 'free') {
            return 'Free';
        }
        if ($this->price_type === 'contact' || $this->price === null) {
            return 'Contact for price';
        }

        $amount = $this->price / 100;

        return $this->currency_code.' '.number_format($amount, 2);
    }
}

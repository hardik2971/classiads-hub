<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class PageResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'key'        => $this->key,
            'title'      => $this->title,
            'body'       => $this->body,
            'updated_at' => $this->updated_at,
        ];
    }
}

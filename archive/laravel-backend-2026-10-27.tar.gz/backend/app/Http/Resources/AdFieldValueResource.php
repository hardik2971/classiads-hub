<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class AdFieldValueResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        $field = $this->whenLoaded('customField');
        $value = $this->value;

        // checkbox values are stored as JSON arrays
        $decoded = json_decode((string) $value, true);
        if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
            $value = $decoded;
        }

        return [
            'custom_field_id' => $this->custom_field_id,
            'code'            => $field?->code,
            'name'            => $field?->name,
            'type'            => $field?->type,
            'value'           => $value,
        ];
    }
}

<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class JobApplicationResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'           => $this->id,
            'status'       => $this->status,
            'cover_letter' => $this->cover_letter,
            'resume_path'  => $this->resume_path,
            'job'          => new JobListingResource($this->whenLoaded('jobListing')),
            'applicant'    => new UserResource($this->whenLoaded('applicant')),
            'created_at'   => $this->created_at,
        ];
    }
}

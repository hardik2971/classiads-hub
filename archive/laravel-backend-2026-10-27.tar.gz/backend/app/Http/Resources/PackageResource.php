<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class PackageResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'                 => $this->id,
            'name'               => $this->name,
            'description'        => $this->description,
            'price'              => (int) $this->price,
            'discount_percent'   => (int) $this->discount_percent,
            'final_price'        => (int) $this->final_price,
            'price_display'      => $this->currency_code.' '.number_format($this->final_price / 100, 2),
            'currency_code'      => $this->currency_code,
            'duration_days'      => (int) $this->duration_days,
            'ad_limit'           => $this->ad_limit,
            'is_unlimited'       => (bool) $this->is_unlimited,
            'icon_path'          => $this->icon_path,
            'ios_product_id'     => $this->ios_product_id,
            'android_product_id' => $this->android_product_id,
            'categories'         => CategoryResource::collection($this->whenLoaded('categories')),
        ];
    }
}

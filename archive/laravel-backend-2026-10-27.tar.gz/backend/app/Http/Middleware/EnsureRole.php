<?php

namespace App\Http\Middleware;

use App\Support\ApiResponse;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Guard-safe role gate for API (Sanctum) routes.
 *
 * Unlike Spatie's RoleMiddleware, this resolves the authenticated user via
 * $request->user() (works for any active guard) and checks roles directly,
 * avoiding web/sanctum guard-name mismatches.
 *
 * Usage: ->middleware('ensure_role:admin,super-admin')
 */
class EnsureRole
{
    public function handle(Request $request, Closure $next, string ...$roles): Response
    {
        $user = $request->user();

        if (! $user) {
            return ApiResponse::error('Unauthenticated.', 401);
        }

        if (! $user->hasAnyRole($roles)) {
            return ApiResponse::error('This action is unauthorized.', 403);
        }

        return $next($request);
    }
}

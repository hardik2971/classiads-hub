<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Adds conservative security response headers (Phase 6 hardening).
 * Deliberately omits a strict Content-Security-Policy to avoid breaking the
 * Filament admin (inline assets) and the Leaflet map CDN.
 */
class SecurityHeaders
{
    public function handle(Request $request, Closure $next): Response
    {
        $response = $next($request);

        $headers = [
            'X-Content-Type-Options' => 'nosniff',
            'X-Frame-Options'        => 'SAMEORIGIN',
            'Referrer-Policy'        => 'strict-origin-when-cross-origin',
            'X-XSS-Protection'       => '0', // modern browsers rely on CSP; legacy filter disabled
            'Permissions-Policy'     => 'geolocation=(self), microphone=(), camera=()',
        ];

        // Only advertise HSTS over real TLS, never on plain-HTTP localhost.
        if ($request->isSecure()) {
            $headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains';
        }

        foreach ($headers as $key => $value) {
            if (! $response->headers->has($key)) {
                $response->headers->set($key, $value);
            }
        }

        return $response;
    }
}
